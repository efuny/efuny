package cn.legendream.wawa.kit;

/**
 * @version V1.0 <>
 * @FileName: Constants
 * @author: Samson.Sun
 * @date: 2017-12-7 19:51
 * @email: s_xin@neusoft.com
 */
public class Constants {
    public static final String APP_ID = "wx6a80112f66ba9cd9";
}
