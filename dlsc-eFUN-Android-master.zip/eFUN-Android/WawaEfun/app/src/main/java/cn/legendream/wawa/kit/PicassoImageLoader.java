package cn.legendream.wawa.kit;

import android.app.Activity;
import android.widget.ImageView;


import com.lzy.imagepicker.loader.ImageLoader;

import java.io.File;

import cn.droidlover.xdroidmvp.imageloader.ILFactory;

/**
 * @version V1.0 <>
 * @FileName: PicassoImageLoader
 * @author: Samson.Sun
 * @date: 2017-12-23 11:52
 * @email: s_xin@neusoft.com
 */
public class PicassoImageLoader implements ImageLoader {
    @Override
    public void displayImage(Activity activity, String path, ImageView imageView, int width, int height) {
        ILFactory.getLoader().loadFile(imageView, new File(path), null);
    }

    @Override
    public void displayImagePreview(Activity activity, String path, ImageView imageView, int width, int height) {

    }

    @Override
    public void clearMemoryCache() {

    }
}
