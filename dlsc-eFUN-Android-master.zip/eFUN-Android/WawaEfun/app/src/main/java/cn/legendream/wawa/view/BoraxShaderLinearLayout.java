package cn.legendream.wawa.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

import cn.legendream.wawa.R;

/**
 * Created by zhaoyuefeng on 2017/8/25.
 */

public class BoraxShaderLinearLayout extends LinearLayout {

    private Paint paint;

    private int bgColor;
    private int shaderColor;
    private float cornerRadius;
    private float shaderRadius;
    private float shaderPositionX;
    private float shaderPositionY = 1;
    private boolean showShaderLeft;
    private boolean showShaderRight;
    private boolean showShaderTop;
    private boolean showShaderBottom;
    private int borderColor;
    private float borderWidth;
//    private int paddingLeft;
//    private int paddingTop;
//    private int paddingRight;
//    private int paddingBottom;

    private Paint borderPaint;

    public BoraxShaderLinearLayout(Context context) {
        this(context, null, 0);
    }

    public BoraxShaderLinearLayout(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public BoraxShaderLinearLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        TypedArray typedArray = context.getTheme().obtainStyledAttributes(attrs, R.styleable.BoraxShaderLinearLayout, defStyleAttr, 0);

        for (int i = 0; i < typedArray.getIndexCount(); i++) {

            int attr = typedArray.getIndex(i);

            if (attr == R.styleable.BoraxShaderLinearLayout_bg_color) {
                bgColor = typedArray.getColor(attr, Color.WHITE);
            } else if (attr == R.styleable.BoraxShaderLinearLayout_shader_color) {
                shaderColor = typedArray.getColor(attr, Color.GRAY);
            } else if (attr == R.styleable.BoraxShaderLinearLayout_corner_radius) {
                cornerRadius = typedArray.getDimension(attr, 0);
            } else if (attr == R.styleable.BoraxShaderLinearLayout_shader_radius) {
                shaderRadius = typedArray.getDimension(attr, 5);
            } else if (attr == R.styleable.BoraxShaderLinearLayout_shader_position_x) {
                shaderPositionX = typedArray.getDimension(attr, 0);
            } else if (attr == R.styleable.BoraxShaderLinearLayout_shader_position_y) {
                shaderPositionY = typedArray.getDimension(attr, 1);
            } else if (attr == R.styleable.BoraxShaderLinearLayout_show_shader_left) {
                showShaderLeft = typedArray.getBoolean(attr, true);
            } else if (attr == R.styleable.BoraxShaderLinearLayout_show_shader_right) {
                showShaderRight = typedArray.getBoolean(attr, true);
            } else if (attr == R.styleable.BoraxShaderLinearLayout_show_shader_top) {
                showShaderTop = typedArray.getBoolean(attr, true);
            } else if (attr == R.styleable.BoraxShaderLinearLayout_show_shader_bottom) {
                showShaderBottom = typedArray.getBoolean(attr, true);
            } else if (attr == R.styleable.BoraxShaderLinearLayout_border_width) {
                borderWidth = typedArray.getDimension(attr, 0);
            } else if (attr == R.styleable.BoraxShaderLinearLayout_border_color) {
                borderColor = typedArray.getColor(attr, Color.BLACK);
            }
//            else if (attr == R.styleable.BoraxShaderLinearLayout_padding_left) {
//                paddingLeft = ((int) typedArray.getDimension(attr, 0));
//            } else if (attr == R.styleable.BoraxShaderLinearLayout_padding_top) {
//                paddingTop = ((int) typedArray.getDimension(attr, 0));
//            } else if (attr == R.styleable.BoraxShaderLinearLayout_padding_right) {
//                paddingRight = ((int) typedArray.getDimension(attr, 0));
//            } else if (attr == R.styleable.BoraxShaderLinearLayout_padding_bottom) {
//                paddingBottom = ((int) typedArray.getDimension(attr, 0));
//            }

        }

        setWillNotDraw(false);

    }

    {
        paint = new Paint();
        paint.setAntiAlias(true);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        shaderColor = Color.parseColor("#506E86A7");
        shaderRadius = 10;

        borderPaint = new Paint();
        borderPaint.setAntiAlias(true);

        showShaderLeft = true;
        showShaderBottom = true;
        showShaderRight = true;
        showShaderTop = true;

        bgColor = Color.WHITE;

    }

    @Override
    protected void onDraw(Canvas canvas) {

        int margin = (int) (shaderRadius * 1.2);
        int leftMargin = 0;
        int topMargin = 0;
        int rightMargin = 0;
        int bottomMargin = 0;

        if (showShaderTop) {
            topMargin = margin;
        }

        if (showShaderBottom) {
            bottomMargin = margin;
        }

        if (showShaderLeft) {
            leftMargin = margin;
        }

        if (showShaderRight) {
            rightMargin = margin;
        }

        //draw background
        RectF rectF = new RectF(leftMargin + borderWidth / 2, topMargin + borderWidth / 2,
                getWidth() - rightMargin - borderWidth / 2, getHeight() - bottomMargin - borderWidth / 2);

        paint.setColor(bgColor);
        paint.setShadowLayer(shaderRadius, shaderPositionX, shaderPositionY, shaderColor);
        canvas.drawRoundRect(rectF, cornerRadius, cornerRadius, paint);

        //draw border
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setColor(borderColor);
        borderPaint.setStrokeWidth(borderWidth);
        float x = ((float) (borderWidth - (borderWidth / Math.pow(3, 1 / 2.0))));

        RectF borderRectF = new RectF(leftMargin + x, topMargin + x,
                getWidth() - rightMargin - x, getHeight() - bottomMargin - x);

        canvas.drawRoundRect(borderRectF, cornerRadius, cornerRadius, borderPaint);

//        setPadding(leftMargin + paddingLeft, topMargin + paddingTop, rightMargin + paddingRight, bottomMargin + paddingBottom);
//        setPadding(leftMargin , topMargin , rightMargin , bottomMargin );

        super.onDraw(canvas);
    }
}
