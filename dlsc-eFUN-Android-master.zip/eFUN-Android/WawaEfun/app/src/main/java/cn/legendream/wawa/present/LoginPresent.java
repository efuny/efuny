package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.LoginParam;
import cn.legendream.wawa.model.LoginResult;
import cn.legendream.wawa.model.TestLoginParam;
import cn.legendream.wawa.model.TestLoginResult;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.LoginActivity;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: LoginPresent
 * @author: Samson.Sun
 * @date: 2017-12-8 9:43
 * @email: s_xin@neusoft.com
 */
public class LoginPresent extends XPresent<LoginActivity> {

    public void doLogin(LoginParam loginParam) {

        Api.getLoginService().doLogin(NetUtil.createRequestBody(loginParam))
                .compose(XApi.<BaseModel<LoginResult>>getApiTransformer())
                .compose(XApi.<BaseModel<LoginResult>>getScheduler())
                .compose(getV().<BaseModel<LoginResult>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<LoginResult>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<LoginResult> loginResult) {
                        getV().hideProgress();
                        getV().showData(loginResult);
                    }
                });
    }

    public void testLogin(TestLoginParam testLoginParam) {

        Api.getLoginService().testLogin(NetUtil.createRequestBody(testLoginParam))
                .compose(XApi.<BaseModel<LoginResult>>getApiTransformer())
                .compose(XApi.<BaseModel<LoginResult>>getScheduler())
                .compose(getV().<BaseModel<LoginResult>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<LoginResult>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<LoginResult> loginResult) {
                        getV().hideProgress();
                        getV().showData(loginResult);
                    }
                });
    }

    public void getTestLogin() {

        Api.getLoginService().getTestLogin()
                .compose(XApi.<BaseModel<TestLoginResult>>getApiTransformer())
                .compose(XApi.<BaseModel<TestLoginResult>>getScheduler())
                .compose(getV().<BaseModel<TestLoginResult>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<TestLoginResult>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<TestLoginResult> testLoginResult) {
                        getV().hideProgress();
                        getV().showTestResult(testLoginResult);
                    }
                });
    }
}
