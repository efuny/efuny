package cn.legendream.wawa;

import cn.legendream.wawa.model.Account;

/**
 * @version V1.0 <>
 * @FileName: AppContext
 * @author: Samson.Sun
 * @date: 2017-12-6 11:07
 * @email: s_xin@neusoft.com
 */
public class AppContext {
    private static Account account;//账户信息

    public static void setAccount(Account account) {
        AppContext.account = account;
    }

    public static Account getAccount() {
        return account;
    }
}
