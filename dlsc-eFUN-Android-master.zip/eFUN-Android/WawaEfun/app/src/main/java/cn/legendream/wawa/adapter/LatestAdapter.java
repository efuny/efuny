package cn.legendream.wawa.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import cn.droidlover.xdroidmvp.base.SimpleListAdapter;
import cn.droidlover.xdroidmvp.kit.KnifeKit;
import cn.legendream.wawa.R;
import cn.legendream.wawa.model.MachineModel;

/**
 * @version V1.0 <>
 * @FileName: LatestAdapter
 * @author: Samson.Sun
 * @date: 2017-12-9 20:33
 * @email: s_xin@neusoft.com
 */
public class LatestAdapter extends SimpleListAdapter<MachineModel,HomeAdapter.ViewHolder> {

    public LatestAdapter(Context context) {
        super(context);
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = View.inflate(context, R.layout.item_machine, null);
        }
        return view;
    }

    @Override
    protected HomeAdapter.ViewHolder newViewHolder(View convertView) {
        return new HomeAdapter.ViewHolder(convertView);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.item_machine;
    }

    @Override
    protected void convert(HomeAdapter.ViewHolder holder, MachineModel item, int position) {

    }

    public static class ViewHolder  {

        public ViewHolder(View convertView) {
            KnifeKit.bind(this, convertView);
        }
    }
}
