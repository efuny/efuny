package cn.legendream.wawa.model;

import java.util.List;

/**
 * @version V1.0 <>
 * @FileName: RechargeModel
 * @author: Samson.Sun
 * @date: 2017-12-21 23:35
 * @email: s_xin@neusoft.com
 */
public class RechargeModel {
    public RechargeModel() {
    }
    private String userMoney;
    private List<RechargeListModel> list;

    public String getUserMoney() {
        return userMoney;
    }

    public void setUserMoney(String userMoney) {
        this.userMoney = userMoney;
    }

    public List<RechargeListModel> getList() {
        return list;
    }

    public void setList(List<RechargeListModel> list) {
        this.list = list;
    }
}
