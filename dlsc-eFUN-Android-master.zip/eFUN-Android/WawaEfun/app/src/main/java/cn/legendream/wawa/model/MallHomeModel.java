package cn.legendream.wawa.model;

import java.util.List;

/**
 * @version V1.0 <>
 * @FileName: MallHomeModel
 * @author: Samson.Sun
 * @date: 2018-7-17 23:11
 * @email: s_xin@neusoft.com
 */
public class MallHomeModel {
    public MallHomeModel() {
    }
    private List<ScoreBannerModel> bannerList;
    private UserInfoModel userInfo;
    private List<CategoryModel> categoryList;
    private List<PopularModel> popularList;
    private List<GoodsModel> goodList;

    public List<ScoreBannerModel> getBannerList() {
        return bannerList;
    }

    public void setBannerList(List<ScoreBannerModel> bannerList) {
        this.bannerList = bannerList;
    }

    public UserInfoModel getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(UserInfoModel userInfo) {
        this.userInfo = userInfo;
    }

    public List<CategoryModel> getCategoryList() {
        return categoryList;
    }

    public void setCategoryList(List<CategoryModel> categoryList) {
        this.categoryList = categoryList;
    }

    public List<PopularModel> getPopularList() {
        return popularList;
    }

    public void setPopularList(List<PopularModel> popularList) {
        this.popularList = popularList;
    }

    public List<GoodsModel> getGoodList() {
        return goodList;
    }

    public void setGoodList(List<GoodsModel> goodList) {
        this.goodList = goodList;
    }
}
