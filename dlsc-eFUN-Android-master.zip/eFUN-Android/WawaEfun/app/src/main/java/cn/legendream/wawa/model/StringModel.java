package cn.legendream.wawa.model;

import cn.droidlover.xdroidmvp.net.IModel;

/**
 * @version V1.0 <>
 * @FileName: StringModel
 * @author: Samson.Sun
 * @date: 2018-1-17 17:28
 * @email: s_xin@neusoft.com
 */
public class StringModel implements IModel {
    public StringModel() {
    }

    @Override
    public boolean isNull() {
        return false;
    }

    @Override
    public boolean isAuthError() {
        return false;
    }

    @Override
    public boolean isBizError() {
        return false;
    }

    @Override
    public boolean isOtherError() {
        return false;
    }

    @Override
    public String getErrorMsg() {
        return "";
    }
}
