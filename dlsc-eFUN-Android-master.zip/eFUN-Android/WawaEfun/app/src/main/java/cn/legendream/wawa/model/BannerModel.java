package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: BannerModel
 * @author: Samson.Sun
 * @date: 2018-1-8 23:12
 * @email: s_xin@neusoft.com
 */
public class BannerModel {
    public BannerModel() {
    }
    private String imagesUrl;
    private String url;
    private String bannerTitle;

    public String getImagesUrl() {
        return imagesUrl;
    }

    public void setImagesUrl(String imagesUrl) {
        this.imagesUrl = imagesUrl;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getBannerTitle() {
        return bannerTitle;
    }

    public void setBannerTitle(String bannerTitle) {
        this.bannerTitle = bannerTitle;
    }
}
