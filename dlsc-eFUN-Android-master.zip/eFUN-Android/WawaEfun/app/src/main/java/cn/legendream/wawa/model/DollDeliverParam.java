package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: DollDeliverParam
 * @author: Samson.Sun
 * @date: 2017-12-24 11:56
 * @email: s_xin@neusoft.com
 */
public class DollDeliverParam {
    public DollDeliverParam() {
    }

    private String userId;
    private String orderId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
