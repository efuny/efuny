package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: MachineModel
 * @author: Samson.Sun
 * @date: 2017-12-11 10:31
 * @email: s_xin@neusoft.com
 */
public class MachineModel {
    public MachineModel() {
    }

    private String machineName;
    private String dollImg;
    private String machinemg;
    private String ipAddress;
    private String gameMoney;
    private String machineId;
    private String faceCamera;
    private String sideCamera;
    private String statusText;
    private String isNew;

    public String getMachineName() {
        return machineName;
    }

    public void setMachineName(String machineName) {
        this.machineName = machineName;
    }

    public String getDollImg() {
        return dollImg;
    }

    public void setDollImg(String dollImg) {
        this.dollImg = dollImg;
    }

    public String getMachinemg() {
        return machinemg;
    }

    public void setMachinemg(String machinemg) {
        this.machinemg = machinemg;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getGameMoney() {
        return gameMoney;
    }

    public void setGameMoney(String gameMoney) {
        this.gameMoney = gameMoney;
    }

    public String getMachineId() {
        return machineId;
    }

    public void setMachineId(String machineId) {
        this.machineId = machineId;
    }

    public String getFaceCamera() {
        return faceCamera;
    }

    public void setFaceCamera(String faceCamera) {
        this.faceCamera = faceCamera;
    }

    public String getSideCamera() {
        return sideCamera;
    }

    public void setSideCamera(String sideCamera) {
        this.sideCamera = sideCamera;
    }

    public String getStatusText() {
        return statusText;
    }

    public void setStatusText(String statusText) {
        this.statusText = statusText;
    }

    public String getIsNew() {
        return isNew;
    }

    public void setIsNew(String isNew) {
        this.isNew = isNew;
    }
}
