package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: UserMessageInfoModel
 * @author: Samson.Sun
 * @date: 2018-6-12 23:15
 * @email: s_xin@neusoft.com
 */
public class UserMessageInfoModel {
    public UserMessageInfoModel() {
    }
    private String isNew;

    public String getIsNew() {
        return isNew;
    }

    public void setIsNew(String isNew) {
        this.isNew = isNew;
    }
}
