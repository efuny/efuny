package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: SystemStartPageInfoModel
 * @author: Samson.Sun
 * @date: 2018-6-12 21:29
 * @email: s_xin@neusoft.com
 */
public class SystemStartPageInfoModel {
    public SystemStartPageInfoModel() {
    }

    private String url;
    private String openUrl;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getOpenUrl() {
        return openUrl;
    }

    public void setOpenUrl(String openUrl) {
        this.openUrl = openUrl;
    }
}
