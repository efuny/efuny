package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: DollListInfoModel
 * @author: Samson.Sun
 * @date: 2018-1-19 13:46
 * @email: s_xin@neusoft.com
 */
public class DollListInfoModel {
    public DollListInfoModel() {
    }

    private String dollName;
    private String doll_img;
    private String create_time;
    private String isCheck;
    private String orderId;

    public String getDollName() {
        return dollName;
    }

    public void setDollName(String dollName) {
        this.dollName = dollName;
    }

    public String getDoll_img() {
        return doll_img;
    }

    public void setDoll_img(String doll_img) {
        this.doll_img = doll_img;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public String getIsCheck() {
        return isCheck;
    }

    public void setIsCheck(String isCheck) {
        this.isCheck = isCheck;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

}
