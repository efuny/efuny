package cn.legendream.wawa.ui.v3.mine.guidebook;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.AboutModel;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.net.Api;
import io.reactivex.functions.Consumer;

/**
 * Created by zhaoyuefeng on 2019/6/10.
 * Description 
 */
public class GuideBookPresenter extends XPresent<GuideBookActivity> {

    public void getAbout() {
        Api.getSimpleService().getAbout()
                .compose(XApi.<BaseModel<AboutModel>>getApiTransformer())
                .compose(XApi.<BaseModel<AboutModel>>getScheduler())
                .compose(getV().<BaseModel<AboutModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<AboutModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<AboutModel> result) {
                        getV().hideProgress();
                        getV().showUrl(result.getData().getProblemUrl());
                    }
                });
    }

}
