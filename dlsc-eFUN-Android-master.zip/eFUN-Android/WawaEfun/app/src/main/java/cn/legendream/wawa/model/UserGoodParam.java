package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: UserGoodParam
 * @author: Samson.Sun
 * @date: 2018-7-21 16:06
 * @email: s_xin@neusoft.com
 */
public class UserGoodParam {
    public UserGoodParam() {
    }

    private String goodId;
    private String userId;
    private String addressId;

    public String getGoodId() {
        return goodId;
    }

    public void setGoodId(String goodId) {
        this.goodId = goodId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }
}
