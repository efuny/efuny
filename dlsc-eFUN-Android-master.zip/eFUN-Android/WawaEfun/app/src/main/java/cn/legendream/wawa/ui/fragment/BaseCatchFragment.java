package cn.legendream.wawa.ui.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.event.BusProvider;
import cn.droidlover.xdroidmvp.mvp.XLazyFragment;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.view.refreshlayout.SmartRefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.MaterialHeader;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.RefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.enumvo.SpinnerStyle;
import cn.droidlover.xdroidmvp.view.refreshlayout.footer.BallPulseFooter;
import cn.droidlover.xdroidmvp.view.refreshlayout.listener.OnRefreshLoadmoreListener;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.event.RefreshCatchEvent;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.Account;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.CatchModel;
import cn.legendream.wawa.model.OrderExchangeInfoModel;
import cn.legendream.wawa.model.RecordModel;
import cn.legendream.wawa.model.RecordParam;
import cn.legendream.wawa.model.UserOrderModel;
import cn.legendream.wawa.model.UserOrderParam;
import cn.legendream.wawa.present.CatchPresent;
import cn.legendream.wawa.view.ScoreChoiceDialog;
import cn.legendream.wawa.view.ScoreDialog;
import io.reactivex.functions.Consumer;

import static android.support.v7.widget.DividerItemDecoration.VERTICAL;

/**
 * @version V1.0 <>
 * @FileName: BaseCatchFragment
 * @author: Samson.Sun
 * @date: 2017-12-9 19:47
 * @email: s_xin@neusoft.com
 */
public abstract class BaseCatchFragment extends XLazyFragment<CatchPresent> {
    @BindView(R.id.contentLayout)
    XRecyclerView contentLayout;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    public static CatchListener catchChangedListener;
    private int page = 1;

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        initAdapter();
        //设置 Header 为 Material风格
        refreshLayout.setRefreshHeader(new MaterialHeader(context).setShowBezierWave(false));
        //设置 Footer 为 球脉冲
        refreshLayout.setRefreshFooter(new BallPulseFooter(context).setSpinnerStyle(SpinnerStyle.Scale));
        refreshLayout.autoRefresh();//第一次进入触发自动刷新，演示效果
        refresh(true);

        refreshLayout.setOnRefreshLoadmoreListener(new OnRefreshLoadmoreListener() {
            @Override
            public void onLoadmore(RefreshLayout refreshlayout) {
                refresh(false);
            }

            @Override
            public void onRefresh(RefreshLayout refreshlayout) {
                refresh(true);
            }
        });

        BusProvider.getBus().toFlowable(RefreshCatchEvent.class)
                .subscribe(new Consumer<RefreshCatchEvent>() {
                    @Override
                    public void accept(RefreshCatchEvent refreshCatchEvent) throws Exception {
                        refresh(true);
                    }
                });
    }

    protected void refresh(boolean isRefresh) {
        final RecordParam recordParam = new RecordParam();
        recordParam.setUserId(AppContext.getAccount().getUserId());
        recordParam.setType(getType());
        if (isRefresh) {
            page = 1;
            recordParam.setPage(page + "");
            getP().userGrabRecordList(true, recordParam);
        } else {
            page++;
            recordParam.setPage(page + "");
            getP().userGrabRecordList(false, recordParam);
        }
    }

    private void initAdapter() {
        setLayoutManager(contentLayout);
        contentLayout.setItemAnimator(new DefaultItemAnimator());
        contentLayout.setLayoutManager(new GridLayoutManager(context, 2));
//        contentLayout.addItemDecoration(new DividerItemDecoration(context, VERTICAL));
        contentLayout.setAdapter(getAdapter());
    }

    public interface CatchListener {
        void catchInfoChanged(String username, String headUrl, String dollCount);
    }

    public abstract SimpleRecAdapter getAdapter();

    public abstract void setLayoutManager(XRecyclerView recyclerView);

    public abstract String getType();

    @Override
    public int getLayoutId() {
        return R.layout.fragment_base_catch;
    }

    @Override
    public CatchPresent newP() {
        return new CatchPresent();
    }

    public void showError(NetError error) {
        super.showError(error);
        refreshLayout.finishRefresh();
        refreshLayout.finishLoadmore();
    }

    public void showData(boolean isRefresh, BaseModel<RecordModel> result) {
        if (isRefresh) {
            refreshLayout.finishRefresh();
            refreshLayout.resetNoMoreData();
        } else {
            refreshLayout.finishLoadmore();
        }
        if (catchChangedListener != null) {
            RecordModel.UserInfo userInfo = result.getData().getUserInfo();
            catchChangedListener.catchInfoChanged(userInfo.getUsername(), userInfo.getHeadUrl(), userInfo.getDollCount());
        }
        if (page > 1) {
            getAdapter().addData(result.getData().getGrabList());
        } else {
            getAdapter().setData(result.getData().getGrabList());
        }
    }

    public void exchangeOrder(String orderId) {
        UserOrderParam userOrderParam = new UserOrderParam();
        userOrderParam.setOrderId(orderId);
        userOrderParam.setUserId(AppContext.getAccount().getUserId());
        getP().userOrderChangeScore(userOrderParam);
    }

    public void exchangeResult(BaseModel<UserOrderModel> result) {
        if (result.getData() == null || TextUtils.isEmpty(result.getData().getPoint())) {
            toast(getString(R.string.exchange_failed));
            return;
        }
        toast(getString(R.string.exchange_success));
        Account account = AppContext.getAccount();
        account.setGameMoney(result.getData().getPoint());
        SharedPref.getInstance(context).put(Keys.ACCOUNT, account);
        AppContext.setAccount(account);
        final RecordParam recordParam = new RecordParam();
        recordParam.setUserId(AppContext.getAccount().getUserId());
        recordParam.setPage(page + "");
        recordParam.setType(getType());
        page = 1;
        getP().userGrabRecordList(true, recordParam);
    }

    public void orderExchangeInfo(CatchModel catchModel) {
        UserOrderParam userOrderParam = new UserOrderParam();
        userOrderParam.setOrderId(catchModel.getOrderId());
        userOrderParam.setUserId(AppContext.getAccount().getUserId());
        getP().orderExchangeInfo(userOrderParam);
    }

    public void exchangeInfo(BaseModel<OrderExchangeInfoModel> result, final String orderId) {
        if (result.getData() != null) {
            ScoreChoiceDialog.Builder builder = new ScoreChoiceDialog.Builder(context)
                    .setMessage(result.getData().getText(), result.getData().getGameIntegral(),
                            result.getData().getUserPoint(), result.getData().getSelectIndex().equals("1") ? false : true)
                    .setOnSubmitClickListener(new ScoreChoiceDialog.OnSubmitClickListener() {
                        @Override
                        public void onScoreChange(DialogInterface dialog, String money, String score, boolean isMoney) {
                            if (isMoney) {
                                exchangeOrder(orderId);
                            } else {
                                userOrderChangeGameIntegral(orderId);
                            }
                            dialog.dismiss();
                        }
                    });
            builder.create().show();
        }
    }

    public void userOrderChangeGameIntegral(String orderId) {
        UserOrderParam userOrderParam = new UserOrderParam();
        userOrderParam.setOrderId(orderId);
        userOrderParam.setUserId(AppContext.getAccount().getUserId());
        getP().userOrderChangeGameIntegral(userOrderParam);
    }

    public void exchangeScoreResult(BaseModel<UserOrderModel> result) {
        if (result.getData() == null || TextUtils.isEmpty(result.getData().getPoint())) {
            toast(getString(R.string.exchange_failed));
            return;
        }
        toast(getString(R.string.exchange_success));
        Account account = AppContext.getAccount();
        account.setUserPoint(result.getData().getPoint());
        SharedPref.getInstance(context).put(Keys.ACCOUNT, account);
        AppContext.setAccount(account);
        final RecordParam recordParam = new RecordParam();
        recordParam.setUserId(AppContext.getAccount().getUserId());
        recordParam.setPage(page + "");
        recordParam.setType(getType());
        page = 1;
        getP().userGrabRecordList(true, recordParam);
    }
}
