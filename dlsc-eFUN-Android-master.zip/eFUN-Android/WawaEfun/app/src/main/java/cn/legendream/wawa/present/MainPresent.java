package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import java.util.List;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BannerModel;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.PushTokenParam;
import cn.legendream.wawa.model.ScoreShopUrlModel;
import cn.legendream.wawa.model.SignParam;
import cn.legendream.wawa.model.SignScoreModel;
import cn.legendream.wawa.model.UserMessageInfoModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.model.UserSignModel;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.MainActivity;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: MainPresent
 * @author: Samson.Sun
 * @date: 2018-1-8 23:10
 * @email: s_xin@neusoft.com
 */
public class MainPresent extends XPresent<MainActivity> {

    public void getBannerList(UserParam userParam) {
        Api.getSimpleService().getBannerList(NetUtil.createRequestBody(userParam))
                .compose(XApi.<BaseModel<List<BannerModel>>>getApiTransformer())
                .compose(XApi.<BaseModel<List<BannerModel>>>getScheduler())
                .compose(getV().<BaseModel<List<BannerModel>>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<List<BannerModel>>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<List<BannerModel>> resultModel) {
                        getV().hideProgress();
                        getV().showBanner(resultModel);
                    }
                });
    }

    public void setUserPushToken(PushTokenParam pushTokenParam) {
        Api.getSimpleService().setUserPushToken(NetUtil.createRequestBody(pushTokenParam))
                .compose(XApi.<BaseModel>getApiTransformer())
                .compose(XApi.<BaseModel>getScheduler())
                .compose(getV().<BaseModel>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel resultModel) {
                        getV().hideProgress();
                    }
                });
    }

    public void getDuiBaLoginUrl(UserParam userParam) {
        Api.getScoreService().getDuiBaLoginUrl(NetUtil.createRequestBody(userParam))
                .compose(XApi.<BaseModel<ScoreShopUrlModel>>getApiTransformer())
                .compose(XApi.<BaseModel<ScoreShopUrlModel>>getScheduler())
                .compose(getV().<BaseModel<ScoreShopUrlModel>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<ScoreShopUrlModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<ScoreShopUrlModel> resultModel) {
                        getV().hideProgress();
                        getV().showScoreShopUrl(resultModel.getData().getUrl());
                    }
                });
    }

    public void userSignView(SignParam signParam) {
        Api.getSimpleService().userSignView(NetUtil.createRequestBody(signParam))
                .compose(XApi.<BaseModel<UserSignModel>>getApiTransformer())
                .compose(XApi.<BaseModel<UserSignModel>>getScheduler())
                .compose(getV().<BaseModel<UserSignModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress(false);
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<UserSignModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<UserSignModel> resultModel) {
                        getV().hideProgress();
                        getV().showSignDialog(resultModel.getData());
                    }
                });
    }

    public void userSignIn(UserParam userParam) {
        Api.getSimpleService().userSignIn(NetUtil.createRequestBody(userParam))
                .compose(XApi.<BaseModel<SignScoreModel>>getApiTransformer())
                .compose(XApi.<BaseModel<SignScoreModel>>getScheduler())
                .compose(getV().<BaseModel<SignScoreModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress(false);
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<SignScoreModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<SignScoreModel> resultModel) {
                        getV().hideProgress();
                        getV().signSuccess(resultModel.getData().getScore(), resultModel.getData().getGameMoney());
                    }
                });
    }

}
