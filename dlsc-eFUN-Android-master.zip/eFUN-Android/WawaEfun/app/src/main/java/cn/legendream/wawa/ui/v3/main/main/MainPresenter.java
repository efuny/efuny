package cn.legendream.wawa.ui.v3.main.main;

import android.util.Log;

import org.reactivestreams.Subscription;

import java.util.List;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BannerModel;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import io.reactivex.functions.Consumer;

/**
 * Created by zhaoyuefeng on 2019/4/26.
 * Description 
 */
public class MainPresenter extends XPresent<MainFragment> {

    public void getBannerList(UserParam userParam) {

        Api.getSimpleService().getBannerList(NetUtil.createRequestBody(userParam))
                .compose(XApi.<BaseModel<List<BannerModel>>>getApiTransformer())
                .compose(XApi.<BaseModel<List<BannerModel>>>getScheduler())
                .compose(getV().<BaseModel<List<BannerModel>>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<List<BannerModel>>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<List<BannerModel>> resultModel) {

                        getV().hideProgress();
                        getV().showBanner(resultModel);
                    }
                });
    }


}
