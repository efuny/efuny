package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: MallGoodListParam
 * @author: Samson.Sun
 * @date: 2018-7-21 17:25
 * @email: s_xin@neusoft.com
 */
public class MallGoodListParam {
    public MallGoodListParam() {
    }

    private String userId;
    private String categoryId;
    private String page;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }
}
