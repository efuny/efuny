package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import java.util.List;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.ExchangeLogModel;
import cn.legendream.wawa.model.OrderInfoModel;
import cn.legendream.wawa.model.OrderInfoParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.ExchangeActivity;
import cn.legendream.wawa.ui.OrderActivity;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: OrderPresent
 * @author: Samson.Sun
 * @date: 2018-7-19 23:46
 * @email: s_xin@neusoft.com
 */
public class OrderPresent extends XPresent<OrderActivity> {
    public void orderInfo(OrderInfoParam orderInfoParam) {
        Api.getSimpleService().orderInfo(NetUtil.createRequestBody(orderInfoParam))
                .compose(XApi.<BaseModel<OrderInfoModel>>getApiTransformer())
                .compose(XApi.<BaseModel<OrderInfoModel>>getScheduler())
                .compose(getV().<BaseModel<OrderInfoModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<OrderInfoModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<OrderInfoModel> result) {
                        getV().hideProgress();
                        getV().showData(result);
                    }
                });
    }
}
