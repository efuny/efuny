package cn.legendream.wawa.ui.gamev2;

/**
 * Created by zhaoyuefeng on 2018/8/29.
 * Description
 */

public class CommandConstants {

    public static final int ENTER = 10;
    public static final int START = 11;
    public static final int DO_EXIT = 12;

    public static final int DO_DOWN = 0;
    public static final int DO_UP = 1;
    public static final int DO_LEFT = 2;
    public static final int DO_RIGHT = 3;

    public static final int DO_GRAP = 4;

    public static final int DO_STOP = 5;


}
