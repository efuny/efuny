package cn.legendream.wawa.model;

/**
 * Created by zhaoyuefeng on 2018/9/28.
 * Description
 */

public class GetExchangeOrderParam {

    private String goodId;
    private String userId;
    private String addressId;

    public String getGoodId() {
        return goodId;
    }

    public void setGoodId(String goodId) {
        this.goodId = goodId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }
}
