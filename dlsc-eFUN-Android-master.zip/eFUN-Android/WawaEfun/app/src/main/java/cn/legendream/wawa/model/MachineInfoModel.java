package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: MachineInfoModel
 * @author: Samson.Sun
 * @date: 2017-12-16 18:57
 * @email: s_xin@neusoft.com
 */
public class MachineInfoModel {
    /**
     * newMachineData : {"timeOut":"60","macAddress":"22210DF462DC","catchResult":"0","powerCatch":"48","powerOntop":"48","powerMove":"48","powerMax":"48","holdHeight":"10"}
     */

    public MachineInfoModel() {
    }

    private String machineGameMoney;
    private String userGameMoney;
    private String machineStatus;
    private String helpUrl;
    private String faceCamera;
    private String sideCamera;
    private String ipAddress;
    private String machineId;
    private DollInfo dollInfo;
    private NewMachineDataBean newMachineData;

    public String getMachineGameMoney() {
        return machineGameMoney;
    }

    public void setMachineGameMoney(String machineGameMoney) {
        this.machineGameMoney = machineGameMoney;
    }

    public String getUserGameMoney() {
        return userGameMoney;
    }

    public void setUserGameMoney(String userGameMoney) {
        this.userGameMoney = userGameMoney;
    }

    public String getMachineStatus() {
        return machineStatus;
    }

    public void setMachineStatus(String machineStatus) {
        this.machineStatus = machineStatus;
    }

    public String getHelpUrl() {
        return helpUrl;
    }

    public void setHelpUrl(String helpUrl) {
        this.helpUrl = helpUrl;
    }

    public DollInfo getDollInfo() {
        return dollInfo;
    }

    public void setDollInfo(DollInfo dollInfo) {
        this.dollInfo = dollInfo;
    }

    public String getFaceCamera() {
        return faceCamera;
    }

    public void setFaceCamera(String faceCamera) {
        this.faceCamera = faceCamera;
    }

    public String getSideCamera() {
        return sideCamera;
    }

    public void setSideCamera(String sideCamera) {
        this.sideCamera = sideCamera;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getMachineId() {
        return machineId;
    }

    public void setMachineId(String machineId) {
        this.machineId = machineId;
    }

    public NewMachineDataBean getNewMachineData() {
        return newMachineData;
    }

    public void setNewMachineData(NewMachineDataBean newMachineData) {
        this.newMachineData = newMachineData;
    }

    public static class NewMachineDataBean {
        /**
         * timeOut : 60
         * macAddress : 22210DF462DC
         * catchResult : 0
         * powerCatch : 48
         * powerOntop : 48
         * powerMove : 48
         * powerMax : 48
         * holdHeight : 10
         */

        private String macAddress;


        public String getMacAddress() {
            return macAddress;
        }

        public void setMacAddress(String macAddress) {
            this.macAddress = macAddress;
        }

    }
}
