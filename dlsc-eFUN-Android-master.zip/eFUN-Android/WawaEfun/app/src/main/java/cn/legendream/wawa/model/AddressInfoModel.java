package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: AddressInfoModel
 * @author: Samson.Sun
 * @date: 2018-1-19 13:44
 * @email: s_xin@neusoft.com
 */
public class AddressInfoModel {
    public AddressInfoModel() {
    }
    private String address;
    private String mobile;
    private String person;
    private String isDefault;
    private String addressId;
    private String expressPrice;
    private String payCreateExpressPrice;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }

    public String getExpressPrice() {
        return expressPrice;
    }

    public void setExpressPrice(String expressPrice) {
        this.expressPrice = expressPrice;
    }

    public String getPayCreateExpressPrice() {
        return payCreateExpressPrice;
    }

    public void setPayCreateExpressPrice(String payCreateExpressPrice) {
        this.payCreateExpressPrice = payCreateExpressPrice;
    }
}
