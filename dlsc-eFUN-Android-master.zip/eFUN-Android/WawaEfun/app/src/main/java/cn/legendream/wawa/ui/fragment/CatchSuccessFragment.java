package cn.legendream.wawa.ui.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;

import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xrecyclerview.RecyclerItemCallback;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.R;
import cn.legendream.wawa.adapter.CatchAdapter;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.CatchModel;
import cn.legendream.wawa.ui.CatchDetailActivity;
import cn.legendream.wawa.ui.SendBabyActivity;
import cn.legendream.wawa.ui.WebActivity;
import cn.legendream.wawa.view.ScoreDialog;

import static android.app.Activity.RESULT_OK;

/**
 * @version V1.0 <>
 * @FileName: CatchSuccessFragment
 * @author: Samson.Sun
 * @date: 2017-12-16 20:33
 * @email: s_xin@neusoft.com
 */
public class CatchSuccessFragment extends BaseCatchFragment {
    CatchAdapter adapter;

    public static CatchSuccessFragment newInstance(CatchListener catchListener) {
        catchChangedListener = catchListener;
        return new CatchSuccessFragment();
    }

    @Override
    public SimpleRecAdapter getAdapter() {
        if (adapter == null) {
            int width = Utils.getScreenWidth(getActivity());

            Log.e("borax", width + "");

            int itemWidth = (width - Utils.dip2px(getContext(), 50)) / 2;
            adapter = new CatchAdapter(context, 1, itemWidth);
            adapter.setRecItemClick(new RecyclerItemCallback<CatchModel, CatchAdapter.ViewHolder>() {
                @Override
                public void onItemClick(int position, CatchModel model, int tag, CatchAdapter.ViewHolder holder) {
                    if (!Utils.isFastClick()) {
//                        if (model.getExpressStatus().equals("0")) {
                        CatchDetailActivity.launch(context, model);
//                        }
                    }
                }
            });
            adapter.setOnSendClickListener(new CatchAdapter.OnSendClickListener() {
                @Override
                public void onSendClicked(CatchModel catchModel, int position) {
                    if (!Utils.isFastClick()) {
                        SendBabyActivity.launch(context, catchModel.getOrderId());
                    }
                }
            });
            adapter.setOnExchangeClickListener(new CatchAdapter.OnExchangeClickListener() {
                @Override
                public void onExchangeClicked(final CatchModel catchModel, int position) {
                    orderExchangeInfo(catchModel);
                }
            });
            adapter.setOnLogisticsClickListener(new CatchAdapter.OnLogisticsClickListener() {
                @Override
                public void onLogisticsClicked(CatchModel catchModel, int position) {
                    if (!Utils.isFastClick()) {
                        WebActivity.launch(context, catchModel.getExpressUrl(), getString(R.string.logistics_info));
                    }
                }
            });
        }
        return adapter;
    }

    @Override
    public void setLayoutManager(XRecyclerView recyclerView) {
        recyclerView.verticalLayoutManager(context);
    }

    @Override
    public String getType() {
        return "1";
    }

}
