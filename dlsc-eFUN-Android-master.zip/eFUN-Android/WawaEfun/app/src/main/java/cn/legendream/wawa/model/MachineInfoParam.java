package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: MachineInfoParam
 * @author: Samson.Sun
 * @date: 2017-12-16 19:01
 * @email: s_xin@neusoft.com
 */
public class MachineInfoParam {
    public MachineInfoParam() {
    }

    private String machineId;
    private String userId;

    public String getMachineId() {
        return machineId;
    }

    public void setMachineId(String machineId) {
        this.machineId = machineId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
