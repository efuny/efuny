package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: GameBeginModel
 * @author: Samson.Sun
 * @date: 2017-12-27 14:45
 * @email: s_xin@neusoft.com
 */
public class GameBeginModel {
    public GameBeginModel() {
    }

    private String gameTime;
    private String orderId;
    private String orderMsec;
    private GameControlModel gameControl;
    private NewMachineDataBean newMachineData;

    public String getGameTime() {
        return gameTime;
    }

    public void setGameTime(String gameTime) {
        this.gameTime = gameTime;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderMsec() {
        return orderMsec;
    }

    public void setOrderMsec(String orderMsec) {
        this.orderMsec = orderMsec;
    }

    public GameControlModel getGameControl() {
        return gameControl;
    }

    public void setGameControl(GameControlModel gameControl) {
        this.gameControl = gameControl;
    }

    public NewMachineDataBean getNewMachineData() {
        return newMachineData;
    }

    public void setNewMachineData(NewMachineDataBean newMachineData) {
        this.newMachineData = newMachineData;
    }

    public static class NewMachineDataBean {
        /**
         * timeOut : 60
         * macAddress : 22210DF462DC
         * catchResult : 0
         * powerCatch : 48
         * powerOntop : 48
         * powerMove : 48
         * powerMax : 48
         * holdHeight : 10
         */

        private String timeOut;
        private String macAddress;
        private String catchResult;
        private String powerCatch;
        private String powerOntop;
        private String powerMove;
        private String powerMax;
        private String holdHeight;

        public String getTimeOut() {
            return timeOut;
        }

        public void setTimeOut(String timeOut) {
            this.timeOut = timeOut;
        }

        public String getMacAddress() {
            return macAddress;
        }

        public void setMacAddress(String macAddress) {
            this.macAddress = macAddress;
        }

        public String getCatchResult() {
            return catchResult;
        }

        public void setCatchResult(String catchResult) {
            this.catchResult = catchResult;
        }

        public String getPowerCatch() {
            return powerCatch;
        }

        public void setPowerCatch(String powerCatch) {
            this.powerCatch = powerCatch;
        }

        public String getPowerOntop() {
            return powerOntop;
        }

        public void setPowerOntop(String powerOntop) {
            this.powerOntop = powerOntop;
        }

        public String getPowerMove() {
            return powerMove;
        }

        public void setPowerMove(String powerMove) {
            this.powerMove = powerMove;
        }

        public String getPowerMax() {
            return powerMax;
        }

        public void setPowerMax(String powerMax) {
            this.powerMax = powerMax;
        }

        public String getHoldHeight() {
            return holdHeight;
        }

        public void setHoldHeight(String holdHeight) {
            this.holdHeight = holdHeight;
        }
    }
}
