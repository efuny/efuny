package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: SignParam
 * @author: Samson.Sun
 * @date: 2018-5-28 23:23
 * @email: s_xin@neusoft.com
 */
public class SignParam {
    public SignParam() {
    }

    public SignParam(String userId, String test) {
        this.userId = userId;
        this.test = test;
    }

    private String userId;
    private String test;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTest() {
        return test;
    }

    public void setTest(String test) {
        this.test = test;
    }
}
