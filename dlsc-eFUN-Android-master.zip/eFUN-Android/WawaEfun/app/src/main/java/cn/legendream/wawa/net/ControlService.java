package cn.legendream.wawa.net;

import cn.legendream.wawa.model.StringModel;
import io.reactivex.Flowable;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Url;

/**
 * @version V1.0 <>
 * @FileName: ControlService
 * @author: Samson.Sun
 * @date: 2018-1-15 20:52
 * @email: s_xin@neusoft.com
 */
public interface ControlService {
    @GET
    Flowable<StringModel> doUp(@Url String url);

    @GET
    Flowable<StringModel> doDown(@Url String url);

    @GET
    Flowable<StringModel> doLeft(@Url String url);

    @GET
    Flowable<StringModel> doRight(@Url String url);

    @GET
    Flowable<StringModel> doStop(@Url String url);

    @GET
    Flowable<StringModel> doGrab(@Url String url);

}
