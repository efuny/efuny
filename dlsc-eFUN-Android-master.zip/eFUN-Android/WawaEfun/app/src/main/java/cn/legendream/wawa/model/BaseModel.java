package cn.legendream.wawa.model;

import cn.droidlover.xdroidmvp.net.IModel;

/**
 * @version V1.0 <>
 * @FileName: BaseModel
 * @author: Samson.Sun
 * @date: 2017-12-8 9:52
 * @email: s_xin@neusoft.com
 */
public class BaseModel<T> implements IModel {
    private String result;
    private String msg;
    private T data;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    @Override
    public boolean isNull() {
        return false;
    }

    @Override
    public boolean isAuthError() {
        return false;
    }

    @Override
    public boolean isBizError() {
        return false;
    }

    @Override
    public boolean isOtherError() {
        return result.equals("0");
    }

    @Override
    public String getErrorMsg() {
        return msg;
    }
}
