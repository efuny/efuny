package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.GetExchangeOrderModel;
import cn.legendream.wawa.model.GetExchangeOrderParam;
import cn.legendream.wawa.model.GetExpressPriceOrderParam;
import cn.legendream.wawa.model.MallExchangeModel;
import cn.legendream.wawa.model.MallInfoModel;
import cn.legendream.wawa.model.MallInfoParam;
import cn.legendream.wawa.model.PayCreateOrderModel;
import cn.legendream.wawa.model.PayCreateOrderParam;
import cn.legendream.wawa.model.UserGoodParam;
import cn.legendream.wawa.model.WxPayOrderModel;
import cn.legendream.wawa.model.WxPayOrderParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.GoodDetailActivity;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: GoodDetailPresent
 * @author: Samson.Sun
 * @date: 2018-7-13 23:53
 * @email: s_xin@neusoft.com
 */
public class GoodDetailPresent extends XPresent<GoodDetailActivity> {

    public void getMallInfo(MallInfoParam mallInfoParam) {
        Api.getSimpleService().getMallInfo(NetUtil.createRequestBody(mallInfoParam))
                .compose(XApi.<BaseModel<MallInfoModel>>getApiTransformer())
                .compose(XApi.<BaseModel<MallInfoModel>>getScheduler())
                .compose(getV().<BaseModel<MallInfoModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<MallInfoModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<MallInfoModel> result) {
                        getV().hideProgress();
                        getV().showData(result);
                    }
                });
    }

    public void mallExchange(UserGoodParam userGoodParam) {
        Api.getSimpleService().mallExchange(NetUtil.createRequestBody(userGoodParam))
                .compose(XApi.<BaseModel<MallExchangeModel>>getApiTransformer())
                .compose(XApi.<BaseModel<MallExchangeModel>>getScheduler())
                .compose(getV().<BaseModel<MallExchangeModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<MallExchangeModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<MallExchangeModel> result) {
                        getV().hideProgress();
                        getV().exchangeResult(result);
                    }
                });
    }

    public void aliPayCreateOrder(PayCreateOrderParam payCreateOrderParam) {
        Api.getSimpleService().aliPayCreateOrder(NetUtil.createRequestBody(payCreateOrderParam))
                .compose(XApi.<BaseModel<PayCreateOrderModel>>getApiTransformer())
                .compose(XApi.<BaseModel<PayCreateOrderModel>>getScheduler())
                .compose(getV().<BaseModel<PayCreateOrderModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<PayCreateOrderModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<PayCreateOrderModel> result) {
                        getV().hideProgress();
                        getV().alipayOrder(result);
                    }
                });
    }

    public void wxPayCreateOrder(WxPayOrderParam wxPayOrderParam) {
        Api.getSimpleService().wxPayCreateOrder(NetUtil.createRequestBody(wxPayOrderParam))
                .compose(XApi.<BaseModel<WxPayOrderModel>>getApiTransformer())
                .compose(XApi.<BaseModel<WxPayOrderModel>>getScheduler())
                .compose(getV().<BaseModel<WxPayOrderModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<WxPayOrderModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<WxPayOrderModel> result) {
                        getV().hideProgress();
                        getV().wechatOrder(result);
                    }
                });
    }

    public void getExchangeOrder(GetExchangeOrderParam getExchangeOrderParam) {

        Api.getSimpleService().getExchangeOrder(NetUtil.createRequestBody(getExchangeOrderParam))
                .compose(XApi.<BaseModel<GetExchangeOrderModel>>getApiTransformer())
                .compose(XApi.<BaseModel<GetExchangeOrderModel>>getScheduler())
                .compose(getV().<BaseModel<GetExchangeOrderModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<GetExchangeOrderModel>>() {
                    @Override
                    protected void onFail(NetError error) {

                    }

                    @Override
                    public void onNext(BaseModel<GetExchangeOrderModel> getExchangeOrderModelBaseModel) {
                        getV().hideProgress();
                        getV().getExchangeOrderResult(getExchangeOrderModelBaseModel);
                    }
                });
    }

    public void getExchangeWxPayCreateOrder(GetExpressPriceOrderParam getExpressPriceOrderParam) {

        Api.getSimpleService().wxPayCreateExchangeOrder(NetUtil.createRequestBody(getExpressPriceOrderParam))
                .compose(XApi.<BaseModel<WxPayOrderModel>>getApiTransformer())
                .compose(XApi.<BaseModel<WxPayOrderModel>>getScheduler())
                .compose(getV().<BaseModel<WxPayOrderModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                }).subscribe(new ApiSubscriber<BaseModel<WxPayOrderModel>>() {
            @Override
            protected void onFail(NetError error) {

            }

            @Override
            public void onNext(BaseModel<WxPayOrderModel> wxPayOrderModelBaseModel) {
                getV().hideProgress();
                getV().wechatOrder(wxPayOrderModelBaseModel);
            }
        });
    }

    public void getExchangeAliPayCreateOrder(GetExpressPriceOrderParam getExpressPriceOrderParam) {

        Api.getSimpleService().aliPayCreateExchangeOrder(NetUtil.createRequestBody(getExpressPriceOrderParam))
                .compose(XApi.<BaseModel<PayCreateOrderModel>>getApiTransformer())
                .compose(XApi.<BaseModel<PayCreateOrderModel>>getScheduler())
                .compose(getV().<BaseModel<PayCreateOrderModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                }).subscribe(new ApiSubscriber<BaseModel<PayCreateOrderModel>>() {
            @Override
            protected void onFail(NetError error) {

            }

            @Override
            public void onNext(BaseModel<PayCreateOrderModel> payCreateOrderModelBaseModel) {
                getV().hideProgress();
                getV().alipayOrder(payCreateOrderModelBaseModel);
            }
        });
    }

}
