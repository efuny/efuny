package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: SignScoreModel
 * @author: Samson.Sun
 * @date: 2018-5-24 0:05
 * @email: s_xin@neusoft.com
 */
public class SignScoreModel {
    private String score;
    private String gameMoney;

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getGameMoney() {
        return gameMoney;
    }

    public void setGameMoney(String gameMoney) {
        this.gameMoney = gameMoney;
    }
}
