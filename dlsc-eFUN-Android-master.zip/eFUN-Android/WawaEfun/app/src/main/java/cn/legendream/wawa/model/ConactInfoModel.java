package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: ConactInfoModel
 * @author: Samson.Sun
 * @date: 2017-12-21 8:42
 * @email: s_xin@neusoft.com
 */
public class ConactInfoModel {
    public ConactInfoModel() {
    }
    private String weibo;
    private String wchat;

    public String getWeibo() {
        return weibo;
    }

    public void setWeibo(String weibo) {
        this.weibo = weibo;
    }

    public String getWchat() {
        return wchat;
    }

    public void setWchat(String wchat) {
        this.wchat = wchat;
    }
}
