package cn.legendream.wawa.model;

import java.util.List;

/**
 * @version V1.0 <>
 * @FileName: ScoreModel
 * @author: Samson.Sun
 * @date: 2017-12-20 16:29
 * @email: s_xin@neusoft.com
 */
public class ScoreModel {
    public ScoreModel() {
    }

    private String userPoint;
    private String helpUrl;
    private List<Score> pointRecordList;

    public String getUserPoint() {
        return userPoint;
    }

    public void setUserPoint(String userPoint) {
        this.userPoint = userPoint;
    }

    public String getHelpUrl() {
        return helpUrl;
    }

    public void setHelpUrl(String helpUrl) {
        this.helpUrl = helpUrl;
    }

    public List<Score> getPointRecordList() {
        return pointRecordList;
    }

    public void setPointRecordList(List<Score> pointRecordList) {
        this.pointRecordList = pointRecordList;
    }
}
