package cn.legendream.wawa.view;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;

/**
 * @version V1.0 <>
 * @FileName: ScoreDialog
 * @author: Samson.Sun
 * @date: 2017-12-28 22:42
 * @email: s_xin@neusoft.com
 */
public class ScoreDialog extends Dialog {
    public ScoreDialog(@NonNull Context context) {
        super(context);
    }

    public interface OnSubmitClickListener {
        void onScoreChange(DialogInterface dialog, String score);
    }

    public ScoreDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    public static class Builder {
        private Context context;
        private String name;
        private String score;
        private OnSubmitClickListener onSubmitClickListener;

        public Builder(Context context) {
            this.context = context;
        }

        public Builder setMessage(String name, String score) {
            this.name = name;
            this.score = score;
            return this;
        }

        public Builder setOnSubmitClickListener(OnSubmitClickListener onSubmitClickListener) {
            this.onSubmitClickListener = onSubmitClickListener;
            return this;
        }

        public ScoreDialog create() {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final ScoreDialog dialog = new ScoreDialog(context, R.style.Dialog);
            View layout = inflater.inflate(R.layout.dialog_score, null);
            TextView tv_content = layout.findViewById(R.id.tv_content);
            Button negativeButton = layout.findViewById(R.id.negativeButton);
            negativeButton.setTypeface(Utils.getGoTrialFont(context));
            String content = context.getResources().getString(R.string.dialog_sure_use)
                    + "<font color='#FF7F7D'>" + name + "</font>"
                    + context.getResources().getString(R.string.exchange)
                    + "<font color='#FF7F7D'>" + score + "</font>"
                    + context.getResources().getString(R.string.dialog_score);
            tv_content.setText(Html.fromHtml(content));
            negativeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onSubmitClickListener.onScoreChange(dialog, score);
                }
            });
            dialog.setContentView(layout);
            return dialog;
        }
    }
}
