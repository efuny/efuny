package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: WxPayOrderParam
 * @author: Samson.Sun
 * @date: 2018-1-20 0:31
 * @email: s_xin@neusoft.com
 */
public class WxPayOrderParam {
    public WxPayOrderParam() {
    }

    private String orderNumber;
    private String deviceInfo;

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getDeviceInfo() {
        return deviceInfo;
    }

    public void setDeviceInfo(String deviceInfo) {
        this.deviceInfo = deviceInfo;
    }
}
