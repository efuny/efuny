package cn.legendream.wawa.present;

import java.util.List;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.GoodsModel;
import cn.legendream.wawa.model.GoodsModel;
import cn.legendream.wawa.model.MallGoodListParam;
import cn.legendream.wawa.model.UserRechargeOrderParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.GoodsListActivity;

/**
 * @version V1.0 <>
 * @FileName: GoodsListPresent
 * @author: Samson.Sun
 * @date: 2018-7-9 23:35
 * @email: s_xin@neusoft.com
 */
public class GoodsListPresent extends XPresent<GoodsListActivity> {

    public void getMallGoodList(final boolean isRefresh, MallGoodListParam mallGoodListParam) {
        Api.getSimpleService().getMallGoodList(NetUtil.createRequestBody(mallGoodListParam))
                .compose(XApi.<BaseModel<List<GoodsModel>>>getApiTransformer())
                .compose(XApi.<BaseModel<List<GoodsModel>>>getScheduler())
                .compose(getV().<BaseModel<List<GoodsModel>>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<List<GoodsModel>>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<List<GoodsModel>> result) {
                        getV().showData(isRefresh, result);
                    }
                });
    }
}
