package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: SignModel
 * @author: Samson.Sun
 * @date: 2018-5-22 15:41
 * @email: s_xin@neusoft.com
 */
public class SignModel {
    private String day;
    private String isSignIn;
    private String score;
    private String gameMoney;

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getIsSignIn() {
        return isSignIn;
    }

    public void setIsSignIn(String isSignIn) {
        this.isSignIn = isSignIn;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getGameMoney() {
        return gameMoney;
    }

    public void setGameMoney(String gameMoney) {
        this.gameMoney = gameMoney;
    }
}
