package cn.legendream.wawa.ui.v3.mine.share;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.shareboard.SnsPlatform;
import com.umeng.socialize.utils.ShareBoardlistener;

import java.lang.ref.WeakReference;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.log.XLog;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.InvitationCodeModel;
import cn.legendream.wawa.model.InviteParam;
import cn.legendream.wawa.model.ShareInfoModel;
import cn.legendream.wawa.model.ShareInfoParam;

public class ShareActivity extends XActivity<SharePresenter> {

    @BindView(R.id.id_rl)
    RelativeLayout idRl;
    @BindView(R.id.name_tv)
    TextView nameTv;
    @BindView(R.id.num_tv)
    TextView numTv;
    @BindView(R.id.code_tv)
    TextView codeTv;
    @BindView(R.id.share_rl)
    RelativeLayout shareRl;
    @BindView(R.id.code_iv)
    ImageView codeIv;
    @BindView(R.id.back_iv)
    ImageView backIv;
    @BindView(R.id.share_code_ll)
    LinearLayout shareCodeLl;
    @BindView(R.id.container_rl)
    RelativeLayout containerRl;

    private UMShareListener mShareListener;
    private ShareAction mShareAction;

    private String shareGold;
    private String shareCodeStr;

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(ShareActivity.class)
                .launch();
    }

    @Override
    public void initData(Bundle savedInstanceState) {

        nameTv.setText("「" + AppContext.getAccount().getNickName() + "」");

        InviteParam inviteParam = new InviteParam();
        inviteParam.setUserId(AppContext.getAccount().getUserId());
        getP().getUserInvitationCode(inviteParam);
        getP().getShareInfo(new ShareInfoParam(AppContext.getAccount().getUserId()));


    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_share;
    }

    @Override
    public SharePresenter newP() {
        return new SharePresenter();
    }


    public void showCode(BaseModel<InvitationCodeModel> result) {

        shareGold = result.getData().getCodePoint();
        shareCodeStr = result.getData().getCode();

        numTv.setText(shareGold);
        codeTv.setText(shareCodeStr);

    }

    public void showShareInfo(BaseModel<ShareInfoModel> result) {

        String codeUrl = result.getData().getCodeUrl();
        Glide.with(context).load(codeUrl).into(codeIv);

    }

    @OnClick({R.id.share_code_ll, R.id.back_iv})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.share_code_ll: {

                doShare();

                break;
            }
            case R.id.back_iv: {
                onBackPressed();
                break;
            }
        }
    }

    private void doShare() {

        containerRl.buildDrawingCache();

        final Bitmap bitmap = containerRl.getDrawingCache();

        mShareListener = new CustomShareListener(this);
        /*增加自定义按钮的分享面板*/
        mShareAction = new ShareAction(context).setDisplayList(
                SHARE_MEDIA.WEIXIN, SHARE_MEDIA.WEIXIN_CIRCLE, SHARE_MEDIA.WEIXIN_FAVORITE,
                SHARE_MEDIA.SINA, SHARE_MEDIA.QQ, SHARE_MEDIA.QZONE)
                .setShareboardclickCallback(new ShareBoardlistener() {
                    @Override
                    public void onclick(SnsPlatform snsPlatform, SHARE_MEDIA share_media) {
                        UMImage umImage = new UMImage(context, bitmap);
                        umImage.setTitle(Utils.formatStrings(context, R.string.share_title, shareGold));
                        umImage.setDescription(Utils.formatStrings(context, R.string.share_content, shareCodeStr));
                        umImage.compressFormat = Bitmap.CompressFormat.PNG;
                        new ShareAction(context)
                                .withMedia(umImage)
                                .setPlatform(share_media)
                                .setCallback(mShareListener)
                                .share();
                    }
                });
        mShareAction.open();

    }

    private static class CustomShareListener implements UMShareListener {

        private WeakReference<ShareActivity> mActivity;

        private CustomShareListener(ShareActivity activity) {
            mActivity = new WeakReference(activity);
        }

        @Override
        public void onStart(SHARE_MEDIA platform) {

        }

        @Override
        public void onResult(SHARE_MEDIA platform) {
            if (platform.name().equals("WEIXIN_FAVORITE")) {
                Toast.makeText(mActivity.get(), platform + " 收藏成功啦", Toast.LENGTH_SHORT).show();
            } else {
                if (platform != SHARE_MEDIA.MORE && platform != SHARE_MEDIA.SMS
                        && platform != SHARE_MEDIA.EMAIL
                        && platform != SHARE_MEDIA.FLICKR
                        && platform != SHARE_MEDIA.FOURSQUARE
                        && platform != SHARE_MEDIA.TUMBLR
                        && platform != SHARE_MEDIA.POCKET
                        && platform != SHARE_MEDIA.PINTEREST

                        && platform != SHARE_MEDIA.INSTAGRAM
                        && platform != SHARE_MEDIA.GOOGLEPLUS
                        && platform != SHARE_MEDIA.YNOTE
                        && platform != SHARE_MEDIA.EVERNOTE) {
                    Toast.makeText(mActivity.get(), " 分享成功啦", Toast.LENGTH_SHORT).show();
                }
            }
        }

        @Override
        public void onError(SHARE_MEDIA platform, Throwable throwable) {
            if (platform != SHARE_MEDIA.MORE && platform != SHARE_MEDIA.SMS
                    && platform != SHARE_MEDIA.EMAIL
                    && platform != SHARE_MEDIA.FLICKR
                    && platform != SHARE_MEDIA.FOURSQUARE
                    && platform != SHARE_MEDIA.TUMBLR
                    && platform != SHARE_MEDIA.POCKET
                    && platform != SHARE_MEDIA.PINTEREST

                    && platform != SHARE_MEDIA.INSTAGRAM
                    && platform != SHARE_MEDIA.GOOGLEPLUS
                    && platform != SHARE_MEDIA.YNOTE
                    && platform != SHARE_MEDIA.EVERNOTE) {
                Toast.makeText(mActivity.get(), " 分享失败啦", Toast.LENGTH_SHORT).show();
                if (throwable != null) {
                    XLog.d("throw", "throw:" + throwable.getMessage());
                }
            }
        }

        @Override
        public void onCancel(SHARE_MEDIA platform) {
            Toast.makeText(mActivity.get(), " 分享取消了", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        /** attention to this below ,must add this**/
        UMShareAPI.get(this).onActivityResult(requestCode, resultCode, data);
    }

}
