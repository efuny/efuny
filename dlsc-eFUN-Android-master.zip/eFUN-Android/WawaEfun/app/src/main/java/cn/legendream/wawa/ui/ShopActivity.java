package cn.legendream.wawa.ui;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.joooonho.SelectableRoundedImageView;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.listener.OnBannerListener;
import com.youth.banner.loader.ImageLoader;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.droidlover.xdroidmvp.view.refreshlayout.SmartRefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.MaterialHeader;
import cn.droidlover.xrecyclerview.RecyclerItemCallback;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.adapter.GoodsAdapter;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.Account;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.CategoryModel;
import cn.legendream.wawa.model.GoodsModel;
import cn.legendream.wawa.model.MallHomeModel;
import cn.legendream.wawa.model.PopularModel;
import cn.legendream.wawa.model.ScoreBannerModel;
import cn.legendream.wawa.model.UserInfoModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.present.ScoreShopPresent;

/**
 * @version V1.0 <>
 * @FileName: ShopActivity
 * @author: Samson.Sun
 * @date: 2018-7-17 22:09
 * @email: s_xin@neusoft.com
 */
public class ShopActivity extends XActivity<ScoreShopPresent> {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.toolbar_title)
    TextView toolbar_title;
    View layout_top;
    TextView tv_score_value;
    @BindView(R.id.rv_list)
    XRecyclerView rv_list;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    Banner banner;
    View layout_left;
    View layout_right_top;
    View layout_right_bottom;
    View layout_right;
    View layout_choice;
    SelectableRoundedImageView iv_left;
    SelectableRoundedImageView iv_right_top;
    SelectableRoundedImageView iv_right_bottom;
    View layout_wawa;
    View layout_perimeter;
    View layout_life_thing;
    View layout_machine_product;
    View layout_food;
    ImageView iv_wawa;
    ImageView iv_perimeter;
    ImageView iv_life_thing;
    ImageView iv_machine_product;
    ImageView iv_food;
    TextView tv_wawa;
    TextView tv_perimeter;
    TextView tv_life_thing;
    TextView tv_machine_product;
    TextView tv_food;
    TextView tv_name1;
    TextView tv_name2;
    TextView tv_name3;
    private GoodsAdapter mAdapter;
    private List<GoodsModel> goodsModelList;
    private List<CategoryModel> categoryModelList;
    private List<PopularModel> popularList;
    private List<ScoreBannerModel> bannerModels;
    private UserInfoModel userInfo;

    public static final String PARAM_URL = "param_url";
    public static final String PARAM_TITLE = "param_title";
    private String url;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar)
                .statusBarDarkFont(true, 0.2f).init();
    }

    public static void launch(Activity activity, String url, String title) {
        Router.newIntent(activity)
                .to(ShopActivity.class)
                .putString(PARAM_URL, url)
                .putString(PARAM_TITLE, title)
                .launch();
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_score_shop;
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        url = getIntent().getStringExtra(PARAM_URL);
        toolbar_title.setText(getIntent().getStringExtra(PARAM_TITLE));
        initAdapter();
        refreshLayout.setRefreshHeader(new MaterialHeader(context).setShowBezierWave(false));
        refreshLayout.autoRefresh();
        setLayoutParam();
        getP().getMallHome(new UserParam(AppContext.getAccount().getUserId()));
    }

    private void setLayoutParam() {
        View v = LayoutInflater.from(this).inflate(R.layout.content_score_shop, null);
        layout_left = v.findViewById(R.id.layout_left);
        layout_right_top = v.findViewById(R.id.layout_right_top);
        layout_right_bottom = v.findViewById(R.id.layout_right_bottom);
        layout_right = v.findViewById(R.id.layout_right);
        iv_left = v.findViewById(R.id.iv_left);
        iv_right_top = v.findViewById(R.id.iv_right_top);
        iv_right_bottom = v.findViewById(R.id.iv_right_bottom);
        tv_name1 = v.findViewById(R.id.tv_name1);
        tv_name2 = v.findViewById(R.id.tv_name2);
        tv_name3 = v.findViewById(R.id.tv_name3);
        layout_choice = v.findViewById(R.id.layout_choice);
        tv_score_value = v.findViewById(R.id.tv_score_value);
        tv_score_value.setText(AppContext.getAccount().getUserPoint());
        banner = v.findViewById(R.id.banner);
        layout_wawa = v.findViewById(R.id.layout_wawa);
        layout_perimeter = v.findViewById(R.id.layout_perimeter);
        layout_life_thing = v.findViewById(R.id.layout_life_thing);
        layout_machine_product = v.findViewById(R.id.layout_machine_product);
        layout_food = v.findViewById(R.id.layout_food);
        iv_wawa = v.findViewById(R.id.iv_wawa);
        iv_perimeter = v.findViewById(R.id.iv_perimeter);
        iv_life_thing = v.findViewById(R.id.iv_life_thing);
        iv_machine_product = v.findViewById(R.id.iv_machine_product);
        iv_food = v.findViewById(R.id.iv_food);
        tv_wawa = v.findViewById(R.id.tv_wawa);
        tv_perimeter = v.findViewById(R.id.tv_perimeter);
        tv_life_thing = v.findViewById(R.id.tv_life_thing);
        tv_machine_product = v.findViewById(R.id.tv_machine_product);
        tv_food = v.findViewById(R.id.tv_food);
        layout_top = v.findViewById(R.id.layout_top);
        View layout_history = v.findViewById(R.id.layout_history);
        layout_history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ExchangeActivity.launch(context);
            }
        });
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        int fullWidth = wm.getDefaultDisplay().getWidth();
        int width = fullWidth / 2 - Kits.Dimens.dpToPxInt(context, 15);
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) layout_left.getLayoutParams();
        layoutParams.width = width;
        layoutParams.height = width;
        RelativeLayout.LayoutParams leftLayoutParams = (RelativeLayout.LayoutParams) iv_left.getLayoutParams();
        int leftWith = width - Kits.Dimens.dpToPxInt(context, 30);
        leftLayoutParams.width = leftWith;
        leftLayoutParams.height = (int) (leftWith * 0.56);
        LinearLayout.LayoutParams layoutRightLayoutParams = (LinearLayout.LayoutParams) layout_right.getLayoutParams();
        layoutRightLayoutParams.width = width;
        layoutRightLayoutParams.height = width;
        RelativeLayout.LayoutParams layoutParams1 = (RelativeLayout.LayoutParams) iv_right_top.getLayoutParams();
        int widthImage = width / 2 - Kits.Dimens.dpToPxInt(context, 20);
        layoutParams1.width = widthImage;
        layoutParams1.height = widthImage;
        RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) iv_right_bottom.getLayoutParams();
        layoutParams2.width = widthImage;
        layoutParams2.height = widthImage;
        LinearLayout.LayoutParams layoutParams3 = (LinearLayout.LayoutParams) layout_choice.getLayoutParams();
        layoutParams3.width = fullWidth;
        layoutParams3.height = width + Kits.Dimens.dpToPxInt(context, 24);

        //设置图片加载器
        banner.setImageLoader(new GlideImageLoader());
        banner.setIndicatorGravity(BannerConfig.CENTER);
        banner.isAutoPlay(true);
        banner.setDelayTime(5000);
        //banner设置方法全部调用完毕时最后调用
        banner.start();
        banner.setOnBannerListener(new OnBannerListener() {
            @Override
            public void OnBannerClick(int position) {
                if (Kits.Empty.check(bannerModels)) {
                    return;
                }
                if (!Utils.isFastClick()) {
                    ScoreBannerModel scoreBannerModel = bannerModels.get(position);
                    if (null != scoreBannerModel) {
                        GoodDetailActivity.launch(context, scoreBannerModel.getGoodId(), "", scoreBannerModel == null ? "0" : scoreBannerModel.getGoodType());
                    }
                }
            }
        });
        rv_list.addHeaderView(layout_top);
    }

    public class GlideImageLoader extends ImageLoader {
        @Override
        public void displayImage(Context context, Object path, ImageView imageView) {
            ILFactory.getLoader().loadNet(imageView, (String) path, null);
        }
    }

    @Override
    public ScoreShopPresent newP() {
        return new ScoreShopPresent();
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    private void initAdapter() {
        goodsModelList = new ArrayList<>();
        categoryModelList = new ArrayList<>();
        popularList = new ArrayList<>();
        mAdapter = new GoodsAdapter(context);
        rv_list.noDivider();
        rv_list.setItemAnimator(new DefaultItemAnimator());
        rv_list.gridLayoutManager(context, 2);
        rv_list.setAdapter(mAdapter);
        mAdapter.setRecItemClick(new RecyclerItemCallback<GoodsModel, GoodsAdapter.ViewHolder>() {
            @Override
            public void onItemClick(int position, GoodsModel model, int tag, GoodsAdapter.ViewHolder holder) {
                if (!Utils.isFastClick()) {
                    GoodDetailActivity.launch(context, model.getGoodId(), model.getGoodName(), model.getGoodType());
                }
            }
        });
    }

    public void showData(BaseModel<MallHomeModel> result) {
        if (result.getData() == null) {
            finish();
        } else {
            goodsModelList = result.getData().getGoodList();
            refreshLayout.finishRefresh();
            mAdapter.setData(goodsModelList);
            showBanner(result.getData().getBannerList());
            categoryModelList = result.getData().getCategoryList();
            popularList = result.getData().getPopularList();
            userInfo = result.getData().getUserInfo();
            setCategory();
            setPopular();
            Account account = AppContext.getAccount();
            account.setUserPoint(userInfo.getUserPoint());
            SharedPref.getInstance(context).put(Keys.ACCOUNT, account);
            AppContext.setAccount(account);
            tv_score_value.setText(userInfo.getUserPoint());
        }
    }

    private void setCategory() {
        if (categoryModelList.size() >= 5) {
            final TextView[] tvCategorys = new TextView[]{tv_wawa, tv_perimeter, tv_life_thing, tv_machine_product, tv_food};
            final ImageView[] ivCategorys = new ImageView[]{iv_wawa, iv_perimeter, iv_life_thing, iv_machine_product, iv_food};
            View[] vCategorys = new View[]{layout_wawa, layout_perimeter, layout_life_thing, layout_machine_product, layout_food};
            for (int i = 0; i < tvCategorys.length; i++) {
                final int finalI = i;
                ILFactory.getLoader().loadNet(ivCategorys[finalI], categoryModelList.get(i).getCategoryImage(), null);
                tvCategorys[i].setText(categoryModelList.get(i).getCategoryName());
                vCategorys[i].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        GoodsListActivity.launch(context, categoryModelList.get(finalI).getCategoryId());
                    }
                });
            }
        }
    }

    private void setPopular() {
        if (popularList.size() >= 3) {
            tv_name1.setText(popularList.get(0).getGoodName());
            tv_name2.setText(popularList.get(1).getGoodName());
            tv_name3.setText(popularList.get(2).getGoodName());

            ILFactory.getLoader().loadNet(iv_left, popularList.get(0).getGoodImageUrl(), null);
            ILFactory.getLoader().loadNet(iv_right_top, popularList.get(1).getGoodImageUrl(), null);
            ILFactory.getLoader().loadNet(iv_right_bottom, popularList.get(2).getGoodImageUrl(), null);
            layout_left.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    GoodDetailActivity.launch(context, popularList.get(0).getGoodId(), popularList.get(0).getGoodName(), popularList.get(0).getGoodType());
                }
            });
            iv_left.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    GoodDetailActivity.launch(context, popularList.get(0).getGoodId(), popularList.get(0).getGoodName(), popularList.get(0).getGoodType());
                }
            });
            layout_right_top.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    GoodDetailActivity.launch(context, popularList.get(1).getGoodId(), popularList.get(1).getGoodName(), popularList.get(1).getGoodType());
                }
            });
            iv_right_top.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    GoodDetailActivity.launch(context, popularList.get(1).getGoodId(), popularList.get(1).getGoodName(), popularList.get(1).getGoodType());
                }
            });
            layout_right_bottom.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    GoodDetailActivity.launch(context, popularList.get(2).getGoodId(), popularList.get(2).getGoodName(), popularList.get(2).getGoodType());
                }
            });
            iv_right_bottom.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    GoodDetailActivity.launch(context, popularList.get(2).getGoodId(), popularList.get(2).getGoodName(), popularList.get(2).getGoodType());
                }
            });
        }
    }

    public void showBanner(List<ScoreBannerModel> resultModel) {
        List<String> images = new ArrayList<>();
        bannerModels = new ArrayList<>();
        bannerModels.addAll(resultModel);
        for (int i = 0; i < resultModel.size(); i++) {
            images.add(resultModel.get(i).getImageUrl());
        }
        //设置图片集合
        banner.update(images);
    }
}
