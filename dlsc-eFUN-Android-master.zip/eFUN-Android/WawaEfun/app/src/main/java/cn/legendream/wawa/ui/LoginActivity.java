package cn.legendream.wawa.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.bugly.crashreport.CrashReport;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.utils.SocializeUtils;

import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.log.XLog;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Constants;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.Account;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.LoginParam;
import cn.legendream.wawa.model.LoginResult;
import cn.legendream.wawa.model.TestLoginParam;
import cn.legendream.wawa.model.TestLoginResult;
import cn.legendream.wawa.present.LoginPresent;
import cn.legendream.wawa.ui.v3.main.MainContainerActivity;
import cn.legendream.wawa.view.LoginDialog;

/**
 * @version V1.0 <>
 * @FileName: LoginActivity
 * @author: Samson.Sun
 * @date: 2017-12-6 11:09
 * @email: s_xin@neusoft.com
 */
public class LoginActivity extends XActivity<LoginPresent> {
    @BindView(R.id.btn_login)
    Button btn_login;
    @BindView(R.id.tv_tourist_login)
    TextView tv_tourist_login;
    @BindView(R.id.tv_efun)
    TextView tv_efun;
    private ProgressDialog dialog;
    private String agreementUrl;

    @Override
    public void initData(Bundle savedInstanceState) {
        tv_efun.setTypeface(Utils.getGoTrialFont(context));
        dialog = new ProgressDialog(context);
        getP().getTestLogin();
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_login;
    }

    @Override
    public LoginPresent newP() {
        return new LoginPresent();
    }

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(LoginActivity.class)
                .launch();
    }

    @OnClick(R.id.btn_login)
    void login() {
        startWeChat();
    }

    private void startWeChat() {
        UMShareAPI.get(this).doOauthVerify(this, SHARE_MEDIA.WEIXIN, authListener);
    }


    public void showData(BaseModel<LoginResult> loginResult) {
        if (!Utils.isFastClick()) {
            if (TextUtils.isEmpty(loginResult.getData().getUserId())) {
                toast("userId为空，请重新登录");
                CrashReport.postCatchedException(new NullPointerException("数据库返回userId为空"));
                return;
            }
            Account account = new Account();
            if (TextUtils.isEmpty(loginResult.getData().getNickName())) {
                CrashReport.postCatchedException(new NullPointerException("登陆返回nickName为空"));
                account.setNickName("");
            } else {
                account.setNickName(loginResult.getData().getNickName());
            }

            if (TextUtils.isEmpty(loginResult.getData().getHeadUrl())) {
                CrashReport.postCatchedException(new NullPointerException("登陆返回headUrl为空"));
                account.setHeadUrl("");
            } else {
                account.setHeadUrl(loginResult.getData().getHeadUrl());
            }
            account.setGameMoney(loginResult.getData().getGameMoney());
            account.setUserId(loginResult.getData().getUserId());
            SharedPref.getInstance(context).put(Keys.ACCOUNT, account);
            SharedPref.getInstance(context).putBoolean(Keys.IS_LOGIN, true);
            AppContext.setAccount(account);
            MainContainerActivity.launch(context);
            finish();
        }
    }

    UMAuthListener authListener = new UMAuthListener() {
        /**
         * @desc 授权开始的回调
         * @param platform 平台名称
         */
        @Override
        public void onStart(SHARE_MEDIA platform) {
            SocializeUtils.safeShowDialog(dialog);
        }

        /**
         * @desc 授权成功的回调
         * @param platform 平台名称
         * @param action 行为序号，开发者用不上
         * @param data 用户资料返回
         */
        @Override
        public void onComplete(SHARE_MEDIA platform, int action, Map<String, String> data) {
            SocializeUtils.safeCloseDialog(dialog);
            /*for (Map.Entry<String, String> entry : data.entrySet()) {
                XLog.d("TAG===",entry.getKey()+":" + entry.getValue());
            }*/
            Toast.makeText(context, "授权成功", Toast.LENGTH_LONG).show();
            UMShareAPI.get(context).getPlatformInfo(context, SHARE_MEDIA.WEIXIN, authInfoListener);
        }

        /**
         * @desc 授权失败的回调
         * @param platform 平台名称
         * @param action 行为序号，开发者用不上
         * @param t 错误原因
         */
        @Override
        public void onError(SHARE_MEDIA platform, int action, Throwable t) {
            SocializeUtils.safeCloseDialog(dialog);
            Toast.makeText(context, "授权失败" + t.getMessage(), Toast.LENGTH_LONG).show();
        }

        /**
         * @desc 授权取消的回调
         * @param platform 平台名称
         * @param action 行为序号，开发者用不上
         */
        @Override
        public void onCancel(SHARE_MEDIA platform, int action) {
            SocializeUtils.safeCloseDialog(dialog);
            Toast.makeText(context, "取消了", Toast.LENGTH_LONG).show();
        }
    };

    UMAuthListener authInfoListener = new UMAuthListener() {
        @Override
        public void onStart(SHARE_MEDIA platform) {

        }

        @Override
        public void onComplete(SHARE_MEDIA platform, int action, Map<String, String> data) {
            if (!TextUtils.isEmpty(data.get("unionid"))) {
                LoginParam loginParam = new LoginParam();
                loginParam.setHeadUrl(data.get("iconurl").trim());
                loginParam.setNickName(data.get("name").trim());
                loginParam.setGender(data.get("gender").trim());
                loginParam.setUnionId(data.get("unionid").trim());
                getP().doLogin(loginParam);
            }
        }

        @Override
        public void onError(SHARE_MEDIA platform, int action, Throwable t) {
            Toast.makeText(context, "错误" + t.getMessage(), Toast.LENGTH_LONG).show();
        }

        @Override
        public void onCancel(SHARE_MEDIA platform, int action) {

        }
    };

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareAPI.get(this).onActivityResult(requestCode, resultCode, data);
    }

    public void showTestResult(BaseModel<TestLoginResult> testLoginResult) {
        if (testLoginResult.getData().getTestLogin().equals(Keys.TEST_LOGIN_SHOW)) {
            tv_tourist_login.setVisibility(View.VISIBLE);
        } else {
            tv_tourist_login.setVisibility(View.GONE);
        }
        if (testLoginResult.getData().getWx().equals(Keys.TEST_LOGIN_SHOW)) {
            btn_login.setVisibility(View.VISIBLE);
        } else {
            btn_login.setVisibility(View.GONE);
        }
        agreementUrl = testLoginResult.getData().getAgreementUrl();
    }

    @OnClick(R.id.tv_efun)
    public void agreementClick() {
        if (!Utils.isFastClick()) {
            WebActivity.launch(context, agreementUrl, getResources().getString(R.string.efun_service));
        }
    }

    @OnClick(R.id.tv_tourist_login)
    public void touristLogin() {
        LoginDialog.Builder builder = new LoginDialog
                .Builder(this)
                .setOnLoginClickListener(
                        new LoginDialog.OnLoginClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, String userName, String password) {
                                if (Kits.Empty.check(userName) || Kits.Empty.check(password)) {
                                    toast(R.string.input_username);
                                    return;
                                }
                                TestLoginParam testLoginParam = new TestLoginParam();
                                testLoginParam.setUsername(userName);
                                testLoginParam.setPassword(password);
                                getP().testLogin(testLoginParam);
                                dialog.dismiss();
                            }
                        }
                );
        builder.create().show();
    }
}
