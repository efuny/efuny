package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: PayCreateOrderParam
 * @author: Samson.Sun
 * @date: 2018-1-20 0:08
 * @email: s_xin@neusoft.com
 */
public class PayCreateOrderParam {
    public PayCreateOrderParam() {
    }

    private String orderNumber;
    private String deviceInfo;

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getDeviceInfo() {
        return deviceInfo;
    }

    public void setDeviceInfo(String deviceInfo) {
        this.deviceInfo = deviceInfo;
    }
}
