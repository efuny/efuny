package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.AboutModel;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.InvitationCodeModel;
import cn.legendream.wawa.model.InviteParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.AboutActivity;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: AboutPresent
 * @author: Samson.Sun
 * @date: 2017-12-21 11:24
 * @email: s_xin@neusoft.com
 */
public class AboutPresent extends XPresent<AboutActivity> {
    public void getAbout() {
        Api.getSimpleService().getAbout()
                .compose(XApi.<BaseModel<AboutModel>>getApiTransformer())
                .compose(XApi.<BaseModel<AboutModel>>getScheduler())
                .compose(getV().<BaseModel<AboutModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<AboutModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<AboutModel> result) {
                        getV().hideProgress();
                        getV().showUrl(result);
                    }
                });
    }

    public void getUserInvitationCode(InviteParam inviteParam) {
        Api.getSimpleService().getUserInvitationCode(NetUtil.createRequestBody(inviteParam))
                .compose(XApi.<BaseModel<InvitationCodeModel>>getApiTransformer())
                .compose(XApi.<BaseModel<InvitationCodeModel>>getScheduler())
                .compose(getV().<BaseModel<InvitationCodeModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<InvitationCodeModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<InvitationCodeModel> result) {
                        getV().hideProgress();
                        getV().showCode(result);
                    }
                });
    }

}
