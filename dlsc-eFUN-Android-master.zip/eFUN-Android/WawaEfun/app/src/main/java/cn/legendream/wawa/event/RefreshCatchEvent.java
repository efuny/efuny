package cn.legendream.wawa.event;

import cn.droidlover.xdroidmvp.event.IBus;

/**
 * @version V1.0 <>
 * @FileName: RefreshCatchEvent
 * @author: Samson.Sun
 * @date: 2018-1-22 23:27
 * @email: s_xin@neusoft.com
 */
public class RefreshCatchEvent implements IBus.IEvent {
    @Override
    public int getTag() {
        return 0;
    }
}
