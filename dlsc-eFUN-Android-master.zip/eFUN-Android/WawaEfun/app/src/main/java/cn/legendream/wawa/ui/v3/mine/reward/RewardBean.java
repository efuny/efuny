package cn.legendream.wawa.ui.v3.mine.reward;

/**
 * Created by zhaoyuefeng on 2019/5/2.
 * Description 
 */
public class RewardBean {

    private String name;
    private String date;
    private String money;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }
}
