package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: OrderStatusModel
 * @author: Samson.Sun
 * @date: 2017-12-27 16:13
 * @email: s_xin@neusoft.com
 */
public class OrderStatusModel {
    public OrderStatusModel() {
    }

    private String orderStatus;
    private String waitSecond;
    private String userGameMoney;

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getWaitSecond() {
        return waitSecond;
    }

    public void setWaitSecond(String waitSecond) {
        this.waitSecond = waitSecond;
    }

    public String getUserGameMoney() {
        return userGameMoney;
    }

    public void setUserGameMoney(String userGameMoney) {
        this.userGameMoney = userGameMoney;
    }
}
