package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.R;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.InvitationCodeModel;
import cn.legendream.wawa.model.InviteParam;
import cn.legendream.wawa.model.ShareInfoModel;
import cn.legendream.wawa.model.ShareInfoParam;
import cn.legendream.wawa.model.SubmitCodeParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.InviteActivity;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: InvitePresent
 * @author: Samson.Sun
 * @date: 2017-12-8 20:38
 * @email: s_xin@neusoft.com
 */
public class InvitePresent extends XPresent<InviteActivity> {
    public void getUserInvitationCode(InviteParam inviteParam) {
        Api.getSimpleService().getUserInvitationCode(NetUtil.createRequestBody(inviteParam))
                .compose(XApi.<BaseModel<InvitationCodeModel>>getApiTransformer())
                .compose(XApi.<BaseModel<InvitationCodeModel>>getScheduler())
                .compose(getV().<BaseModel<InvitationCodeModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<InvitationCodeModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<InvitationCodeModel> result) {
                        getV().hideProgress();
                        getV().showCode(result);
                    }
                });
    }

    public void submitUserCode(SubmitCodeParam submitCodeParam) {
        Api.getSimpleService().submitUserCode(NetUtil.createRequestBody(submitCodeParam))
                .compose(XApi.<BaseModel>getApiTransformer())
                .compose(XApi.<BaseModel>getScheduler())
                .compose(getV().<BaseModel>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel result) {
                        getV().hideProgress();
                        getV().inputCodeResult(result);
                    }
                });
    }

    public void getShareInfo(ShareInfoParam shareInfoParam) {
        Api.getSimpleService().getShareInfo(NetUtil.createRequestBody(shareInfoParam))
                .compose(XApi.<BaseModel<ShareInfoModel>>getApiTransformer())
                .compose(XApi.<BaseModel<ShareInfoModel>>getScheduler())
                .compose(getV().<BaseModel<ShareInfoModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<ShareInfoModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<ShareInfoModel> result) {
                        getV().showShareInfo(result);
                    }
                });
    }
}
