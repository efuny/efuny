package cn.legendream.wawa.model;

import java.util.List;

/**
 * @version V1.0 <>
 * @FileName: CategoryData
 * @author: Samson.Sun
 * @date: 2017-12-17 23:34
 * @email: s_xin@neusoft.com
 */
public class CategoryData {
    public CategoryData(List<CategoryModel> data) {
        this.data = data;
    }
    List<CategoryModel> data;

    public List<CategoryModel> getData() {
        return data;
    }

    public void setData(List<CategoryModel> data) {
        this.data = data;
    }
}
