package cn.legendream.wawa.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xdroidmvp.kit.KnifeKit;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BillModel;
import de.hdodenhof.circleimageview.CircleImageView;

/**
 * @version V1.0 <>
 * @FileName: RechargeListAdapter
 * @author: Samson.Sun
 * @date: 2018-4-3 9:47
 * @email: s_xin@neusoft.com
 */
public class RechargeListAdapter extends SimpleRecAdapter<BillModel, RechargeListAdapter.ViewHolder> {
    public RechargeListAdapter(Context context) {
        super(context);
    }

    @Override
    public RechargeListAdapter.ViewHolder newViewHolder(View itemView) {
        return new RechargeListAdapter.ViewHolder(itemView);
    }

    @Override
    public int getLayoutId() {
        return R.layout.item_bill;
    }

    @Override
    public void onBindViewHolder(RechargeListAdapter.ViewHolder holder, int position) {
        BillModel billModel = data.get(position);
        if (billModel.getPayType().equals("1")) {
            holder.profile_image.setImageResource(R.drawable.ic_wechat);
        } else if (billModel.getPayType().equals("2")) {
            holder.profile_image.setImageResource(R.drawable.ic_alipay);
        }
        if (billModel.getOrderStatus().equals("2")) {
            holder.tv_state.setText(context.getResources().getString(R.string.pay_success));
            holder.tv_state.setTextColor(context.getResources().getColor(R.color.green_ad));
        } else if (billModel.getOrderStatus().equals("1")) {
            holder.tv_state.setText(context.getResources().getString(R.string.unpaid));
            holder.tv_state.setTextColor(context.getResources().getColor(R.color.red_7d));
        }
        holder.tv_money.setText(Utils.formatStrings(context, R.string.bill_money, billModel.getPrice()));
        holder.tv_baby_money.setText(Utils.formatStrings(context, R.string.bill_baby_money, billModel.getGameMoney()));
        holder.tv_time.setText(billModel.getDateTime());
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.profile_image)
        CircleImageView profile_image;
        @BindView(R.id.tv_money)
        TextView tv_money;
        @BindView(R.id.tv_baby_money)
        TextView tv_baby_money;
        @BindView(R.id.tv_time)
        TextView tv_time;
        @BindView(R.id.tv_state)
        TextView tv_state;

        public ViewHolder(View itemView) {
            super(itemView);
            KnifeKit.bind(this, itemView);
        }
    }
}
