package cn.legendream.wawa.ui.v3.main.main;

import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.mvp.XLazyFragment;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BannerModel;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.CategoryData;
import cn.legendream.wawa.model.CategoryModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.ui.MessageActivity;
import cn.legendream.wawa.ui.WebActivity;
import cn.legendream.wawa.ui.fragment.HomeFragment;
import cn.legendream.wawa.view.banner.BannerViewPagerUtil;

public class MainFragment extends XLazyFragment<MainPresenter> implements AppBarLayout.OnOffsetChangedListener {

    @BindView(R.id.message_point_view)
    View messagePointView;
    @BindView(R.id.message_rl)
    RelativeLayout messageRl;
    @BindView(R.id.ly_dots)
    LinearLayout lyDots;
    @BindView(R.id.viewpager)
    ViewPager viewpager;
    @BindView(R.id.app_bar)
    AppBarLayout appBar;
    @BindView(R.id.tab_bg_view)
    View tabBgView;
    @BindView(R.id.top_tab_zone_ll)
    LinearLayout topTabZoneLl;
    @BindView(R.id.top_tab_new_ll)
    LinearLayout topTabNewLl;
    @BindView(R.id.top_tab_life_ll)
    LinearLayout topTabLifeLl;
    @BindView(R.id.container_fl)
    FrameLayout containerFl;
    @BindView(R.id.zone_tv)
    TextView zoneTv;
    @BindView(R.id.newgoods_tv)
    TextView newgoodsTv;
    @BindView(R.id.life_tv)
    TextView lifeTv;
    @BindView(R.id.tab_layout_ll)
    LinearLayout tabLayoutLl;

    List<BannerModel> bannerModels;

    List<Fragment> fragmentList = new ArrayList<>();
    List<View> tabList = new ArrayList<>();
    List<TextView> tabTvList = new ArrayList<>();

    //广告图
    BannerViewPagerUtil viewPagerUtil;
    //广告图图片
    private List<String> ads = new ArrayList<String>();

    @Override
    public int getLayoutId() {
        return R.layout.fragment_main;
    }

    @Override
    public MainPresenter newP() {
        return new MainPresenter();
    }

    @Override
    public void initData(Bundle savedInstanceState) {

        appBar.addOnOffsetChangedListener(this);
        initFragment();
        initBanner();

    }

    private void initFragment() {

        tabList.add(topTabZoneLl);
        tabList.add(topTabNewLl);
        tabList.add(topTabLifeLl);

        tabTvList.add(zoneTv);
        tabTvList.add(newgoodsTv);
        tabTvList.add(lifeTv);

        FragmentManager fragmentManager = getChildFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();

        CategoryData categoryData = SharedPref.getInstance(context).get(Keys.CATEGORY, CategoryData.class);
        if (categoryData.getData() == null) {
            return;
        }
        List<CategoryModel> machineResult = categoryData.getData();
        if (machineResult == null) {
            return;
        }

        for (int i = 0; i < machineResult.size(); i++) {

            if (i >= 3) {
                break;
            }

            HomeFragment homeFragment = HomeFragment.newInstance(machineResult.get(i).getCategoryId());
            tabTvList.get(i).setText(machineResult.get(i).getCategoryName());
            fragmentList.add(homeFragment);
            transaction.add(R.id.container_fl, homeFragment);
        }

        transaction.commit();

        setTab(0);

    }

    private void initBanner() {

        UserParam userParam = new UserParam();
        userParam.setUserId(AppContext.getAccount().getUserId());
        getP().getBannerList(userParam);

    }

    private void setTab(int index) {

        FragmentManager fragmentManager = getChildFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();

        for (int i = 0; i < fragmentList.size(); i++) {

            if (index == i) {
                transaction.show(fragmentList.get(i));
                tabList.get(i).setSelected(true);
            } else {
                transaction.hide(fragmentList.get(i));
                tabList.get(i).setSelected(false);
            }

        }

        transaction.commit();

    }

    public void showBanner(BaseModel<List<BannerModel>> resultModel) {
        if (resultModel == null || Kits.Empty.check(resultModel.getData())) {
            return;
        }
        bannerModels = new ArrayList<>();
        bannerModels.addAll(resultModel.getData());
        for (int i = 0; i < resultModel.getData().size(); i++) {
            ads.add(resultModel.getData().get(i).getImagesUrl());
        }
        //设置图片集合
        if (viewPagerUtil == null) {
            viewPagerUtil = new BannerViewPagerUtil(getContext(), viewpager, lyDots, 10, 4, ads);

            viewPagerUtil.setOnAdItemClickListener(new BannerViewPagerUtil.OnAdItemClickListener() {
                @Override
                public void onItemClick(View v, int flag) {

                    if (Kits.Empty.check(bannerModels)) {
                        return;
                    }
                    if (!Utils.isFastClick()) {
                        BannerModel bannerModel = bannerModels.get(flag);
                        WebActivity.launch(context, bannerModel.getUrl(), bannerModel.getBannerTitle());
                    }

                }
            });

            viewPagerUtil.initVps();
        }
    }

    @OnClick({R.id.message_rl, R.id.top_tab_zone_ll, R.id.top_tab_new_ll, R.id.top_tab_life_ll})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.message_rl: {

                if (!Utils.isFastClick()) {
                    messagePointView.setVisibility(View.GONE);
                    MessageActivity.launch(context);
                }

                break;
            }
            case R.id.top_tab_zone_ll: {
                setTab(0);
                break;
            }
            case R.id.top_tab_new_ll: {
                setTab(1);
                break;
            }
            case R.id.top_tab_life_ll: {
                setTab(2);
                break;
            }
        }
    }

    @Override
    public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {

        int maxHeight = tabLayoutLl.getHeight() - appBar.getHeight();
        if (verticalOffset == 0) {
            tabBgView.setAlpha(0);
        } else if (verticalOffset == maxHeight) {
            tabBgView.setAlpha(1);
        } else {
            tabBgView.setAlpha(0);
        }
        float alpha = -1.0f * verticalOffset / appBar.getHeight();
        if (-verticalOffset == appBar.getHeight()) {
            tabBgView.setAlpha(1f);
        } else {
            if (alpha > 0.98) {
                tabBgView.setAlpha(0.98f);
            } else if (alpha > 0.96) {
                tabBgView.setAlpha(0.76f);
            } else if (alpha > 0.94) {
                tabBgView.setAlpha(0.54f);
            } else if (alpha > 0.92) {
                tabBgView.setAlpha(0.32f);
            } else if (alpha > 0.9) {
                tabBgView.setAlpha(0.1f);
            } else {
                tabBgView.setAlpha(0f);
            }
        }

    }

}
