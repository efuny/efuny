package cn.legendream.wawa.model;

import java.util.List;

/**
 * @version V1.0 <>
 * @FileName: UserSignModel
 * @author: Samson.Sun
 * @date: 2018-5-22 15:43
 * @email: s_xin@neusoft.com
 */
public class UserSignModel {
    private List<SignModel> signList;
    private String signNumber;
    private String daySignStauts;//0 未签到 1已签到

    public List<SignModel> getSignList() {
        return signList;
    }

    public void setSignList(List<SignModel> signList) {
        this.signList = signList;
    }

    public String getSignNumber() {
        return signNumber;
    }

    public void setSignNumber(String signNumber) {
        this.signNumber = signNumber;
    }

    public String getDaySignStauts() {
        return daySignStauts;
    }

    public void setDaySignStauts(String daySignStauts) {
        this.daySignStauts = daySignStauts;
    }
}
