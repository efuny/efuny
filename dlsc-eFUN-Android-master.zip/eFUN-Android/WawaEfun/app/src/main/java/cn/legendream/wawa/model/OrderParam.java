package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: OrderParam
 * @author: Samson.Sun
 * @date: 2017-12-27 16:13
 * @email: s_xin@neusoft.com
 */
public class OrderParam {
    public OrderParam() {
    }

    private String userId;
    private String orderId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
