package cn.legendream.wawa.ui.v3.main.mine;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.event.BusProvider;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.mvp.XLazyFragment;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.event.RefreshCatchEvent;
import cn.legendream.wawa.event.RefreshMessageEvent;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.Account;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.ConactInfoModel;
import cn.legendream.wawa.model.SubmitCodeParam;
import cn.legendream.wawa.model.UserInfoModel;
import cn.legendream.wawa.model.UserMessageInfoModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.ui.AddressActivity;
import cn.legendream.wawa.ui.ConsumptionActivity;
import cn.legendream.wawa.ui.MessageActivity;
import cn.legendream.wawa.ui.RecordActivity;
import cn.legendream.wawa.ui.ScoreActivity;
import cn.legendream.wawa.ui.SettingActivity;
import cn.legendream.wawa.ui.v3.mine.guidebook.GuideBookActivity;
import cn.legendream.wawa.ui.v3.mine.reward.RewardActivity;
import cn.legendream.wawa.ui.v3.mine.share.ShareActivity;
import cn.legendream.wawa.view.CustomDialog;
import cn.legendream.wawa.view.InviteDialog;
import de.hdodenhof.circleimageview.CircleImageView;
import io.reactivex.functions.Consumer;

public class MineFragment extends XLazyFragment<MinePresenter> {

    @BindView(R.id.message_iv)
    ImageView messageIv;
    @BindView(R.id.avatar_iv)
    CircleImageView avatarIv;
    @BindView(R.id.name_tv)
    TextView nameTv;
    @BindView(R.id.id_tv)
    TextView idTv;
    @BindView(R.id.gold_tv)
    TextView goldTv;
    @BindView(R.id.gold_ll)
    LinearLayout goldLl;
    @BindView(R.id.point_tv)
    TextView pointTv;
    @BindView(R.id.point_ll)
    LinearLayout pointLl;
    @BindView(R.id.doll_tv)
    TextView dollTv;
    @BindView(R.id.doll_ll)
    LinearLayout dollLl;
    @BindView(R.id.reward_tv)
    TextView rewardTv;
    @BindView(R.id.invite_tv)
    TextView inviteTv;
    @BindView(R.id.book_tv)
    TextView bookTv;
    @BindView(R.id.address_tv)
    TextView addressTv;
    @BindView(R.id.service_tv)
    TextView serviceTv;
    @BindView(R.id.setting_tv)
    TextView settingTv;
    @BindView(R.id.message_point_view)
    View messagePointView;

    private String sinaConect = "";
    private String wechatConect = "";
    private InviteDialog inviteDialog;
    private String bookUrl;

    @Override
    public void onResume() {
        super.onResume();

        pointTv.setText("积分(" + AppContext.getAccount().getUserPoint() + ")");
        goldTv.setText("娃娃币(" + AppContext.getAccount().getGameMoney() + ")");

    }

    @Override
    public void initData(Bundle savedInstanceState) {

        nameTv.setText(AppContext.getAccount().getNickName());
        idTv.setText(Utils.formatStrings(context, R.string.user_id, AppContext.getAccount().getUserId()));
        ILFactory.getLoader().loadNet(avatarIv, AppContext.getAccount().getHeadUrl(), null);

        getP().getContactInfo();
        final UserParam userParam = new UserParam();
        userParam.setUserId(AppContext.getAccount().getUserId());
        getP().getUserInfo(userParam);

        goldTv.setTypeface(Utils.getGoTrialFont(context));
        pointTv.setTypeface(Utils.getGoTrialFont(context));
        dollTv.setTypeface(Utils.getGoTrialFont(context));
        rewardTv.setTypeface(Utils.getGoTrialFont(context));
        inviteTv.setTypeface(Utils.getGoTrialFont(context));
        bookTv.setTypeface(Utils.getGoTrialFont(context));
        addressTv.setTypeface(Utils.getGoTrialFont(context));
        serviceTv.setTypeface(Utils.getGoTrialFont(context));
        settingTv.setTypeface(Utils.getGoTrialFont(context));

        getP().getUserMessageInfo(new UserParam(AppContext.getAccount().getUserId()));

        BusProvider.getBus().toFlowable(RefreshCatchEvent.class)
                .subscribe(new Consumer<RefreshCatchEvent>() {
                    @Override
                    public void accept(RefreshCatchEvent payEvent) throws Exception {
                        getP().getUserInfo(userParam);
                    }
                });

        BusProvider.getBus().toFlowable(RefreshMessageEvent.class)
                .subscribe(new Consumer<RefreshMessageEvent>() {
                    @Override
                    public void accept(RefreshMessageEvent refreshMessageEvent) {
                        getP().getUserMessageInfo(new UserParam(AppContext.getAccount().getUserId()));
                    }
                });

    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_mine;
    }

    @Override
    public MinePresenter newP() {
        return new MinePresenter();
    }

    @OnClick({R.id.message_iv, R.id.gold_ll, R.id.point_ll, R.id.doll_ll, R.id.reward_tv, R.id.invite_tv, R.id.book_tv, R.id.address_tv, R.id.service_tv, R.id.setting_tv, R.id.input_invite_tv})
    public void onViewClicked(View view) {

        switch (view.getId()) {
            case R.id.message_iv: {
                if (!Utils.isFastClick()) {
                    messagePointView.setVisibility(View.GONE);
                    MessageActivity.launch(context);
                }
                break;
            }
            case R.id.gold_ll: {

                if (!Utils.isFastClick()) {
                    ConsumptionActivity.launch(context);
                }

                break;
            }
            case R.id.point_ll: {

                if (!Utils.isFastClick()) {
                    ScoreActivity.launch(context);
                }

                break;
            }
            case R.id.doll_ll: {

                if (!Utils.isFastClick()) {
                    RecordActivity.launch(context);
                }

                break;
            }
            case R.id.reward_tv: {

                if (!Utils.isFastClick()) {
                    RewardActivity.launch(context);
                }

                break;
            }
            case R.id.invite_tv: {

                if (!Utils.isFastClick()) {
                    ShareActivity.launch(context);
                }

                break;
            }
            case R.id.book_tv: {

                if (!Utils.isFastClick()) {
                    GuideBookActivity.launch(context);
                }


                break;
            }
            case R.id.address_tv: {

                if (!Utils.isFastClick()) {
                    AddressActivity.launch(context);
                }

                break;
            }
            case R.id.service_tv: {

                CustomDialog.Builder builder = new CustomDialog
                        .Builder(getContext())
                        .setTitle(getString(R.string.contact_customer))
                        .setContent(Utils.formatStrings(context, R.string.contact_wechat, wechatConect)
                                , Utils.formatStrings(context, R.string.contact_webo, sinaConect))
                        .setNegativeButton(getString(R.string.closed),
                                new android.content.DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                builder.create().show();

                break;
            }
            case R.id.setting_tv: {

                if (!Utils.isFastClick()) {
                    SettingActivity.launch(context);
                }

                break;
            }

            case R.id.input_invite_tv: {

                String inputCode = Utils.paste(context);
                if (Kits.Empty.check(inputCode) || inputCode.length() != 7 || !Utils.isNumeric(inputCode)) {
                    inputCode = "";
                }

                inviteDialog = new InviteDialog.Builder(context)
                        .setCode(inputCode)
                        .setOnSubmitClickListener(new InviteDialog.OnSubmitClickListener() {
                            @Override
                            public void onCodeChange(DialogInterface dialog, String code) {
                                hideSoftKeyBoard();
                                if (Kits.Empty.check(code)) {
                                    toast(R.string.please_input_code);
                                    return;
                                }
                                SubmitCodeParam submitCodeParam = new SubmitCodeParam();
                                submitCodeParam.setUserId(AppContext.getAccount().getUserId());
                                submitCodeParam.setCode(code);
                                getP().submitUserCode(submitCodeParam);
                            }
                        }).create();

                inviteDialog.show();

                break;
            }
        }
    }

    public void showConectInfo(BaseModel<ConactInfoModel> result) {
        wechatConect = result.getData().getWchat();
        sinaConect = result.getData().getWeibo();
    }

    public void setUserInfo(BaseModel<UserInfoModel> result) {
        Account account = AppContext.getAccount();
        account.setGameMoney(result.getData().getGameMoney());
        account.setUserPoint(result.getData().getUserPoint());
        account.setHeadUrl(result.getData().getHeadUrl());
        SharedPref.getInstance(context).put(Keys.ACCOUNT, account);
        AppContext.setAccount(account);
//        tv_money_num.setText(AppContext.getAccount().getGameMoney());
        pointTv.setText("积分(" + AppContext.getAccount().getUserPoint() + ")");
        goldTv.setText("娃娃币(" + AppContext.getAccount().getGameMoney() + ")");
    }

    public void inputCodeResult(BaseModel result) {
        if (result.getResult().equals("1")) {
            toast(R.string.input_code_success);
            inviteDialog.dismiss();
        } else {
            toast(result.getMsg());
        }
    }

    public void isShowNewMessage(BaseModel<UserMessageInfoModel> resultModel) {
        //0 没有新消息 1有新消息
        if (resultModel.getData().getIsNew().equals("1")) {
            messagePointView.setVisibility(View.VISIBLE);
        } else {
            messagePointView.setVisibility(View.GONE);
        }
    }

}
