package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: PushTokenParam
 * @author: Samson.Sun
 * @date: 2018-2-28 22:20
 * @email: s_xin@neusoft.com
 */
public class PushTokenParam {
    public PushTokenParam() {
    }

    private String pushToken;
    private String userId;

    public String getPushToken() {
        return pushToken;
    }

    public void setPushToken(String pushToken) {
        this.pushToken = pushToken;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
