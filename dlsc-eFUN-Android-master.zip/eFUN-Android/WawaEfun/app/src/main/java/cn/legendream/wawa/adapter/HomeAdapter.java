package cn.legendream.wawa.adapter;

import android.content.Context;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.base.SimpleListAdapter;
import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.kit.KnifeKit;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.MachineModel;

/**
 * @version V1.0 <>
 * @FileName: HomeAdapter
 * @author: Samson.Sun
 * @date: 2017-12-11 9:53
 * @email: s_xin@neusoft.com
 */
public class HomeAdapter extends SimpleRecAdapter<MachineModel, HomeAdapter.ViewHolder> {

    public HomeAdapter(Context context) {
        super(context);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        int fullWidth = wm.getDefaultDisplay().getWidth();
        final MachineModel machineModel = data.get(position);
        int width = fullWidth / 2 - Kits.Dimens.dpToPxInt(context, 20);
        int height = (int) (width * 1.22);
        GridLayoutManager.LayoutParams layoutParams = (GridLayoutManager.LayoutParams) holder.layout_item.getLayoutParams();
        layoutParams.height = height;
        layoutParams.width = width;
        holder.layout_item.setLayoutParams(layoutParams);
        ILFactory.getLoader().loadNet(holder.iv_pic, machineModel.getDollImg(), null);
        holder.tv_state.setText(machineModel.getStatusText());
        if (machineModel.getStatusText().equals(getString(R.string.free))) {
            holder.tv_state.setBackgroundResource(R.drawable.bg_machine_state_green);
        } else {
            holder.tv_state.setBackgroundResource(R.drawable.bg_machine_state_yellow);
        }
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) holder.tv_name.getLayoutParams();
        params.height = 1;
        params.width = width - Kits.Dimens.dpToPxInt(context, 38);
        holder.tv_name.setLayoutParams(params);
        holder.tv_name.setText(machineModel.getMachineName());
        holder.tv_name.setTypeface(Utils.getGoTrialFont(context));
        holder.tv_money.setText(machineModel.getGameMoney() + "/次");
        holder.tv_money.setTypeface(Utils.getGoTrialFont(context));

        holder.layout_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getRecItemClick() != null) {
                    getRecItemClick().onItemClick(position, machineModel, 0, holder);
                }
            }
        });
    }


    @Override
    public ViewHolder newViewHolder(View itemView) {
        return new ViewHolder(itemView);
    }

    @Override
    public int getLayoutId() {
        return R.layout.item_machine;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.layout_item)
        View layout_item;
        @BindView(R.id.iv_pic)
        ImageView iv_pic;
        @BindView(R.id.tv_money)
        TextView tv_money;
        @BindView(R.id.tv_state)
        TextView tv_state;
        @BindView(R.id.tv_name)
        TextView tv_name;

        public ViewHolder(View itemView) {
            super(itemView);
            KnifeKit.bind(this, itemView);
        }
    }
}
