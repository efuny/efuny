package cn.legendream.wawa.model;

import java.util.List;

/**
 * @version V1.0 <>
 * @FileName: FeedbackTypeModel
 * @author: Samson.Sun
 * @date: 2017-12-23 16:38
 * @email: s_xin@neusoft.com
 */
public class FeedbackTypeModel {
    public FeedbackTypeModel() {
    }

    private List<TypeModel> typeList;

    public List<TypeModel> getTypeList() {
        return typeList;
    }

    public void setTypeList(List<TypeModel> typeList) {
        this.typeList = typeList;
    }
}
