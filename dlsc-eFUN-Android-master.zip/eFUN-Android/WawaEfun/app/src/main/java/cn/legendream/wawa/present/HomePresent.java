package cn.legendream.wawa.present;

import java.util.List;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.MachineListParam;
import cn.legendream.wawa.model.MachineModel;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.fragment.HomeFragment;

/**
 * @version V1.0 <>
 * @FileName: HomePresent
 * @author: Samson.Sun
 * @date: 2017-12-11 9:56
 * @email: s_xin@neusoft.com
 */
public class HomePresent extends XPresent<HomeFragment> {
    public void getMachineList(MachineListParam machineListParam) {
        Api.getSimpleService().getMachineList(NetUtil.createRequestBody(machineListParam))
                .compose(XApi.<BaseModel<List<MachineModel>>>getApiTransformer())
                .compose(XApi.<BaseModel<List<MachineModel>>>getScheduler())
                .compose(getV().<BaseModel<List<MachineModel>>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<List<MachineModel>>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<List<MachineModel>> machineResult) {
                        getV().showData(machineResult);
                    }
                });
    }

}
