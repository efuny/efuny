package cn.legendream.wawa.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.AES128;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.ExchangeGoodInfoModel;
import cn.legendream.wawa.model.GoodInfoModel;
import cn.legendream.wawa.model.MallInfoModel;
import cn.legendream.wawa.model.OrderInfoModel;
import cn.legendream.wawa.model.OrderInfoParam;
import cn.legendream.wawa.present.VirtualDetailPresent;

/**
 * 虚拟详情
 *
 * @version V1.0 <>
 * @FileName: VirtualDetailActivity
 * @author: Samson.Sun
 * @date: 2018-7-21 16:32
 * @email: s_xin@neusoft.com
 */
public class VirtualDetailActivity extends XActivity<VirtualDetailPresent> {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.toolbar_title)
    TextView toolbar_title;
    @BindView(R.id.tv_coupon_name)
    TextView tv_coupon_name;
    @BindView(R.id.tv_coupon_time)
    TextView tv_coupon_time;
    @BindView(R.id.tv_code)
    TextView tv_code;
    @BindView(R.id.iv_detail_image)
    ImageView iv_detail_image;
    @BindView(R.id.wv_web)
    WebView wv_web;
    @BindView(R.id.layout_score)
    View layout_score;
    private String orderId;
    private String url;
    private String code;
    private String userPoint;
    public static final String PARAM_ORDER_ID = "param_order_id";
    public static final String PARAM_GOODS_NAME = "param_goods_name";

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar).init();
    }

    public static void launch(Activity activity, String orderId, String goodsName) {
        Router.newIntent(activity)
                .to(VirtualDetailActivity.class)
                .putString(PARAM_ORDER_ID, orderId)
                .putString(PARAM_GOODS_NAME, goodsName)
                .launch();
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_virtual_detail;
    }

    @Override
    public VirtualDetailPresent newP() {
        return new VirtualDetailPresent();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        orderId = getIntent().getStringExtra(PARAM_ORDER_ID);
        toolbar_title.setText(getIntent().getStringExtra(PARAM_GOODS_NAME));
        OrderInfoParam orderInfoParam = new OrderInfoParam();
        orderInfoParam.setUserId(AppContext.getAccount().getUserId());
        orderInfoParam.setOrderId(orderId);
        getP().orderInfo(orderInfoParam);
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    @OnClick(R.id.tv_copy)
    void copy() {
        Utils.copy(context, code);
        toast(R.string.copy_code);
    }

    @SuppressLint("JavascriptInterface")
    private void initWeb() {
        WebSettings webSettings = wv_web.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDefaultTextEncodingName("UTF-8");
        webSettings.setUseWideViewPort(true);// 放大缩小
        webSettings.setSupportZoom(true);
        webSettings.setLoadWithOverviewMode(true);
//        webSettings.setBuiltInZoomControls(true);
        wv_web.addJavascriptInterface(this, "nativeMethod");
        wv_web.setWebChromeClient(new MyWebChromeClient());
        wv_web.setWebViewClient(new WebViewClient());
        if (url != null && url.contains("http")) {
            url = AES128.decode2(url);
            url = url.replace("\"", "");
            wv_web.loadUrl(url);
        }
    }

    class MyWebChromeClient extends WebChromeClient {

        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
        }

        @Override
        public boolean onJsAlert(WebView view, String url, String message,
                                 JsResult result) {
            result.confirm();
            return true;
        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
            try {
                if (newProgress == 100) {
                    hideProgress();
                } else {
                    showProgress();
                }
            } catch (WindowManager.BadTokenException e) {

            }
        }
    }

    public void showData(BaseModel<OrderInfoModel> result) {
        ExchangeGoodInfoModel exchangeGoodInfo = result.getData().getExchangeGoodInfo();
        GoodInfoModel goodInfo = result.getData().getGoodInfo();
        if (exchangeGoodInfo != null) {
            if (!TextUtils.isEmpty(exchangeGoodInfo.getCode())) {
                layout_score.setVisibility(View.VISIBLE);
                code = exchangeGoodInfo.getCode();
                tv_code.setText(Utils.formatStrings(context, R.string.coupon_code, code));
            }else{
                layout_score.setVisibility(View.GONE);
            }
            if (TextUtils.isEmpty(exchangeGoodInfo.getExchangeImageUrl())){
                iv_detail_image.setVisibility(View.GONE);
            }else{
                iv_detail_image.setVisibility(View.VISIBLE);
                ILFactory.getLoader().loadNet(iv_detail_image, exchangeGoodInfo.getExchangeImageUrl(), null);
            }
            tv_coupon_time.setText(exchangeGoodInfo.getExpiryTime());
        }
        if (goodInfo != null) {
            tv_coupon_name.setText(goodInfo.getGoodName());
            url = result.getData().getGoodInfo().getDetail();
            initWeb();
        }
    }

}
