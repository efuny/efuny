package cn.legendream.wawa.net;

import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.LoginResult;
import cn.legendream.wawa.model.TestLoginResult;
import io.reactivex.Flowable;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * @version V1.0 <>
 * @FileName: LoginService
 * @author: Samson.Sun
 * @date: 2017-12-8 9:51
 * @email: s_xin@neusoft.com
 */
public interface LoginService {
    @POST("userLogin")
    Flowable<BaseModel<LoginResult>> doLogin(@Body RequestBody body);

    @POST("testLogin")
    Flowable<BaseModel<LoginResult>> testLogin(@Body RequestBody body);

    @POST("getTestLogin")
    Flowable<BaseModel<TestLoginResult>> getTestLogin();
}
