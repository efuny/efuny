package cn.legendream.wawa.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.PathEffect;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;

/**
 * Created by zhaoyuefeng on 2018/7/17.
 * Description
 */

public class DashView extends View {

    Paint paint;

    public DashView(Context context) {
        super(context);
    }

    public DashView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public DashView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    {
        paint = new Paint();
        paint.setAntiAlias(true);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        PathEffect pathEffect = new DashPathEffect(new float[]{15, 10, 15, 10}, 0);
        paint.setPathEffect(pathEffect);
        paint.setColor(getResources().getColor(R.color.bg_DBD));

        int width = Utils.dip2px(getContext(), 1);

        paint.setStrokeWidth(width);

        canvas.drawLine(0, width / 2, getWidth(), width / 2, paint);
    }
}
