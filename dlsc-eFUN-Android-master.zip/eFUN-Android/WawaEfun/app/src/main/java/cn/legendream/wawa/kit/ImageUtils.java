package cn.legendream.wawa.kit;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;

import cn.droidlover.xdroidmvp.view.refreshlayout.util.DensityUtil;

/**
 * @version V1.0 <>
 * @FileName: ImageUtils
 * @author: Samson.Sun
 * @date: 2018-3-21 22:07
 * @email: s_xin@neusoft.com
 */
public class ImageUtils {

    public static Bitmap createWaterMaskBitmap(Bitmap src, Bitmap watermark,
                                               int paddingLeft, int paddingTop) {
        if (src == null) {
            return null;
        }
        int width = src.getWidth();
        int height = src.getHeight();
        //创建一个bitmap
        Bitmap newb = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);// 创建一个新的和SRC长度宽度一样的位图
        //将该图片作为画布
        Canvas canvas = new Canvas(newb);
        //在画布 0，0坐标上开始绘制原始图片
        canvas.drawBitmap(src, 0, 0, null);
        //在画布上绘制水印图片
        canvas.drawBitmap(watermark, paddingLeft, paddingTop, null);
        // 保存
        canvas.save(Canvas.ALL_SAVE_FLAG);
        // 存储
        canvas.restore();
        return newb;
    }

    public static Bitmap drawText(Context context, Bitmap bitmap, String text,
                                  int size, int color, int start, int end, int paddingLeft, int paddingTop, boolean isBold) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(color);
        paint.setTextSize(DensityUtil.dp2px(size));
        if (isBold) {
            paint.setTypeface(Typeface.DEFAULT_BOLD);
        }
        Rect bounds = new Rect();
        paint.getTextBounds(text, 0, text.length(), bounds);
        return drawTextToBitmap(context, bitmap, text, paint, bounds, start, end,
                paddingLeft,
                paddingTop + bounds.height());
    }

    private static Bitmap drawTextToBitmap(Context context, Bitmap bitmap, String text,
                                           Paint paint, Rect bounds, int start, int end, int paddingLeft, int paddingTop) {
        android.graphics.Bitmap.Config bitmapConfig = bitmap.getConfig();

        paint.setDither(true); // 获取跟清晰的图像采样
        paint.setFilterBitmap(true);// 过滤一些
        if (bitmapConfig == null) {
            bitmapConfig = android.graphics.Bitmap.Config.ARGB_8888;
        }
        bitmap = bitmap.copy(bitmapConfig, true);
        Canvas canvas = new Canvas(bitmap);

        canvas.drawText(text, start, end, paddingLeft, paddingTop, paint);
        return bitmap;
    }

    public static Bitmap drawShareTxt(Bitmap bmp, String content, int textSize, double withMix, double heightMix) {
        Bitmap newBitmap = Bitmap.createBitmap(bmp.getWidth(), bmp.getHeight(), android.graphics.Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(newBitmap);
        canvas.drawBitmap(bmp, 0, 0, null);
        TextPaint textPaint = new TextPaint();
        textPaint.setAntiAlias(true);
        textPaint.setTextSize(DensityUtil.dp2px(textSize));
        int leftRightPadding = (int) (withMix * bmp.getWidth());
        int heightPadding = (int) (heightMix * bmp.getHeight());
        StaticLayout sl = new StaticLayout(content, textPaint, newBitmap.getWidth() - leftRightPadding * 2, Layout.Alignment.ALIGN_CENTER, 1.0f, 0.0f, false);
        canvas.translate(leftRightPadding, heightPadding);
        sl.draw(canvas);
        return newBitmap;
    }
}
