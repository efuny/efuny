package cn.legendream.wawa.net;

import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.ScoreShopUrlModel;
import io.reactivex.Flowable;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * @version V1.0 <>
 * @FileName: ScoreService
 * @author: Samson.Sun
 * @date: 2018-5-21 15:15
 * @email: s_xin@neusoft.com
 */
public interface ScoreService {
    @POST("getDuiBaLoginUrl")
    Flowable<BaseModel<ScoreShopUrlModel>> getDuiBaLoginUrl(@Body RequestBody body);
}
