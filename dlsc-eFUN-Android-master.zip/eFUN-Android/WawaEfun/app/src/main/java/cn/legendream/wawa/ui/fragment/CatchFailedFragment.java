package cn.legendream.wawa.ui.fragment;

import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xrecyclerview.RecyclerItemCallback;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.adapter.CatchAdapter;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.CatchModel;
import cn.legendream.wawa.model.RecordModel;
import cn.legendream.wawa.ui.SendBabyActivity;

/**
 * @version V1.0 <>
 * @FileName: CatchFailedFragment
 * @author: Samson.Sun
 * @date: 2017-12-16 20:33
 * @email: s_xin@neusoft.com
 */
public class CatchFailedFragment extends BaseCatchFragment {

    CatchAdapter adapter;

    public static CatchFailedFragment newInstance(CatchListener catchListener) {
        catchChangedListener = catchListener;
        return new CatchFailedFragment();
    }

    @Override
    public SimpleRecAdapter getAdapter() {

        int width = Utils.getScreenWidth(getActivity());
        int itemWidth = (width - Utils.dip2px(getContext(), 50)) / 2;

        if (adapter == null) {
            adapter = new CatchAdapter(context, 2, itemWidth);
            adapter.setRecItemClick(new RecyclerItemCallback<CatchModel, CatchAdapter.ViewHolder>() {
                @Override
                public void onItemClick(int position, CatchModel model, int tag, CatchAdapter.ViewHolder holder) {
                }
            });
        }
        return adapter;
    }

    @Override
    public void setLayoutManager(XRecyclerView recyclerView) {
        recyclerView.verticalLayoutManager(context);
    }

    @Override
    public String getType() {
        return "0";
    }

}
