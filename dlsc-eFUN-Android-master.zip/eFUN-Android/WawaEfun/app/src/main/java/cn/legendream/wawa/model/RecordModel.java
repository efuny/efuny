package cn.legendream.wawa.model;

import java.util.List;

/**
 * @version V1.0 <>
 * @FileName: RecordModel
 * @author: Samson.Sun
 * @date: 2017-12-20 22:55
 * @email: s_xin@neusoft.com
 */
public class RecordModel {
    public RecordModel() {
    }
    private UserInfo userInfo;
    private List<CatchModel> grabList;

    public UserInfo getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(UserInfo userInfo) {
        this.userInfo = userInfo;
    }

    public List<CatchModel> getGrabList() {
        return grabList;
    }

    public void setGrabList(List<CatchModel> grabList) {
        this.grabList = grabList;
    }

    public class UserInfo{
        public UserInfo() {
        }
        private String username;
        private String headUrl;
        private String dollCount;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getHeadUrl() {
            return headUrl;
        }

        public void setHeadUrl(String headUrl) {
            this.headUrl = headUrl;
        }

        public String getDollCount() {
            return dollCount;
        }

        public void setDollCount(String dollCount) {
            this.dollCount = dollCount;
        }
    }
}
