package cn.legendream.wawa.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Switch;

import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.bean.SHARE_MEDIA;

import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.event.BusProvider;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.event.LogoutEvent;
import cn.legendream.wawa.event.RefreshCatchEvent;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.Account;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.present.SettingPresent;
import me.drakeet.materialdialog.MaterialDialog;

/**
 * @version V1.0 <>
 * @FileName: SettingActivity
 * @author: Samson.Sun
 * @date: 2017-12-14 9:11
 * @email: s_xin@neusoft.com
 */
public class SettingActivity extends XActivity<SettingPresent> {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.sw_music)
    Switch sw_music;
    @BindView(R.id.sw_sound)
    Switch sw_sound;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar)
                .statusBarDarkFont(true, 0.2f).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        sw_music.setChecked(SharedPref.getInstance(context).getBoolean(Keys.IS_BACKGROUND_MUSIC, true));
        sw_sound.setChecked(SharedPref.getInstance(context).getBoolean(Keys.IS_SOUND, true));
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_setting;
    }

    @Override
    public SettingPresent newP() {
        return new SettingPresent();
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    @OnClick(R.id.layout_about)
    void about() {
        if (!Utils.isFastClick()) {
            AboutActivity.launch(context);
        }
    }

    @OnClick(R.id.tv_logout)
    void logout() {
        /*new MaterialDialog.Builder(this)
                .title(R.string.logout)
                .content(R.string.is_logout)
                .positiveText(R.string.confirm)
                .negativeText(R.string.cancel)
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        UserParam userParam = new UserParam();
                        userParam.setUserId(AppContext.getAccount().getUserId());
                        getP().doLogout(userParam);
                    }
                })
                .onNegative(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                    }
                })
                .show();*/

        final MaterialDialog materialDialog = new MaterialDialog(context);
        materialDialog.setTitle(R.string.logout)
                .setMessage(R.string.is_logout)
                .setCanceledOnTouchOutside(true)
                .setPositiveButton(R.string.confirm, new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        materialDialog.dismiss();
                        UserParam userParam = new UserParam();
                        userParam.setUserId(AppContext.getAccount().getUserId());
                        getP().doLogout(userParam);
                    }
                });
        materialDialog.setNegativeButton(R.string.cancel, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                materialDialog.dismiss();
            }
        });
        materialDialog.show();
    }

    @OnClick(R.id.sw_music)
    void changeMusic() {
        if (sw_music.isChecked()) {
            SharedPref.getInstance(context).putBoolean(Keys.IS_BACKGROUND_MUSIC, true);
        } else {
            SharedPref.getInstance(context).putBoolean(Keys.IS_BACKGROUND_MUSIC, false);
        }
    }

    @OnClick(R.id.sw_sound)
    void changeSound() {
        if (sw_sound.isChecked()) {
            SharedPref.getInstance(context).putBoolean(Keys.IS_SOUND, true);
        } else {
            SharedPref.getInstance(context).putBoolean(Keys.IS_SOUND, false);
        }
    }

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(SettingActivity.class)
                .launch();
    }

    public void showData(BaseModel result) {
        if (result.getResult().equals("1")) {
            UMShareAPI.get(context).deleteOauth(context, SHARE_MEDIA.WEIXIN, authListener);
        } else {
            toast(R.string.logout_failed);
        }
    }

    UMAuthListener authListener = new UMAuthListener() {
        /**
         * @desc 授权开始的回调
         * @param platform 平台名称
         */
        @Override
        public void onStart(SHARE_MEDIA platform) {
        }

        /**
         * @desc 授权成功的回调
         * @param platform 平台名称
         * @param action 行为序号，开发者用不上
         * @param data 用户资料返回
         */
        @Override
        public void onComplete(SHARE_MEDIA platform, int action, Map<String, String> data) {
            hideProgress();
            Account account = new Account();
            AppContext.setAccount(account);
            SharedPref.getInstance(context).put(Keys.ACCOUNT, account);
            SharedPref.getInstance(context).putBoolean(Keys.IS_LOGIN, false);
            BusProvider.getBus().post(new LogoutEvent());
            Intent intent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        }

        /**
         * @desc 授权失败的回调
         * @param platform 平台名称
         * @param action 行为序号，开发者用不上
         * @param t 错误原因
         */
        @Override
        public void onError(SHARE_MEDIA platform, int action, Throwable t) {
        }

        /**
         * @desc 授权取消的回调
         * @param platform 平台名称
         * @param action 行为序号，开发者用不上
         */
        @Override
        public void onCancel(SHARE_MEDIA platform, int action) {
        }
    };
}
