package cn.legendream.wawa.ui.v3.mine.reward;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.RewardModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.ui.v3.mine.share.ShareActivity;

public class RewardActivity extends XActivity<RewardPresenter> {

    @BindView(R.id.back_iv)
    ImageView backIv;
    @BindView(R.id.invite_people_num_tv)
    TextView invitePeopleNumTv;
    @BindView(R.id.charge_people_num_tv)
    TextView chargePeopleNumTv;
    @BindView(R.id.charge_num_tv)
    TextView chargeNumTv;
    @BindView(R.id.reward_num_tv)
    TextView rewardNumTv;
    @BindView(R.id.title_ll)
    LinearLayout titleLl;
    @BindView(R.id.reward_recycler_view)
    RecyclerView rewardRecyclerView;

    RewardRecyclerAdapter adapter;

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(RewardActivity.class)
                .launch();
    }

    @Override
    public void initData(Bundle savedInstanceState) {

        adapter = new RewardRecyclerAdapter(this);
        rewardRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        rewardRecyclerView.setAdapter(adapter);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        dividerItemDecoration.setDrawable(new ColorDrawable(ContextCompat.getColor(this, R.color.bg_F6E)));
        rewardRecyclerView.addItemDecoration(dividerItemDecoration);

        getP().getRewardList(new UserParam(AppContext.getAccount().getUserId()));

    }

    public void showResult(BaseModel<RewardModel> data) {

        invitePeopleNumTv.setText(data.getData().getInvitation_count() + "");
        chargePeopleNumTv.setText(data.getData().getRecharge_count() + "");
        chargeNumTv.setText(data.getData().getRecharge_money() + "");
        rewardNumTv.setText(data.getData().getRecharge_integral() + "");

        adapter.refreshData(data.getData().getList());

    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_reward;
    }

    @Override
    public RewardPresenter newP() {
        return new RewardPresenter();
    }

    @OnClick(R.id.back_iv)
    public void onViewClicked() {
        onBackPressed();
    }
}
