package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: UserOrderParam
 * @author: Samson.Sun
 * @date: 2018-1-19 16:06
 * @email: s_xin@neusoft.com
 */
public class UserOrderParam {
    public UserOrderParam() {
    }
    private String userId;
    private String orderId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
