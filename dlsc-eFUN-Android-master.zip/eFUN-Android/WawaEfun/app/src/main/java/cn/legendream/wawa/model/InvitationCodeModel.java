package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: InvitationCodeModel
 * @author: Samson.Sun
 * @date: 2017-12-21 8:59
 * @email: s_xin@neusoft.com
 */
public class InvitationCodeModel {
    public InvitationCodeModel() {
    }

    private String code;
    private String codePoint;
    private String shareUrl;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCodePoint() {
        return codePoint;
    }

    public void setCodePoint(String codePoint) {
        this.codePoint = codePoint;
    }

    public String getShareUrl() {
        return shareUrl;
    }

    public void setShareUrl(String shareUrl) {
        this.shareUrl = shareUrl;
    }
}
