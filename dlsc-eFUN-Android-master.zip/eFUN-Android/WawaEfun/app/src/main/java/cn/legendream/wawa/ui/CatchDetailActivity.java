package cn.legendream.wawa.ui;

import android.app.Activity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.makeramen.roundedimageview.RoundedImageView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.event.BusProvider;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.event.PayEvent;
import cn.legendream.wawa.event.RefreshCatchEvent;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.Account;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.CatchDetailExpressModel;
import cn.legendream.wawa.model.CatchDetailModel;
import cn.legendream.wawa.model.CatchModel;
import cn.legendream.wawa.model.OrderExchangeInfoModel;
import cn.legendream.wawa.model.UserOrderModel;
import cn.legendream.wawa.model.UserOrderParam;
import cn.legendream.wawa.present.CatchDetailPresent;
import cn.legendream.wawa.view.BoraxRoundTextView;
import cn.legendream.wawa.view.ScoreChoiceDialog;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: CatchDetailActivity
 * @author: Samson.Sun
 * @date: 2018-5-21 16:20
 * @email: s_xin@neusoft.com
 */
public class CatchDetailActivity extends XActivity<CatchDetailPresent> {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.toolbar_title)
    TextView toolbar_title;
    @BindView(R.id.tv_name)
    TextView tv_name;
    //    @BindView(R.id.tv_catch_state)
//    TextView tv_catch_state;
    @BindView(R.id.tv_exchange_value)
    TextView tv_exchange_value;
    //    @BindView(R.id.tv_num_value)
//    TextView tv_num_value;
//    @BindView(R.id.tv_state_value)
//    TextView tv_state_value;
    @BindView(R.id.tv_id_value)
    TextView tv_id_value;
    //    @BindView(R.id.tv_content)
//    TextView tv_content;
    //    @BindView(R.id.tv_send_help)
//    TextView tv_send_help;
    @BindView(R.id.tv_exchange)
    TextView tv_exchange;
    @BindView(R.id.tv_send)
    TextView tv_send;
    @BindView(R.id.profile_image)
    RoundedImageView profile_image;
    @BindView(R.id.tv_state)
    ImageView tv_state;
    public static final String PARAM_ORDER = "param_order";
    @BindView(R.id.image_rl)
    RelativeLayout imageRl;
    @BindView(R.id.tv_state_value)
    BoraxRoundTextView tv_state_value;
    @BindView(R.id.layout_state)
    RelativeLayout layoutState;
    @BindView(R.id.layout_exchange_money)
    RelativeLayout layoutExchangeMoney;
    @BindView(R.id.tv_exchange_point)
    TextView tvExchangePoint;
    @BindView(R.id.layout_exchange_point)
    RelativeLayout layoutExchangePoint;
    @BindView(R.id.user_name_tv)
    TextView userNameTv;
    @BindView(R.id.user_phone_tv)
    TextView userPhoneTv;
    @BindView(R.id.address_tv)
    TextView addressTv;
    @BindView(R.id.address_ll)
    LinearLayout addressLl;
    @BindView(R.id.express_no_tv)
    TextView expressNoTv;
    @BindView(R.id.express_name_tv)
    BoraxRoundTextView expressNameTv;
    @BindView(R.id.send_notice_tv)
    TextView sendNoticeTv;
    @BindView(R.id.express_address_tv)
    TextView expressAddressTv;
    @BindView(R.id.container_bottom_ll)
    LinearLayout containerBottomLl;
    @BindView(R.id.bottom_rl)
    RelativeLayout bottomRl;
    @BindView(R.id.layout_bottom)
    RelativeLayout layoutBottom;
    private CatchModel catchModel;
    private CatchDetailModel catchDetailModel;
    private OrderExchangeInfoModel orderExchangeInfoModel;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar)
                .statusBarDarkFont(true, 0.2f).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        sendNoticeTv.setTypeface(Utils.getGoTrialFont(context));
        catchModel = (CatchModel) getIntent().getSerializableExtra(PARAM_ORDER);
        toolbar_title.setText(catchModel.getDollName());
        UserOrderParam userOrderParam = new UserOrderParam();
        userOrderParam.setUserId(AppContext.getAccount().getUserId());
        userOrderParam.setOrderId(catchModel.getOrderId());
        getP().userGrabRecordInfo(userOrderParam);
        getP().expressInfo(userOrderParam);
        BusProvider.getBus().toFlowable(RefreshCatchEvent.class)
                .subscribe(new Consumer<RefreshCatchEvent>() {
                    @Override
                    public void accept(RefreshCatchEvent refreshCatchEvent) throws Exception {
                        finish();
                    }
                });

        //如果是0 显示发货按钮 和兑换按钮。其他的发货和兑换按钮都隐藏。 2的时候显示查看发货按钮。
//        if (catchModel.getExpressStatus().equals("0")) {
//            tv_state.setVisibility(View.VISIBLE);
//            tv_state.setImageResource(R.drawable.ic_success);
//        } else {
//            tv_state.setVisibility(View.GONE);
//        }

        BusProvider.getBus().toFlowable(PayEvent.class)
                .subscribe(new Consumer<PayEvent>() {
                    @Override
                    public void accept(PayEvent payEvent) throws Exception {
                        finish();
                    }
                });

        imageRl.post(new Runnable() {
            @Override
            public void run() {

                int width = imageRl.getWidth();

                ViewGroup.LayoutParams layoutParams = imageRl.getLayoutParams();

                layoutParams.height = width;
                imageRl.setLayoutParams(layoutParams);

            }
        });

    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_catch_detail;
    }

    @Override
    public CatchDetailPresent newP() {
        return new CatchDetailPresent();
    }

    public void showDetail(CatchDetailModel catchDetailModel) {
        this.catchDetailModel = catchDetailModel;
        ILFactory.getLoader().loadNet(profile_image, catchDetailModel.getDollImage(), null);
        tv_name.setText(catchDetailModel.getDollName());
//        tv_catch_state.setText(catchDetailModel.getStatusText());
        tv_exchange_value.setText(catchDetailModel.getGameIntegral());
//        tv_num_value.setText(Utils.formatStrings(context, R.string.catch_detail_num_value, catchDetailModel.getDollNumber()));
        tv_id_value.setText(catchDetailModel.getGameNumber());
        tvExchangePoint.setText(catchDetailModel.getUserPoint());


        if (catchDetailModel.getStatus().equals("3")) {
            UserOrderParam userOrderParam = new UserOrderParam();
            userOrderParam.setUserId(AppContext.getAccount().getUserId());
            userOrderParam.setOrderId(catchModel.getOrderId());
            getP().orderExchangeInfo(userOrderParam);
            tv_state.setImageResource(R.drawable.ic_success);
            layoutBottom.setVisibility(View.VISIBLE);
            tv_state_value.setText(catchDetailModel.getDollStatusText());
        } else if (catchDetailModel.getStatus().equals("4")) {
            layoutBottom.setVisibility(View.GONE);
            tv_state.setImageResource(R.drawable.ic_sent);
            tv_state_value.setText("已发货");
        } else if (catchDetailModel.getStatus().equals("5")) {
            layoutBottom.setVisibility(View.GONE);
            tv_state.setImageResource(R.drawable.ic_done);
            tv_state_value.setText("已完成");
        } else if (catchDetailModel.getStatus().equals("6")) {
            layoutBottom.setVisibility(View.GONE);
            tv_state.setImageResource(R.drawable.ic_exchanged);
            tv_state_value.setText("已兑换");
        } else {
            layoutBottom.setVisibility(View.GONE);
            tv_state.setVisibility(View.GONE);
            tv_state_value.setVisibility(View.GONE);
        }

    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    public static void launch(Activity activity, CatchModel model) {
        Router.newIntent(activity)
                .to(CatchDetailActivity.class)
                .putSerializable(PARAM_ORDER, model)
                .launch();
    }

    @OnClick(R.id.tv_exchange)
    void exchangeEfun() {
        if (orderExchangeInfoModel == null) {
            return;
        }
        ScoreChoiceDialog.Builder builder = new ScoreChoiceDialog.Builder(context)
                .setMessage(orderExchangeInfoModel.getText(), orderExchangeInfoModel.getGameIntegral(),
                        orderExchangeInfoModel.getUserPoint(), orderExchangeInfoModel.getSelectIndex().equals("1") ? false : true)
                .setOnSubmitClickListener(new ScoreChoiceDialog.OnSubmitClickListener() {
                    @Override
                    public void onScoreChange(DialogInterface dialog, String money, String score, boolean isMoney) {
                        if (isMoney) {
                            exchangeOrder(catchModel.getOrderId());
                        } else {
                            userOrderChangeGameIntegral(catchModel.getOrderId());
                        }
                        dialog.dismiss();
                    }
                });
        builder.create().show();
//        ScoreDialog.Builder builder = new ScoreDialog.Builder(context)
//                .setMessage(catchModel.getDollName(), catchModel.getDollScore())
//                .setOnSubmitClickListener(new ScoreDialog.OnSubmitClickListener() {
//                    @Override
//                    public void onScoreChange(DialogInterface dialog, String score) {
//                        UserOrderParam userOrderParam = new UserOrderParam();
//                        userOrderParam.setOrderId(catchModel.getOrderId());
//                        userOrderParam.setUserId(AppContext.getAccount().getUserId());
//                        getP().userOrderChangeScore(userOrderParam);
//                        tv_exchange.setEnabled(false);
//                        dialog.dismiss();
//                    }
//                });
//        builder.create().show();
    }

    @OnClick(R.id.tv_send)
    void sendEfun() {
        if (!Utils.isFastClick()) {
            SendBabyActivity.launch(context, catchModel.getOrderId());
        }
    }

//    @OnClick(R.id.tv_send_help)
//    void help() {
//        if (!Utils.isFastClick()) {
//            WebActivity.launch(context, Api.ED_PATH, getString(R.string.apply_send_help));
//        }
//    }

    public void exchangeResult(BaseModel<UserOrderModel> result, boolean isMoney) {
        if (result.getData() == null || TextUtils.isEmpty(result.getData().getPoint())) {
            toast(getString(R.string.exchange_failed));
            return;
        }
        toast(getString(R.string.exchange_success));
        Account account = AppContext.getAccount();
        if (isMoney) {
            account.setGameMoney(result.getData().getPoint());
        } else {
            account.setUserPoint(result.getData().getPoint());
        }
        SharedPref.getInstance(context).put(Keys.ACCOUNT, account);
        AppContext.setAccount(account);
        BusProvider.getBus().post(new RefreshCatchEvent());
    }

    public void exchangeInfo(BaseModel<OrderExchangeInfoModel> result, final String orderId) {
        if (result.getData() != null) {
            this.orderExchangeInfoModel = result.getData();
        }

        tvExchangePoint.setText(orderExchangeInfoModel.getNew_userPoint());

    }

    public void exchangeOrder(String orderId) {
        UserOrderParam userOrderParam = new UserOrderParam();
        userOrderParam.setOrderId(orderId);
        userOrderParam.setUserId(AppContext.getAccount().getUserId());
        getP().userOrderChangeScore(userOrderParam);
    }

    public void userOrderChangeGameIntegral(String orderId) {
        UserOrderParam userOrderParam = new UserOrderParam();
        userOrderParam.setOrderId(orderId);
        userOrderParam.setUserId(AppContext.getAccount().getUserId());
        getP().userOrderChangeGameIntegral(userOrderParam);
    }

    public void expressInfoResult(BaseModel<CatchDetailExpressModel> data) {

        if (data == null || data.getData() == null || TextUtils.isEmpty(data.getData().getNumber())) {

            addressLl.setVisibility(View.GONE);
            bottomRl.setVisibility(View.GONE);

        }

        addressLl.setVisibility(View.VISIBLE);
        bottomRl.setVisibility(View.VISIBLE);

        userNameTv.setText(data.getData().getContacts());
        userPhoneTv.setText(data.getData().getPhone());
        addressTv.setText(data.getData().getAddress());
        expressNameTv.setText(data.getData().getCompany());
        expressNoTv.setText(data.getData().getNumber());
        expressAddressTv.setText(data.getData().getRecord());

    }

}
