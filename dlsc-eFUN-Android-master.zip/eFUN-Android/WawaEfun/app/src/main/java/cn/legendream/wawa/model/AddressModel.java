package cn.legendream.wawa.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * @version V1.0 <>
 * @FileName: AddressModel
 * @author: Samson.Sun
 * @date: 2017-12-14 14:48
 * @email: s_xin@neusoft.com
 */
public class AddressModel implements Serializable{
    public AddressModel() {
    }

    private String person;
    private String mobile;
    private String address;
    private String isDefault;
    private String addressId;
    private boolean isCheck = false;

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }

    public boolean isCheck() {
        return isCheck;
    }

    public void setCheck(boolean check) {
        isCheck = check;
    }
}
