package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.MachineInfoModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.MineActivity;
import cn.legendream.wawa.ui.SettingActivity;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: SettingPresent
 * @author: Samson.Sun
 * @date: 2017-12-14 9:11
 * @email: s_xin@neusoft.com
 */
public class SettingPresent extends XPresent<SettingActivity> {
    public void doLogout(UserParam userParam){
        Api.getSimpleService().userLogout(NetUtil.createRequestBody(userParam))
                .compose(XApi.<BaseModel>getApiTransformer())
                .compose(XApi.<BaseModel>getScheduler())
                .compose(getV().<BaseModel>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel result) {
                        getV().showData(result);
                    }
                });
    }
}
