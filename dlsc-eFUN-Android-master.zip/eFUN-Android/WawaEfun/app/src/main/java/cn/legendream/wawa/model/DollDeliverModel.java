package cn.legendream.wawa.model;

import java.util.List;

/**
 * @version V1.0 <>
 * @FileName: DollDeliverModel
 * @author: Samson.Sun
 * @date: 2017-12-24 11:55
 * @email: s_xin@neusoft.com
 */
public class DollDeliverModel {
    public DollDeliverModel() {
    }

    private AddressInfoModel addressInfo;
    private List<DollListInfoModel> dollList;

    public AddressInfoModel getAddressInfo() {
        return addressInfo;
    }

    public void setAddressInfo(AddressInfoModel addressInfo) {
        this.addressInfo = addressInfo;
    }

    public List<DollListInfoModel> getDollList() {
        return dollList;
    }

    public void setDollList(List<DollListInfoModel> dollList) {
        this.dollList = dollList;
    }

}
