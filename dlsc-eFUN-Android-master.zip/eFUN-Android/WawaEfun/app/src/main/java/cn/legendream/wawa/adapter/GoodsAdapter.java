package cn.legendream.wawa.adapter;

import android.content.Context;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.joooonho.SelectableRoundedImageView;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.kit.KnifeKit;
import cn.legendream.wawa.R;
import cn.legendream.wawa.model.GoodsModel;

/**
 * @version V1.0 <>
 * @FileName: GoodsAdapter
 * @author: Samson.Sun
 * @date: 2018-7-9 23:45
 * @email: s_xin@neusoft.com
 */
public class GoodsAdapter extends SimpleRecAdapter<GoodsModel, GoodsAdapter.ViewHolder> {
    public GoodsAdapter(Context context) {
        super(context);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        int fullWidth = wm.getDefaultDisplay().getWidth();
        final GoodsModel goodsModel = data.get(position);
        int width = fullWidth / 2 - Kits.Dimens.dpToPxInt(context, 15);
        int height = (int) (width * 1.35);
        GridLayoutManager.LayoutParams layoutParams = (GridLayoutManager.LayoutParams) holder.layout_item.getLayoutParams();
        layoutParams.height = height;
        layoutParams.width = width;
        layoutParams.leftMargin = position % 2 == 0 ? Kits.Dimens.dpToPxInt(context, 10) : Kits.Dimens.dpToPxInt(context, 5);
        layoutParams.rightMargin = position % 2 == 0 ? Kits.Dimens.dpToPxInt(context, 5) : Kits.Dimens.dpToPxInt(context, 10);
        RelativeLayout.LayoutParams imageLayoutParams = (RelativeLayout.LayoutParams) holder.iv_shop_image.getLayoutParams();
        imageLayoutParams.width = width - Kits.Dimens.dpToPxInt(context, 10);
        imageLayoutParams.height = width - Kits.Dimens.dpToPxInt(context, 10);
        ILFactory.getLoader().loadNet(holder.iv_shop_image, goodsModel.getGoodImageUrl(), null);
        holder.tv_good_name.setText(goodsModel.getGoodName());
        if (TextUtils.isEmpty(goodsModel.getIntegral())) {
            holder.tv_good_score.setVisibility(View.GONE);
            holder.tv_score.setVisibility(View.GONE);
        } else {
            int score = Integer.parseInt(goodsModel.getIntegral());
            if (score > 0) {
                holder.tv_good_score.setVisibility(View.VISIBLE);
                holder.tv_score.setVisibility(View.VISIBLE);
                holder.tv_good_score.setText(goodsModel.getIntegral());
            } else {
                holder.tv_good_score.setVisibility(View.GONE);
                holder.tv_score.setVisibility(View.GONE);
            }
        }
        if (TextUtils.isEmpty(goodsModel.getPrice())) {
            holder.tv_good_and.setVisibility(View.GONE);
            holder.tv_good_price.setVisibility(View.GONE);
            holder.tv_good_money.setVisibility(View.GONE);
        } else {
            double price = Double.parseDouble(goodsModel.getPrice());
            if (price > 0) {
                holder.tv_good_and.setVisibility(View.VISIBLE);
                holder.tv_good_price.setVisibility(View.VISIBLE);
                holder.tv_good_money.setVisibility(View.VISIBLE);
                holder.tv_good_price.setText(goodsModel.getPrice());
            } else {
                holder.tv_good_and.setVisibility(View.GONE);
                holder.tv_good_price.setVisibility(View.GONE);
                holder.tv_good_money.setVisibility(View.GONE);
            }
        }
        holder.layout_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getRecItemClick() != null) {
                    getRecItemClick().onItemClick(position, goodsModel, 0, holder);
                }
            }
        });
        holder.iv_shop_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getRecItemClick() != null) {
                    getRecItemClick().onItemClick(position, goodsModel, 0, holder);
                }
            }
        });
    }

    @Override
    public ViewHolder newViewHolder(View itemView) {
        return new ViewHolder(itemView);
    }

    @Override
    public int getLayoutId() {
        return R.layout.item_goods;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.layout_item)
        View layout_item;
        @BindView(R.id.iv_shop_image)
        SelectableRoundedImageView iv_shop_image;
        @BindView(R.id.tv_good_name)
        TextView tv_good_name;
        @BindView(R.id.tv_good_score)
        TextView tv_good_score;
        @BindView(R.id.tv_score)
        TextView tv_score;
        @BindView(R.id.tv_good_and)
        TextView tv_good_and;
        @BindView(R.id.tv_good_price)
        TextView tv_good_price;
        @BindView(R.id.tv_good_money)
        TextView tv_good_money;

        public ViewHolder(View itemView) {
            super(itemView);
            KnifeKit.bind(this, itemView);
        }
    }
}
