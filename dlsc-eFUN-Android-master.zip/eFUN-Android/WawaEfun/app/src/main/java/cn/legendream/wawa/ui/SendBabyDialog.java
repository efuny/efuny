package cn.legendream.wawa.ui;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.ImageView;

import cn.legendream.wawa.R;

/**
 * Created by zhaoyuefeng on 2018/9/27.
 * Description
 */

public class SendBabyDialog extends Dialog {

    ImageView closeIv;
    ImageView aliIv;
    ImageView wechatIv;

    String orderNo;

    SendBabyActivity sendBabyActivity;

    public SendBabyDialog(@NonNull Context context, SendBabyActivity sendBabyActivity, String orderNo) {
        this(context, R.style.Dialog);
        this.sendBabyActivity = sendBabyActivity;
        this.orderNo = orderNo;
    }

    public SendBabyDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.send_baby_dialog);

        closeIv = findViewById(R.id.close_iv);
        aliIv = findViewById(R.id.ali_iv);
        wechatIv = findViewById(R.id.wechat_iv);

        closeIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        aliIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendBabyActivity.createAliOrder(orderNo);
                dismiss();
            }
        });

        wechatIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendBabyActivity.createWechatOrder(orderNo);
                dismiss();
            }
        });

    }
}
