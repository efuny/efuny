package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: SendBabyModel
 * @author: Samson.Sun
 * @date: 2017-12-21 23:00
 * @email: s_xin@neusoft.com
 */
public class SendBabyModel {
    public SendBabyModel() {
    }
    private String dollName;
    private String dollId;

    public String getDollId() {
        return dollId;
    }

    public void setDollId(String dollId) {
        this.dollId = dollId;
    }

    public String getDollName() {
        return dollName;
    }

    public void setDollName(String dollName) {
        this.dollName = dollName;
    }
}
