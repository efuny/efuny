package cn.legendream.wawa.model;

/**
 * Created by zhaoyuefeng on 2018/9/26.
 * Description
 */

public class GetExpressPriceOrderModel {


    /**
     * orderNo : Kc235e744b9ca17749552d014cf26ad0b
     */

    private String orderNo;

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
}
