package cn.legendream.wawa.model;

import java.io.Serializable;

/**
 * @version V1.0 <>
 * @FileName: CategoryModel
 * @author: Samson.Sun
 * @date: 2017-12-17 17:53
 * @email: s_xin@neusoft.com
 */
public class CategoryModel implements Serializable {
    public CategoryModel() {
    }

    private String categoryName;
    private String categoryId;
    private String categoryImage;

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryImage() {
        return categoryImage;
    }

    public void setCategoryImage(String categoryImage) {
        this.categoryImage = categoryImage;
    }
}
