package cn.legendream.wawa.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.makeramen.roundedimageview.RoundedImageView;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.kit.KnifeKit;
import cn.legendream.wawa.R;
import cn.legendream.wawa.model.CatchModel;
import cn.legendream.wawa.view.BoraxShaderLinearLayoutWithPadding;

/**
 * @version V1.0 <>
 * @FileName: CatchAdapter
 * @author: Samson.Sun
 * @date: 2017-12-16 21:09
 * @email: s_xin@neusoft.com
 */
public class CatchAdapter extends SimpleRecAdapter<CatchModel, CatchAdapter.ViewHolder> {

    private int type = 1;//1成功2失败
    private OnSendClickListener onSendClickListener;
    private OnExchangeClickListener onExchangeClickListener;
    private OnLogisticsClickListener onLogisticsClickListener;

    private int itemWidth;

    public CatchAdapter(Context context, int type, int width) {
        super(context);
        this.type = type;
        this.itemWidth = width;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        ViewGroup.LayoutParams itemLp = holder.item_catch.getLayoutParams();
        itemLp.width = itemWidth;
        itemLp.height = (int) (itemWidth * 1.3);
        holder.item_catch.setLayoutParams(itemLp);

        ViewGroup.LayoutParams imageLp = holder.imageRl.getLayoutParams();
        imageLp.height = itemWidth;
        holder.imageRl.setLayoutParams(imageLp);

        final CatchModel catchModel = data.get(position);
        holder.tv_sending.setVisibility(View.GONE);
        if (type == 1) {
            if (catchModel.getExpressStatus().equals("0")) {
//                holder.layout_send.setVisibility(View.VISIBLE);
//                holder.layout_select.setVisibility(View.GONE);
            } else if (catchModel.getExpressStatus().equals("2")) {
//                holder.layout_send.setVisibility(View.GONE);
//                holder.layout_select.setVisibility(View.VISIBLE);
//                holder.tv_logistics.setVisibility(View.VISIBLE);
                holder.tv_sending.setVisibility(View.VISIBLE);
            } else if (catchModel.getExpressStatus().equals("3") || catchModel.getExpressStatus().equals("1")) {
//                holder.layout_send.setVisibility(View.GONE);
//                holder.layout_select.setVisibility(View.VISIBLE);
//                holder.tv_logistics.setVisibility(View.GONE);
                holder.tv_sending.setVisibility(View.VISIBLE);
            }
            ILFactory.getLoader().loadNet(holder.iv_image, catchModel.getDollImage(), null);
            holder.tv_name.setText(catchModel.getDollName());
            holder.tv_sending.setText(catchModel.getStatusText());
            holder.tv_time.setText(catchModel.getDateTime() + " " + catchModel.getReleaseText());
//            holder.tv_send.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    if (onSendClickListener != null) {
//                        onSendClickListener.onSendClicked(catchModel, position);
//                    }
//                }
//            });
//            holder.tv_exchange.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    onExchangeClickListener.onExchangeClicked(catchModel, position);
//                }
//            });
//            holder.tv_logistics.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    onLogisticsClickListener.onLogisticsClicked(catchModel, position);
//                }
//            });
            holder.item_catch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getRecItemClick().onItemClick(position, catchModel, type, holder);
                }
            });
        } else {
//            holder.layout_send.setVisibility(View.GONE);
//            holder.layout_select.setVisibility(View.GONE);
            ILFactory.getLoader().loadNet(holder.iv_image, catchModel.getDollImage(), null);
            holder.tv_name.setText(catchModel.getDollName());
            holder.tv_sending.setText(catchModel.getStatusText());
            holder.tv_time.setText(catchModel.getDateTime());
        }
    }

    public void setOnSendClickListener(OnSendClickListener onSendClickListener) {
        this.onSendClickListener = onSendClickListener;
    }

    public void setOnExchangeClickListener(OnExchangeClickListener onExchangeClickListener) {
        this.onExchangeClickListener = onExchangeClickListener;
    }

    public void setOnLogisticsClickListener(OnLogisticsClickListener onLogisticsClickListener) {
        this.onLogisticsClickListener = onLogisticsClickListener;
    }

    @Override
    public ViewHolder newViewHolder(View itemView) {
        return new ViewHolder(itemView);
    }

    @Override
    public int getLayoutId() {
        return R.layout.item_catch;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.iv_image)
        RoundedImageView iv_image;
        @BindView(R.id.tv_sending)
        TextView tv_sending;
        @BindView(R.id.image_rl)
        RelativeLayout imageRl;
        @BindView(R.id.tv_name)
        TextView tv_name;
        @BindView(R.id.tv_time)
        TextView tv_time;
        @BindView(R.id.item_catch)
        BoraxShaderLinearLayoutWithPadding item_catch;

        public ViewHolder(View itemView) {
            super(itemView);
            KnifeKit.bind(this, itemView);
        }
    }

    public interface OnSendClickListener {
        void onSendClicked(CatchModel catchModel, int position);
    }

    public interface OnExchangeClickListener {
        void onExchangeClicked(CatchModel catchModel, int position);
    }

    public interface OnLogisticsClickListener {
        void onLogisticsClicked(CatchModel catchModel, int position);
    }
}
