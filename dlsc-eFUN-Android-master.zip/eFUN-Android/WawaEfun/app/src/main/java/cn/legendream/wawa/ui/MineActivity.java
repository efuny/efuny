package cn.legendream.wawa.ui;

import android.app.Activity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.tencent.bugly.crashreport.CrashReport;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.event.BusProvider;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.event.LogoutEvent;
import cn.legendream.wawa.event.RefreshCatchEvent;
import cn.legendream.wawa.event.RefreshMessageEvent;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.Account;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.ConactInfoModel;
import cn.legendream.wawa.model.SubmitCodeParam;
import cn.legendream.wawa.model.UserInfoModel;
import cn.legendream.wawa.model.UserMessageInfoModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.present.MinePresent;
import cn.legendream.wawa.view.CustomDialog;
import cn.legendream.wawa.view.InviteDialog;
import de.hdodenhof.circleimageview.CircleImageView;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: MineActivity
 * @author: Samson.Sun
 * @date: 2017-12-8 18:01
 * @email: s_xin@neusoft.com
 */
public class MineActivity extends XActivity<MinePresent> implements AppBarLayout.OnOffsetChangedListener {
    @BindView(R.id.app_bar)
    AppBarLayout app_bar;
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.toolbar_layout)
    CollapsingToolbarLayout toolbar_layout;
    @BindView(R.id.item_detail_container)
    NestedScrollView item_detail_container;
    @BindView(R.id.toolbar_title)
    TextView toolbar_title;
    @BindView(R.id.tv_user_name)
    TextView tv_user_name;
    @BindView(R.id.iv_user_id)
    TextView iv_user_id;
    @BindView(R.id.tv_score_num)
    TextView tv_score_num;
    //    @BindView(R.id.tv_money_num)
//    TextView tv_money_num;
    @BindView(R.id.profile_image)
    CircleImageView profile_image;
    @BindView(R.id.iv_message_new)
    ImageView iv_message_new;
    private int maxMarginTop = 0;
    private int maxMarginLeft = 0;
    private int maxMarginRight = 0;
    private int EXPEND_MARGIN_TOP = 0;//展开后margin
    private String sinaConect = "";
    private String wechatConect = "";
    private InviteDialog inviteDialog;
    public static final String PARAM_MESSAGE = "param_message";

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        setSupportActionBar(toolbar);
        Utils.awakeApp(context);
        if (TextUtils.isEmpty(AppContext.getAccount().getNickName())) {
            AppContext.getAccount().setNickName("");
        }
        toolbar_title.setText(AppContext.getAccount().getNickName());
        tv_user_name.setText(AppContext.getAccount().getNickName());
        iv_user_id.setText(Utils.formatStrings(context, R.string.user_id, AppContext.getAccount().getUserId()));
        ILFactory.getLoader().loadNet(profile_image, AppContext.getAccount().getHeadUrl(), null);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(false);
        }
        EXPEND_MARGIN_TOP = Kits.Dimens.dpToPxInt(context, 10);
        ViewGroup.MarginLayoutParams marginParams = getMarginLayoutParams(item_detail_container);
        maxMarginTop = marginParams.topMargin;
        maxMarginLeft = marginParams.leftMargin;
        maxMarginRight = marginParams.rightMargin;
        app_bar.addOnOffsetChangedListener(this);
        getP().getContactInfo();
        final UserParam userParam = new UserParam();
        userParam.setUserId(AppContext.getAccount().getUserId());
        getP().getUserInfo(userParam);
//        tv_money_num.setTypeface(Utils.getCondensedBold(context));
        tv_score_num.setTypeface(Utils.getCondensedBold(context));
        BusProvider.getBus().toFlowable(LogoutEvent.class)
                .subscribe(new Consumer<LogoutEvent>() {
                    @Override
                    public void accept(LogoutEvent logoutEvent) throws Exception {
                        finish();
                    }
                });

        BusProvider.getBus().toFlowable(RefreshCatchEvent.class)
                .subscribe(new Consumer<RefreshCatchEvent>() {
                    @Override
                    public void accept(RefreshCatchEvent payEvent) throws Exception {
                        getP().getUserInfo(userParam);
                    }
                });

        getP().getUserMessageInfo(new UserParam(AppContext.getAccount().getUserId()));
        BusProvider.getBus().toFlowable(RefreshMessageEvent.class)
                .subscribe(new Consumer<RefreshMessageEvent>() {
                    @Override
                    public void accept(RefreshMessageEvent refreshMessageEvent) {
                        getP().getUserMessageInfo(new UserParam(AppContext.getAccount().getUserId()));
                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
//        tv_money_num.setText(AppContext.getAccount().getGameMoney());
        tv_score_num.setText(AppContext.getAccount().getUserPoint());
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_mine;
    }

    @Override
    public MinePresent newP() {
        return new MinePresent();
    }

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(MineActivity.class)
                .launch();
    }

    @Override
    public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
        int maxHeight = toolbar.getHeight() - app_bar.getHeight();
        if (verticalOffset == 0) {
            setMargin(maxMarginTop);
            toolbar_title.setAlpha(0);
        } else if (verticalOffset == maxHeight) {
            setMargin(EXPEND_MARGIN_TOP);
            toolbar_title.setAlpha(1);
        } else {
            setMargin(maxMarginTop * (maxHeight - verticalOffset) / maxHeight + EXPEND_MARGIN_TOP * verticalOffset / maxHeight);
            toolbar_title.setAlpha(0);
        }
    }

    private void setMargin(int px) {
        ViewGroup.MarginLayoutParams marginParams = getMarginLayoutParams(item_detail_container);
        marginParams.setMargins(maxMarginLeft, px, maxMarginRight, 0);
        item_detail_container.setLayoutParams(marginParams);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @OnClick({R.id.iv_back, R.id.layout_my_money, R.id.layout_bill, R.id.layout_score,
            R.id.layout_my_baby, R.id.layout_my_ask_num, R.id.layout_input_ask_num,
            R.id.iv_message, R.id.iv_setting, R.id.layout_customer, R.id.layout_my_address, R.id.layout_score_shop})
    void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                finish();
                break;
            case R.id.layout_my_money:
                if (!Utils.isFastClick()) {
                    MyAccountActivity.launch(context);
                }
                break;

            case R.id.layout_bill:
                if (!Utils.isFastClick()) {
                    ConsumptionActivity.launch(context);
                }
                break;

            case R.id.layout_score:
                if (!Utils.isFastClick()) {
                    ScoreActivity.launch(context);
                }
                break;

            case R.id.layout_my_baby:
                if (!Utils.isFastClick()) {
                    RecordActivity.launch(context);
                }
                break;

            case R.id.layout_my_ask_num:
                if (!Utils.isFastClick()) {
                    InviteActivity.launch(context);
                }
                break;

            case R.id.layout_input_ask_num:
                String inputCode = Utils.paste(context);
                if (Kits.Empty.check(inputCode) || inputCode.length() != 7 || !Utils.isNumeric(inputCode)) {
                    inputCode = "";
                }
                inviteDialog = new InviteDialog.Builder(context)
                        .setCode(inputCode)
                        .setOnSubmitClickListener(new InviteDialog.OnSubmitClickListener() {
                            @Override
                            public void onCodeChange(DialogInterface dialog, String code) {
                                hideSoftKeyBoard();
                                if (Kits.Empty.check(code)) {
                                    toast(R.string.please_input_code);
                                    return;
                                }
                                SubmitCodeParam submitCodeParam = new SubmitCodeParam();
                                submitCodeParam.setUserId(AppContext.getAccount().getUserId());
                                submitCodeParam.setCode(code);
                                getP().submitUserCode(submitCodeParam);
                            }
                        }).create();
                inviteDialog.show();
                break;

            case R.id.iv_message:
                if (!Utils.isFastClick()) {
                    iv_message_new.setVisibility(View.GONE);
                    MessageActivity.launch(context);
                }
                break;

            case R.id.iv_setting:
                if (!Utils.isFastClick()) {
                    SettingActivity.launch(context);
                }
                break;

            case R.id.layout_customer:
                CustomDialog.Builder builder = new CustomDialog
                        .Builder(this)
                        .setTitle(getString(R.string.contact_customer))
                        .setContent(Utils.formatStrings(context, R.string.contact_wechat, wechatConect)
                                , Utils.formatStrings(context, R.string.contact_webo, sinaConect))
                        .setNegativeButton(getString(R.string.closed),
                                new android.content.DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                builder.create().show();
                break;

            case R.id.layout_my_address:
                if (!Utils.isFastClick()) {
                    AddressActivity.launch(context);
                }
                break;
            case R.id.layout_score_shop:
                String url = SharedPref.getInstance(context).getString(Keys.SCORE_SHOP_URL, "");
                if (TextUtils.isEmpty(url)) {
                    url = Api.DUI_BA_PATH;
                }
                ShopActivity.launch(context, url, getString(R.string.score_shop));
                break;
        }
    }

    public void showConectInfo(BaseModel<ConactInfoModel> result) {
        wechatConect = result.getData().getWchat();
        sinaConect = result.getData().getWeibo();
    }

    public void setUserInfo(BaseModel<UserInfoModel> result) {
        Account account = AppContext.getAccount();
        account.setGameMoney(result.getData().getGameMoney());
        account.setUserPoint(result.getData().getUserPoint());
        account.setHeadUrl(result.getData().getHeadUrl());
        SharedPref.getInstance(context).put(Keys.ACCOUNT, account);
        AppContext.setAccount(account);
//        tv_money_num.setText(AppContext.getAccount().getGameMoney());
        tv_score_num.setText(AppContext.getAccount().getUserPoint());
    }

    public void inputCodeResult(BaseModel result) {
        if (result.getResult().equals("1")) {
            toast(R.string.input_code_success);
            inviteDialog.dismiss();
        } else {
            toast(result.getMsg());
        }
    }

    public void isShowNewMessage(BaseModel<UserMessageInfoModel> resultModel) {
        //0 没有新消息 1有新消息
        if (resultModel.getData().getIsNew().equals("1")) {
            iv_message_new.setVisibility(View.VISIBLE);
        } else {
            iv_message_new.setVisibility(View.GONE);
        }
    }
}
