package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: InviteParam
 * @author: Samson.Sun
 * @date: 2017-12-21 9:08
 * @email: s_xin@neusoft.com
 */
public class InviteParam {
    public InviteParam() {
    }
    private String userId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
