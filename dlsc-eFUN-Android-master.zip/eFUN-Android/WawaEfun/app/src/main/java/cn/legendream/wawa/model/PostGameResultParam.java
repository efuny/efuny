package cn.legendream.wawa.model;

/**
 * Created by zhaoyuefeng on 2018/8/30.
 * Description
 */

public class PostGameResultParam {

    private String orderId;
    private String orderStatus;

    public PostGameResultParam() {
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }
}
