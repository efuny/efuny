package cn.legendream.wawa.event;

import cn.droidlover.xdroidmvp.event.IBus;

/**
 * @version V1.0 <>
 * @FileName: PayEvent
 * @author: Samson.Sun
 * @date: 2018-1-22 17:37
 * @email: s_xin@neusoft.com
 */
public class PayEvent implements IBus.IEvent {
    @Override
    public int getTag() {
        return 0;
    }
}
