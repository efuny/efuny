package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.CatchDetailExpressModel;
import cn.legendream.wawa.model.CatchDetailModel;
import cn.legendream.wawa.model.OrderExchangeInfoModel;
import cn.legendream.wawa.model.OrderParam;
import cn.legendream.wawa.model.UserOrderModel;
import cn.legendream.wawa.model.UserOrderParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.CatchDetailActivity;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: CatchDetailPresent
 * @author: Samson.Sun
 * @date: 2018-5-21 16:20
 * @email: s_xin@neusoft.com
 */
public class CatchDetailPresent extends XPresent<CatchDetailActivity> {
    public void userGrabRecordInfo(UserOrderParam userOrderParam) {
        Api.getSimpleService().userGrabRecordInfo(NetUtil.createRequestBody(userOrderParam))
                .compose(XApi.<BaseModel<CatchDetailModel>>getApiTransformer())
                .compose(XApi.<BaseModel<CatchDetailModel>>getScheduler())
                .compose(getV().<BaseModel<CatchDetailModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<CatchDetailModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<CatchDetailModel> result) {
                        getV().hideProgress();
                        getV().showDetail(result.getData());
                    }
                });
    }

    public void userOrderChangeScore(UserOrderParam userOrderParam) {
        Api.getSimpleService().userOrderChangeScore(NetUtil.createRequestBody(userOrderParam))
                .compose(XApi.<BaseModel<UserOrderModel>>getApiTransformer())
                .compose(XApi.<BaseModel<UserOrderModel>>getScheduler())
                .compose(getV().<BaseModel<UserOrderModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<UserOrderModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<UserOrderModel> result) {
                        getV().hideProgress();
                        getV().exchangeResult(result, true);
                    }
                });
    }

    public void orderExchangeInfo(final UserOrderParam userOrderParam) {
        Api.getSimpleService().orderExchangeInfo(NetUtil.createRequestBody(userOrderParam))
                .compose(XApi.<BaseModel<OrderExchangeInfoModel>>getApiTransformer())
                .compose(XApi.<BaseModel<OrderExchangeInfoModel>>getScheduler())
                .compose(getV().<BaseModel<OrderExchangeInfoModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<OrderExchangeInfoModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<OrderExchangeInfoModel> result) {
                        getV().hideProgress();
                        getV().exchangeInfo(result, userOrderParam.getOrderId());
                    }
                });
    }

    public void userOrderChangeGameIntegral(final UserOrderParam userOrderParam) {
        Api.getSimpleService().userOrderChangeGameIntegral(NetUtil.createRequestBody(userOrderParam))
                .compose(XApi.<BaseModel<UserOrderModel>>getApiTransformer())
                .compose(XApi.<BaseModel<UserOrderModel>>getScheduler())
                .compose(getV().<BaseModel<UserOrderModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<UserOrderModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<UserOrderModel> result) {
                        getV().hideProgress();
                        getV().exchangeResult(result, false);
                    }
                });
    }

    public void expressInfo(final UserOrderParam userOrderParam) {

        Api.getSimpleService().catchDetailExpress(NetUtil.createRequestBody(userOrderParam))
                .compose(XApi.<BaseModel<CatchDetailExpressModel>>getApiTransformer())
                .compose(XApi.<BaseModel<CatchDetailExpressModel>>getScheduler())
                .compose(getV().<BaseModel<CatchDetailExpressModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                }).subscribe(new ApiSubscriber<BaseModel<CatchDetailExpressModel>>() {
            @Override
            public void onNext(BaseModel<CatchDetailExpressModel> result) {
                getV().hideProgress();
                getV().expressInfoResult(result);
            }

            @Override
            protected void onFail(NetError error) {
                getV().showError(error);
            }
        });

    }

}
