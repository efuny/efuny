package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: DeliverSubmitParam
 * @author: Samson.Sun
 * @date: 2018-1-19 11:20
 * @email: s_xin@neusoft.com
 */
public class DeliverSubmitParam {
    public DeliverSubmitParam() {
    }
    private String userId;
    private String orderIds;
    private String addressId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOrderIds() {
        return orderIds;
    }

    public void setOrderIds(String orderIds) {
        this.orderIds = orderIds;
    }

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }
}
