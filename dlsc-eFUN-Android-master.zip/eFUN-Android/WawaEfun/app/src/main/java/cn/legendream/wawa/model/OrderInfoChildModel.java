package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: OrderInfoChildModel
 * @author: Samson.Sun
 * @date: 2018-7-20 1:12
 * @email: s_xin@neusoft.com
 */
public class OrderInfoChildModel {
    public OrderInfoChildModel() {
    }

    private String price;
    private String integral;
    private String orderNumber;
    private String createTime;

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }
}
