package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: OrderExchangeInfoModel
 * @author: Samson.Sun
 * @date: 2018-6-8 17:31
 * @email: s_xin@neusoft.com
 */
public class OrderExchangeInfoModel {
    public OrderExchangeInfoModel() {
    }

    private String text;
    private String userPoint;//第一个选项文字
    private String gameIntegral;//第二个选项文字
    private String selectIndex;//默认选中 0第一个 1第二个
    private String new_userPoint;
    private String new_gameIntegral;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getUserPoint() {
        return userPoint;
    }

    public void setUserPoint(String userPoint) {
        this.userPoint = userPoint;
    }

    public String getGameIntegral() {
        return gameIntegral;
    }

    public void setGameIntegral(String gameIntegral) {
        this.gameIntegral = gameIntegral;
    }

    public String getSelectIndex() {
        return selectIndex;
    }

    public void setSelectIndex(String selectIndex) {
        this.selectIndex = selectIndex;
    }

    public String getNew_userPoint() {
        return new_userPoint;
    }

    public void setNew_userPoint(String new_userPoint) {
        this.new_userPoint = new_userPoint;
    }

    public String getNew_gameIntegral() {
        return new_gameIntegral;
    }

    public void setNew_gameIntegral(String new_gameIntegral) {
        this.new_gameIntegral = new_gameIntegral;
    }
}
