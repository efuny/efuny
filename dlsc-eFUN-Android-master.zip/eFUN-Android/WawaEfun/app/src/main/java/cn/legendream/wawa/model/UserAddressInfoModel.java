package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: UserAddressInfoModel
 * @author: Samson.Sun
 * @date: 2018-7-18 0:36
 * @email: s_xin@neusoft.com
 */
public class UserAddressInfoModel {
    public UserAddressInfoModel() {
    }

    private String address;
    private String userAddressPerson;
    private String userAddressMobile;
    private String userAddressId;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUserAddressPerson() {
        return userAddressPerson;
    }

    public void setUserAddressPerson(String userAddressPerson) {
        this.userAddressPerson = userAddressPerson;
    }

    public String getUserAddressMobile() {
        return userAddressMobile;
    }

    public void setUserAddressMobile(String userAddressMobile) {
        this.userAddressMobile = userAddressMobile;
    }

    public String getUserAddressId() {
        return userAddressId;
    }

    public void setUserAddressId(String userAddressId) {
        this.userAddressId = userAddressId;
    }
}
