package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: LoginParam
 * @author: Samson.Sun
 * @date: 2017-12-8 9:44
 * @email: s_xin@neusoft.com
 */
public class LoginParam {
    public LoginParam() {
    }

    private String nickName;
    private String headUrl;
    private String gender;
    private String unionId;

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getHeadUrl() {
        return headUrl;
    }

    public void setHeadUrl(String headUrl) {
        this.headUrl = headUrl;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getUnionId() {
        return unionId;
    }

    public void setUnionId(String unionId) {
        this.unionId = unionId;
    }
}
