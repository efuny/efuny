package cn.legendream.wawa.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.joooonho.SelectableRoundedImageView;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.kit.KnifeKit;
import cn.legendream.wawa.R;
import cn.legendream.wawa.model.ExchangeLogModel;

/**
 * @version V1.0 <>
 * @FileName: ExchangeAdapter
 * @author: Samson.Sun
 * @date: 2018-7-18 23:54
 * @email: s_xin@neusoft.com
 */
public class ExchangeAdapter extends SimpleRecAdapter<ExchangeLogModel, ExchangeAdapter.ViewHolder> {
    public ExchangeAdapter(Context context) {
        super(context);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final ExchangeLogModel exchangeLogModel = data.get(position);
        ILFactory.getLoader().loadNet(holder.iv_shop_image, exchangeLogModel.getGoodImageUrl(), null);
        holder.tv_good_name.setText(exchangeLogModel.getGoodName());
        if (TextUtils.isEmpty(exchangeLogModel.getIntegral())) {
            holder.tv_good_score.setVisibility(View.GONE);
            holder.tv_score.setVisibility(View.GONE);
        } else {
            int score = Integer.parseInt(exchangeLogModel.getIntegral());
            if (score > 0) {
                holder.tv_good_score.setVisibility(View.VISIBLE);
                holder.tv_score.setVisibility(View.VISIBLE);
                holder.tv_good_score.setText(exchangeLogModel.getIntegral());
            } else {
                holder.tv_good_score.setVisibility(View.GONE);
                holder.tv_score.setVisibility(View.GONE);
            }
        }
        if (TextUtils.isEmpty(exchangeLogModel.getPrice())) {
            holder.tv_good_and.setVisibility(View.GONE);
            holder.tv_good_price.setVisibility(View.GONE);
            holder.tv_good_money.setVisibility(View.GONE);
        } else {
            double price = Double.parseDouble(exchangeLogModel.getPrice());
            if (price > 0) {
                holder.tv_good_and.setVisibility(View.VISIBLE);
                holder.tv_good_price.setVisibility(View.VISIBLE);
                holder.tv_good_money.setVisibility(View.VISIBLE);
                holder.tv_good_price.setText(exchangeLogModel.getPrice());
            } else {
                holder.tv_good_and.setVisibility(View.GONE);
                holder.tv_good_price.setVisibility(View.GONE);
                holder.tv_good_money.setVisibility(View.GONE);
            }
        }
        holder.iv_exchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getRecItemClick() != null) {
                    getRecItemClick().onItemClick(position, exchangeLogModel, 0, holder);
                }
            }
        });
        holder.iv_exchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getRecItemClick() != null) {
                    getRecItemClick().onItemClick(position, exchangeLogModel, 0, holder);
                }
            }
        });
    }

    @Override
    public ViewHolder newViewHolder(View itemView) {
        return new ViewHolder(itemView);
    }

    @Override
    public int getLayoutId() {
        return R.layout.item_exchange;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.layout_item)
        View layout_item;
        @BindView(R.id.iv_shop_image)
        SelectableRoundedImageView iv_shop_image;
        @BindView(R.id.tv_good_name)
        TextView tv_good_name;
        @BindView(R.id.tv_good_score)
        TextView tv_good_score;
        @BindView(R.id.tv_score)
        TextView tv_score;
        @BindView(R.id.tv_good_and)
        TextView tv_good_and;
        @BindView(R.id.tv_good_price)
        TextView tv_good_price;
        @BindView(R.id.tv_good_money)
        TextView tv_good_money;
        @BindView(R.id.iv_exchange)
        ImageView iv_exchange;

        public ViewHolder(View itemView) {
            super(itemView);
            KnifeKit.bind(this, itemView);
        }
    }
}
