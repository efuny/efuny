package cn.legendream.wawa.view;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import cn.legendream.wawa.R;

/**
 * @version V1.0 <>
 * @FileName: PayDialog
 * @author: Samson.Sun
 * @date: 2018-7-25 10:43
 * @email: s_xin@neusoft.com
 */
public class PayDialog extends Dialog {
    public PayDialog(@NonNull Context context) {
        super(context);
    }

    public interface OnWechatPayClickListener {
        void onWechatPay(DialogInterface dialog, String score, double money);
    }

    public interface OnAlipayPayClickListener {
        void onAlipayPay(DialogInterface dialog, String score, double money);
    }

    public PayDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    public static class Builder {
        private Context context;
        private ImageView alipayIv;
        private ImageView wechatIv;
        private ImageView closeIv;
        private OnWechatPayClickListener onWechatPayClickListener;
        private OnAlipayPayClickListener onAlipayPayClickListener;
        private String score;
        private double money;

        public Builder(Context context) {
            this.context = context;
        }

        public Builder setMessage(String score, double money) {
            this.money = money;
            this.score = score;
            return this;
        }

        public Builder setOnWechatPayClickListener(OnWechatPayClickListener onWechatPayClickListener) {
            this.onWechatPayClickListener = onWechatPayClickListener;
            return this;
        }

        public Builder setOnAlipayPayClickListener(OnAlipayPayClickListener onAlipayPayClickListener) {
            this.onAlipayPayClickListener = onAlipayPayClickListener;
            return this;
        }

        public PayDialog create() {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final PayDialog dialog = new PayDialog(context, R.style.Dialog);
            View layout = inflater.inflate(R.layout.send_baby_dialog, null);
            alipayIv = layout.findViewById(R.id.ali_iv);
            wechatIv = layout.findViewById(R.id.wechat_iv);
            closeIv = layout.findViewById(R.id.close_iv);
            alipayIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onAlipayPayClickListener.onAlipayPay(dialog, score, money);
                }
            });
            wechatIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onWechatPayClickListener.onWechatPay(dialog, score, money);
                }
            });
            closeIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
            dialog.setContentView(layout);
            return dialog;
        }
    }
}
