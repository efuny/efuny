package cn.legendream.wawa.kit;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.text.Html;
import android.text.TextUtils;
import android.view.WindowManager;

import com.tencent.bugly.crashreport.CrashReport;

import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import cn.droidlover.xdroidmvp.kit.Kits;
import cn.legendream.wawa.AppContext;

/**
 * @version V1.0 <>
 * @FileName: Utils
 * @author: Samson.Sun
 * @date: 2017-12-10 1:06
 * @email: s_xin@neusoft.com
 */
public class Utils {
    private static final int MIN_DELAY_TIME = 300;  // 两次点击间隔不能少于300ms
    private static long lastClickTime;

    /**
     * 获得状态栏的高度
     */
    public static int getStatusHeight(Context context) {
        int statusHeight = -1;
        try {
            Class<?> clazz = Class.forName("com.android.internal.R$dimen");
            Object object = clazz.newInstance();
            int height = Integer.parseInt(clazz.getField("status_bar_height").get(object).toString());
            statusHeight = context.getResources().getDimensionPixelSize(height);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return statusHeight;
    }

    public static String formatStrings(Context context, int resId, Object... str) {
        String formatString = context.getResources().getString(resId);
        return String.format(formatString, str);
    }

    /**
     * 复制
     *
     * @param content
     */
    public static void copy(Context context, String content) {
        ClipboardManager cmb = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("eq", content);
        cmb.setPrimaryClip(clip);
    }

    /**
     * 粘贴
     */
    public static String paste(Context context) {
        CharSequence pasteData = null;
        try {
            ClipboardManager cmb = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clipData = cmb.getPrimaryClip();
            if (clipData == null) {
                return null;
            }
            ClipData.Item item = clipData.getItemAt(0);
            // 获取剪贴板中的文本
            pasteData = item.getText();
            if (pasteData == null) {
                return null;
            }
        } catch (Exception e) {
            pasteData = null;
        }
        if (pasteData == null) {
            return null;
        }
        return pasteData.toString().trim();
    }

    public static String parseDesc(String desc) {
        String content = Html.fromHtml(desc).toString().replaceAll("[\\n\\r\\s\\t]", "").trim();
        return stringFilter(toDBC(content));
    }

    /**
     * 半角转换为全角
     *
     * @param input
     * @return
     */
    private static String toDBC(String input) {
        char[] c = input.toCharArray();
        for (int i = 0; i < c.length; i++) {
            if (c[i] == 12288) {
                c[i] = (char) 32;
                continue;
            }
            if (c[i] > 65280 && c[i] < 65375)
                c[i] = (char) (c[i] - 65248);
        }
        return new String(c);
    }

    /**
     * 去除特殊字符或将所有中文标号替换为英文标号
     *
     * @param str
     * @return
     */
    private static String stringFilter(String str) {
        str = str.replaceAll("【", "[").replaceAll("】", "]")
                .replaceAll("！", "!").replaceAll("：", ":");// 替换中文标号
        return str.replaceAll("[『』]", "").trim();
    }

    /**
     * 利用正则表达式判断字符串是否是数字
     *
     * @param str
     * @return
     */
    public static boolean isNumeric(String str) {
        Pattern pattern = Pattern.compile("[0-9]*");
        Matcher isNum = pattern.matcher(str);
        if (!isNum.matches()) {
            return false;
        }
        return true;
    }

    /**
     * @param @param  mobile
     * @param @return 设定文件
     * @return boolean 返回类型
     * @throws
     * @Title: 验证手机号码
     * @Description: TODO
     */
    public static boolean checkMobile(String mobile) {
        String regex = "(\\+\\d+)?1[34578]\\d{9}$";
        return Pattern.matches(regex, mobile);
    }

    /**
     * @param @param  phone
     * @param @return 设定文件
     * @return boolean 返回类型
     * @throws
     * @Title: 验证固话
     * @Description: TODO
     */
    public static boolean checkPhone(String phone) {
        String regex = "(\\+\\d+)?(\\d{3,4}\\-?)?\\d{7,8}$";
        return Pattern.matches(regex, phone);
    }

    public static String hidePhone(String phone) {
        if (Kits.Empty.check(phone) || phone.length() < 5) {
            return "";
        } else {
            return phone.replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2");
        }
    }

    public static Typeface getGoTrialFont(Context context) {
        Typeface typeFace = Typeface.createFromAsset(context.getAssets(), "fonts/RTWSYueGoTrial.otf");
        return typeFace;
    }

    public static Typeface getCondensedBold(Context context) {
        Typeface typeFace = Typeface.createFromAsset(context.getAssets(), "fonts/DINCondensedBold.ttf");
        return typeFace;
    }

    public static int getAppVersionCode(Context context) {
        int versionCode = 0;
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo(
                    context.getPackageName(), 0);
            versionCode = info.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
        }
        return versionCode;
    }

    public static boolean isFastClick() {
        boolean flag = true;
        long currentClickTime = System.currentTimeMillis();
        if ((currentClickTime - lastClickTime) >= MIN_DELAY_TIME) {
            flag = false;
        }
        lastClickTime = currentClickTime;
        return flag;
    }

    public static void awakeApp(Context context) {
        if (AppContext.getAccount() == null || TextUtils.isEmpty(AppContext.getAccount().getUserId())) {
            CrashReport.postCatchedException(new NullPointerException(context.getPackageName() + ":userId丢失-重新登陆"));
            Utils.restartApplication(context);
            return;
        }
    }

    public static void restartApplication(Context context) {
        final Intent intent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(intent);
    }

    public static int getScreenWidth(Activity activity) {

        WindowManager manager = (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);

        int width = manager.getDefaultDisplay().getWidth();

        return width;
    }

    public static int getScreenHeight(Activity activity) {

        WindowManager manager = (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);

        int height = manager.getDefaultDisplay().getHeight();

        return height;
    }

    /**
     * 根据手机的分辨率从 dp 的单位 转成为 px(像素)
     */
    public static int dip2px(Context context, float dpValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

}
