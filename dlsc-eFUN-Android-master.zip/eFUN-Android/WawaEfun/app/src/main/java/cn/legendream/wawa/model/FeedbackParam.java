package cn.legendream.wawa.model;

import java.util.List;

/**
 * @version V1.0 <>
 * @FileName: FeedbackParam
 * @author: Samson.Sun
 * @date: 2017-12-23 16:45
 * @email: s_xin@neusoft.com
 */
public class FeedbackParam {
    public FeedbackParam() {
    }

    private String userId;
    private String content;
    private String typeId;
    private List<String> images;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTypeId() {
        return typeId;
    }

    public void setTypeId(String typeId) {
        this.typeId = typeId;
    }

    public List<String> getImages() {
        return images;
    }

    public void setImages(List<String> images) {
        this.images = images;
    }
}
