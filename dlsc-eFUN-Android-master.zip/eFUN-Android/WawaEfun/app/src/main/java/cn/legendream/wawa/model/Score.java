package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: Score
 * @author: Samson.Sun
 * @date: 2017-12-20 21:16
 * @email: s_xin@neusoft.com
 */
public class Score {
    public Score() {
    }
    private String dollName;
    private String point;
    private String pointContent;
    private String dateTime;
    private String dollImageUrl;

    public String getDollName() {
        return dollName;
    }

    public void setDollName(String dollName) {
        this.dollName = dollName;
    }

    public String getPoint() {
        return point;
    }

    public void setPoint(String point) {
        this.point = point;
    }

    public String getPointContent() {
        return pointContent;
    }

    public void setPointContent(String pointContent) {
        this.pointContent = pointContent;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getDollImageUrl() {
        return dollImageUrl;
    }

    public void setDollImageUrl(String dollImageUrl) {
        this.dollImageUrl = dollImageUrl;
    }
}
