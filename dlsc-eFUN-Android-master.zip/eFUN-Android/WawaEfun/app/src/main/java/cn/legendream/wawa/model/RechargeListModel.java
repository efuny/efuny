package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: RechargeListModel
 * @author: Samson.Sun
 * @date: 2017-12-21 23:35
 * @email: s_xin@neusoft.com
 */
public class RechargeListModel {
    public RechargeListModel() {
    }

    private String packageName;
    private String packageTitle;
    private String packagePrice;
    private String packageGameMoney;
    private String packageImageUrl;
    private String packageId;
    private boolean isSelect = false;

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getPackageTitle() {
        return packageTitle;
    }

    public void setPackageTitle(String packageTitle) {
        this.packageTitle = packageTitle;
    }

    public String getPackagePrice() {
        return packagePrice;
    }

    public void setPackagePrice(String packagePrice) {
        this.packagePrice = packagePrice;
    }

    public String getPackageGameMoney() {
        return packageGameMoney;
    }

    public void setPackageGameMoney(String packageGameMoney) {
        this.packageGameMoney = packageGameMoney;
    }

    public String getPackageImageUrl() {
        return packageImageUrl;
    }

    public void setPackageImageUrl(String packageImageUrl) {
        this.packageImageUrl = packageImageUrl;
    }

    public String getPackageId() {
        return packageId;
    }

    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }

    public boolean isSelect() {
        return isSelect;
    }

    public void setSelect(boolean select) {
        isSelect = select;
    }
}
