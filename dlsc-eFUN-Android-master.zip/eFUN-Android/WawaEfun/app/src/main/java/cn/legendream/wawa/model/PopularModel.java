package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: PopularModel
 * @author: Samson.Sun
 * @date: 2018-7-17 23:26
 * @email: s_xin@neusoft.com
 */
public class PopularModel {
    public PopularModel() {
    }

    private String goodName;
    private String goodImageUrl;
    private String goodId;
    private String goodType;

    public String getGoodName() {
        return goodName;
    }

    public void setGoodName(String goodName) {
        this.goodName = goodName;
    }

    public String getGoodImageUrl() {
        return goodImageUrl;
    }

    public void setGoodImageUrl(String goodImageUrl) {
        this.goodImageUrl = goodImageUrl;
    }

    public String getGoodId() {
        return goodId;
    }

    public void setGoodId(String goodId) {
        this.goodId = goodId;
    }

    public String getGoodType() {
        return goodType;
    }

    public void setGoodType(String goodType) {
        this.goodType = goodType;
    }
}
