package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: MessageParam
 * @author: Samson.Sun
 * @date: 2017-12-27 14:21
 * @email: s_xin@neusoft.com
 */
public class MessageParam {
    public MessageParam() {
    }

    public String userId;
    public String page;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }
}
