package cn.legendream.wawa.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;


import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.droidlover.xdroidmvp.view.citypicker.Interface.OnCityItemClickListener;
import cn.droidlover.xdroidmvp.view.citypicker.bean.CityBean;
import cn.droidlover.xdroidmvp.view.citypicker.bean.DistrictBean;
import cn.droidlover.xdroidmvp.view.citypicker.bean.ProvinceBean;
import cn.droidlover.xdroidmvp.view.citypicker.citywheel.CityConfig;
import cn.droidlover.xdroidmvp.view.citypicker.style.citypickerview.CityPickerView;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.AddAddressParam;
import cn.legendream.wawa.model.AddressModel;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.present.AddAddressPresent;

/**
 * 新建地址
 *
 * @version V1.0 <>
 * @FileName: AddAddressActivity
 * @author: Samson.Sun
 * @date: 2017-12-8 20:30
 * @email: s_xin@neusoft.com
 */
public class AddAddressActivity extends XActivity<AddAddressPresent> {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.toolbar_title)
    TextView toolbar_title;
    @BindView(R.id.tv_choice_address)
    TextView tv_choice_address;
    @BindView(R.id.et_name)
    EditText et_name;
    @BindView(R.id.et_phone)
    EditText et_phone;
    @BindView(R.id.et_address)
    EditText et_address;
    @BindView(R.id.cbAddress)
    CheckBox cbAddress;
    @BindView(R.id.layout_choice_address)
    View layout_choice_address;
    private String provinceName = "";
    private String cityName = "";
    private String districtName = "";
    private boolean isEdit = false;
    private AddressModel addressModel;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        isEdit = getIntent().getBooleanExtra(Keys.IS_EDIT, false);
        if (isEdit) {
            addressModel = (AddressModel) getIntent().getSerializableExtra(Keys.EDIT_ADDRESS);
            toolbar_title.setText(R.string.update_address);
            et_name.setText(addressModel.getPerson());
            et_phone.setText(addressModel.getMobile());
            cbAddress.setChecked(addressModel.getIsDefault().equals("1"));
        }
        et_phone.setInputType(InputType.TYPE_CLASS_NUMBER);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_add_address;
    }

    @Override
    public AddAddressPresent newP() {
        return new AddAddressPresent();
    }

    @OnClick(R.id.layout_choice_address)
    void choiceAddress() {
        CityPickerView.getInstance().setConfig(new CityConfig.Builder(this).showBackground(false).build());
        CityPickerView.getInstance().setOnCityItemClickListener(new OnCityItemClickListener() {
            @Override
            public void onSelected(ProvinceBean province, CityBean city, DistrictBean district) {
                if (province != null) {
                    provinceName = province.getName();
                }
                if (city != null) {
                    cityName = city.getName() + getString(R.string.city);
                }
                if (district != null) {
                    districtName = district.getName();
                }
                tv_choice_address.setText(provinceName + "-" + cityName + "-" + districtName);
                tv_choice_address.setTextColor(context.getResources().getColor(R.color.black_55));
            }

            @Override
            public void onCancel() {
            }
        });
        CityPickerView.getInstance().showCityPicker(this);
    }

    @OnClick(R.id.tv_create_address)
    void save() {
        String name = et_name.getEditableText().toString().trim();
        if (TextUtils.isEmpty(name)) {
            toast(R.string.please_input_name);
            return;
        }
        String phoneNumber = et_phone.getEditableText().toString().trim();
        if (TextUtils.isEmpty(phoneNumber)) {
            toast(R.string.please_input_phone);
            return;
        }
        if (!Utils.checkMobile(phoneNumber) && !Utils.checkPhone(phoneNumber)) {
            toast(R.string.please_input_right_phone);
            return;
        }
        String address = et_address.getEditableText().toString().trim();
        if (TextUtils.isEmpty(address)) {
            toast(R.string.please_input_address);
            return;
        }
        if (TextUtils.isEmpty(provinceName) || TextUtils.isEmpty(cityName)) {
            toast(R.string.please_choice_address);
            return;
        }
        AddAddressParam addAddressParam = new AddAddressParam();
        addAddressParam.setIsDefault(cbAddress.isChecked() ? "1" : "0");
        addAddressParam.setProvince(provinceName);
        addAddressParam.setCity(cityName);
        addAddressParam.setArea(districtName);
        addAddressParam.setMobile(phoneNumber);
        addAddressParam.setPerson(name);
        addAddressParam.setAddress(address);
        addAddressParam.setUserId(AppContext.getAccount().getUserId());
        if (isEdit) {

        } else {
            getP().userEstablishAddress(addAddressParam);
        }
    }

    @OnClick(R.id.layout_default)
    void setDefault() {
        cbAddress.setChecked(!cbAddress.isChecked());
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    public static void launch(Activity activity, boolean isEdit, AddressModel model) {
        Router.newIntent(activity)
                .to(AddAddressActivity.class)
                .putBoolean(Keys.IS_EDIT, isEdit)
                .putSerializable(Keys.EDIT_ADDRESS, model)
                .requestCode(Keys.ADD_ADDRESS)
                .launch();
    }

    public void showData(BaseModel result) {
        if (result.getResult().equals("1")) {
            toast(R.string.add_address_success);
            Bundle bundle = new Bundle();
            bundle.putBoolean(Keys.ADD_ADDRESS_RESULT, true);
            setResult(RESULT_OK, new Intent().putExtras(bundle));
            finish();
        } else {
            toast(R.string.add_address_failed);
        }
    }
}
