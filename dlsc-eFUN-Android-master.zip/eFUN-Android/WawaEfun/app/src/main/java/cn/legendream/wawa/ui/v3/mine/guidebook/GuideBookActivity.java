package cn.legendream.wawa.ui.v3.mine.guidebook;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.R;

public class GuideBookActivity extends XActivity<GuideBookPresenter> {


    @BindView(R.id.webView)
    WebView webView;
    @BindView(R.id.iv_back)
    ImageView ivBack;

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(GuideBookActivity.class)
                .launch();
    }

    @Override
    public void initData(Bundle savedInstanceState) {

        getP().getAbout();

    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_web_view;
    }

    @Override
    public GuideBookPresenter newP() {
        return new GuideBookPresenter();
    }

    void showUrl(String url) {

        webView.loadUrl(url);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setUseWideViewPort(true); // 关键点
        webView.getSettings().setAllowFileAccess(true); // 允许访问文件
        webView.getSettings().setSupportZoom(true); // 支持缩放
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE); // 不加载缓存内容
        webView.getSettings().setDomStorageEnabled(true);

        webView.setWebViewClient(new WebViewClient());


    }

    @OnClick(R.id.iv_back)
    public void onViewClicked() {
        onBackPressed();
    }
}
