package cn.legendream.wawa.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.base.XFragmentAdapter;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.ui.fragment.BaseScoreFragment;
import cn.legendream.wawa.ui.fragment.ScoreExpensesFragment;
import cn.legendream.wawa.ui.fragment.ScoreGainFragment;

/**
 * 我的积分
 *
 * @version V1.0 <>
 * @FileName: ScoreActivity
 * @author: Samson.Sun
 * @date: 2017-12-8 19:55
 * @email: s_xin@neusoft.com
 */
public class ScoreActivity extends XActivity implements AppBarLayout.OnOffsetChangedListener, BaseScoreFragment.ScoreChanged {
    @BindView(R.id.app_bar)
    AppBarLayout app_bar;
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.toolbar_layout)
    CollapsingToolbarLayout toolbar_layout;
    @BindView(R.id.refreshLayout)
    View refreshLayout;
    @BindView(R.id.toolbar_title)
    TextView toolbar_title;
    @BindView(R.id.tv_score)
    TextView tv_score;
    @BindView(R.id.viewPager)
    ViewPager viewPager;
    @BindView(R.id.tabLayout)
    TabLayout tabLayout;
    private int maxMarginTop = 0;
    private int maxMarginLeft = 0;
    private int maxMarginRight = 0;
    private int EXPEND_MARGIN_TOP = 0;//展开后margin
    private String helpUrl = "";

    List<Fragment> fragmentList = new ArrayList<>();
    String[] titles;
    XFragmentAdapter adapter;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        setSupportActionBar(toolbar);
        Utils.awakeApp(context);
        fragmentList.clear();
        fragmentList.add(ScoreGainFragment.newInstance(this));
        fragmentList.add(ScoreExpensesFragment.newInstance(this));
        titles = new String[]{getString(R.string.score_gain), getString(R.string.score_expense)};
        if (adapter == null) {
            adapter = new XFragmentAdapter(getSupportFragmentManager(), fragmentList, titles);
        }
        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(2);

//        refreshLayout.setOnRefreshLoadmoreListener(this);
        tabLayout.setupWithViewPager(viewPager, true);
        for (int i = 0; i < titles.length; i++) {
            tabLayout.getTabAt(i).setCustomView(getTabText(i, titles));
            if (i == 0) {
                TextView tabViewDefault = tabLayout.getTabAt(0).getCustomView().findViewById(R.id.tv_tab_name);
                tabViewDefault.setTextColor(context.getResources().getColor(R.color.pink_84));
            }
        }
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                final TextView textView = tab.getCustomView().findViewById(R.id.tv_tab_name);
                textView.setTextColor(context.getResources().getColor(R.color.pink_84));
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                final TextView textView = tab.getCustomView().findViewById(R.id.tv_tab_name);
                textView.setTextColor(context.getResources().getColor(R.color.pink_c0));
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(false);
        }
        EXPEND_MARGIN_TOP = Kits.Dimens.dpToPxInt(context, 10);
        ViewGroup.MarginLayoutParams marginParams = getMarginLayoutParams(refreshLayout);
        maxMarginTop = marginParams.topMargin;
        maxMarginLeft = marginParams.leftMargin;
        maxMarginRight = marginParams.rightMargin;
        app_bar.addOnOffsetChangedListener(this);
        tv_score.setTypeface(Utils.getCondensedBold(context));
    }

    public View getTabText(int position, String[] titles) {
        View v = LayoutInflater.from(this).inflate(R.layout.tab_item, null);
        TextView tv = v.findViewById(R.id.tv_tab_name);
        tv.setText(titles[position]);
        tv.setTypeface(Utils.getGoTrialFont(context));
        return v;
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_score;
    }

    @Override
    public Object newP() {
        return null;
    }

    @Override
    public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
        int maxHeight = toolbar.getHeight() - app_bar.getHeight();
        if (verticalOffset == 0) {
            setMargin(maxMarginTop);
            toolbar_title.setAlpha(0);
        } else if (verticalOffset == maxHeight) {
            setMargin(EXPEND_MARGIN_TOP);
            toolbar_title.setAlpha(1);
        } else {
            setMargin(maxMarginTop * (maxHeight - verticalOffset) / maxHeight + EXPEND_MARGIN_TOP * verticalOffset / maxHeight);
            toolbar_title.setAlpha(0);
        }
    }

    private void setMargin(int px) {
        ViewGroup.MarginLayoutParams marginParams = getMarginLayoutParams(refreshLayout);
        marginParams.setMargins(maxMarginLeft, px, maxMarginRight, 0);
        refreshLayout.setLayoutParams(marginParams);
    }

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(ScoreActivity.class)
                .launch();
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    @OnClick(R.id.layout_exchange)
    void exchange() {
    }

    @OnClick(R.id.v_score)
    void help() {
        if (!Utils.isFastClick()) {
            WebActivity.launch(context, helpUrl, getString(R.string.help));
        }
    }

    @Override
    public void scoreChange(String score, String helpUrl) {
        tv_score.setText(score);
        this.helpUrl = helpUrl;
    }
}
