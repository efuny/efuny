package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: DeleteAddressParam
 * @author: Samson.Sun
 * @date: 2017-12-22 15:09
 * @email: s_xin@neusoft.com
 */
public class DeleteAddressParam {
    public DeleteAddressParam() {
    }

    private String userId;
    private String addressId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }
}
