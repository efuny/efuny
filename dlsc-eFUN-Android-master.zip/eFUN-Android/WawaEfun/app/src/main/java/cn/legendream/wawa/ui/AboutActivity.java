package cn.legendream.wawa.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.media.UMWeb;
import com.umeng.socialize.shareboard.SnsPlatform;
import com.umeng.socialize.utils.ShareBoardlistener;

import java.lang.ref.WeakReference;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.log.XLog;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.AboutModel;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.InvitationCodeModel;
import cn.legendream.wawa.present.AboutPresent;

/**
 * @version V1.0 <>
 * @FileName: AboutActivity
 * @author: Samson.Sun
 * @date: 2017-12-8 20:01
 * @email: s_xin@neusoft.com
 */
public class AboutActivity extends XActivity<AboutPresent> implements AppBarLayout.OnOffsetChangedListener {
    @BindView(R.id.app_bar)
    AppBarLayout app_bar;
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.toolbar_layout)
    CollapsingToolbarLayout toolbar_layout;
    @BindView(R.id.item_detail_container)
    NestedScrollView item_detail_container;
    @BindView(R.id.iv_version)
    TextView iv_version;
    private int maxMarginTop = 0;
    private int maxMarginLeft = 0;
    private int maxMarginRight = 0;
    private int EXPEND_MARGIN_TOP = 0;//展开后margin
    private AboutModel aboutModel;
    private UMShareListener mShareListener;
    private ShareAction mShareAction;
    private String shareUrl = "";
    private String codeFull = "";
    private String codePoint = "";

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        setSupportActionBar(toolbar);
        Utils.awakeApp(context);
        toolbar_layout.setTitle(AppContext.getAccount().getNickName());
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(false);
        }
        EXPEND_MARGIN_TOP = Kits.Dimens.dpToPxInt(context, 10);
        ViewGroup.MarginLayoutParams marginParams = getMarginLayoutParams(item_detail_container);
        maxMarginTop = marginParams.topMargin;
        maxMarginLeft = marginParams.leftMargin;
        maxMarginRight = marginParams.rightMargin;
        app_bar.addOnOffsetChangedListener(this);
        getP().getAbout();
        String versionCode = Kits.Package.getVersionName(context);
        iv_version.setText(Utils.formatStrings(context, R.string.version_code, versionCode));
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_about;
    }

    @Override
    public AboutPresent newP() {
        return new AboutPresent();
    }

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(AboutActivity.class)
                .launch();
    }

    @Override
    public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
        int maxHeight = toolbar.getHeight() - app_bar.getHeight();
        if (verticalOffset == 0) {
            setMargin(maxMarginTop);
        } else if (verticalOffset == maxHeight) {
            setMargin(EXPEND_MARGIN_TOP);
        } else {
            setMargin(maxMarginTop * (maxHeight - verticalOffset) / maxHeight + EXPEND_MARGIN_TOP * verticalOffset / maxHeight);
        }
    }

    private void setMargin(int px) {
        ViewGroup.MarginLayoutParams marginParams = getMarginLayoutParams(item_detail_container);
        marginParams.setMargins(maxMarginLeft, px, maxMarginRight, 0);
        item_detail_container.setLayoutParams(marginParams);
    }

    @OnClick({R.id.iv_back, R.id.layout_give_a_mark, R.id.layout_tell_friends,
            R.id.layout_feedback, R.id.layout_bug, R.id.layout_user_agreement})
    void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                finish();
                break;
            case R.id.layout_give_a_mark:
                //TODO 暂时隐藏
                break;

            case R.id.layout_tell_friends:
                mShareListener = new CustomShareListener(this);
                /*增加自定义按钮的分享面板*/
                mShareAction = new ShareAction(context).setDisplayList(
                        SHARE_MEDIA.WEIXIN, SHARE_MEDIA.WEIXIN_CIRCLE, SHARE_MEDIA.WEIXIN_FAVORITE,
                        SHARE_MEDIA.SINA, SHARE_MEDIA.QQ, SHARE_MEDIA.QZONE)
                        .setShareboardclickCallback(new ShareBoardlistener() {
                            @Override
                            public void onclick(SnsPlatform snsPlatform, SHARE_MEDIA share_media) {
                                UMWeb web = new UMWeb(aboutModel.getShareUrl());
                                web.setTitle(Utils.formatStrings(context, R.string.share_title, codePoint));
                                web.setDescription(Utils.formatStrings(context, R.string.share_content, codeFull));
                                web.setThumb(new UMImage(context, R.drawable.ic_share_img));
                                new ShareAction(context).withMedia(web)
                                        .setPlatform(share_media)
                                        .setCallback(mShareListener)
                                        .share();
                            }
                        });
                mShareAction.open();
                break;

            case R.id.layout_feedback:
                if (!Utils.isFastClick()) {
                    FeedbackActivity.launch(context);
                }
                break;

            case R.id.layout_bug:
                if (!Utils.isFastClick()) {
                    WebActivity.launch(context, aboutModel.getAgreementUrl(), getString(R.string.bug));
                }
                break;

            case R.id.layout_user_agreement:
                if (!Utils.isFastClick()) {
                    WebActivity.launch(context, aboutModel.getAgreementUrl(), getString(R.string.agreement));
                }
                break;
        }
    }

    public void showCode(BaseModel<InvitationCodeModel> result) {
        shareUrl = result.getData().getShareUrl();
        codePoint = result.getData().getCodePoint();
        codeFull = result.getData().getCode();
    }


    public void showUrl(BaseModel<AboutModel> result) {
        aboutModel = result.getData();
    }

    private static class CustomShareListener implements UMShareListener {

        private WeakReference<AboutActivity> mActivity;

        private CustomShareListener(AboutActivity activity) {
            mActivity = new WeakReference(activity);
        }

        @Override
        public void onStart(SHARE_MEDIA platform) {

        }

        @Override
        public void onResult(SHARE_MEDIA platform) {
            if (platform.name().equals("WEIXIN_FAVORITE")) {
                Toast.makeText(mActivity.get(), platform + " 收藏成功啦", Toast.LENGTH_SHORT).show();
            } else {
                if (platform != SHARE_MEDIA.MORE && platform != SHARE_MEDIA.SMS
                        && platform != SHARE_MEDIA.EMAIL
                        && platform != SHARE_MEDIA.FLICKR
                        && platform != SHARE_MEDIA.FOURSQUARE
                        && platform != SHARE_MEDIA.TUMBLR
                        && platform != SHARE_MEDIA.POCKET
                        && platform != SHARE_MEDIA.PINTEREST

                        && platform != SHARE_MEDIA.INSTAGRAM
                        && platform != SHARE_MEDIA.GOOGLEPLUS
                        && platform != SHARE_MEDIA.YNOTE
                        && platform != SHARE_MEDIA.EVERNOTE) {
                    Toast.makeText(mActivity.get(), " 分享成功啦", Toast.LENGTH_SHORT).show();
                }
            }
        }

        @Override
        public void onError(SHARE_MEDIA platform, Throwable throwable) {
            if (platform != SHARE_MEDIA.MORE && platform != SHARE_MEDIA.SMS
                    && platform != SHARE_MEDIA.EMAIL
                    && platform != SHARE_MEDIA.FLICKR
                    && platform != SHARE_MEDIA.FOURSQUARE
                    && platform != SHARE_MEDIA.TUMBLR
                    && platform != SHARE_MEDIA.POCKET
                    && platform != SHARE_MEDIA.PINTEREST

                    && platform != SHARE_MEDIA.INSTAGRAM
                    && platform != SHARE_MEDIA.GOOGLEPLUS
                    && platform != SHARE_MEDIA.YNOTE
                    && platform != SHARE_MEDIA.EVERNOTE) {
                Toast.makeText(mActivity.get(), " 分享失败啦", Toast.LENGTH_SHORT).show();
                if (throwable != null) {
                    XLog.d("throw", "throw:" + throwable.getMessage());
                }
            }
        }

        @Override
        public void onCancel(SHARE_MEDIA platform) {
            Toast.makeText(mActivity.get(), " 分享取消了", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        /** attention to this below ,must add this**/
        UMShareAPI.get(this).onActivityResult(requestCode, resultCode, data);
    }
}
