package cn.legendream.wawa.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.makeramen.roundedimageview.RoundedImageView;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.kit.KnifeKit;
import cn.legendream.wawa.R;
import cn.legendream.wawa.model.DollListInfoModel;
import cn.legendream.wawa.view.BoraxShaderLinearLayoutWithPadding;

/**
 * @version V1.0 <>
 * @FileName: SendBabyAdapter
 * @author: Samson.Sun
 * @date: 2017-12-21 17:12
 * @email: s_xin@neusoft.com
 */
public class SendBabyAdapter extends SimpleRecAdapter<DollListInfoModel, SendBabyAdapter.ViewHolder> {

    private OnCheckedListener onCheckedListener;
    private int itemWidth;

    public SendBabyAdapter(Context context, int width) {
        super(context);
        this.itemWidth = width;
    }

    @Override
    public ViewHolder newViewHolder(View itemView) {
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        ViewGroup.LayoutParams itemLp = holder.itemCatch.getLayoutParams();
        itemLp.width = itemWidth;
        itemLp.height = (int) (itemWidth * 1.3);
        holder.itemCatch.setLayoutParams(itemLp);

        ViewGroup.LayoutParams imageLp = holder.imageRl.getLayoutParams();
        imageLp.height = itemWidth;
        holder.imageRl.setLayoutParams(imageLp);

        final DollListInfoModel dollListInfoModel = data.get(position);

        holder.selectRl.setVisibility(View.GONE);

        ILFactory.getLoader().loadNet(holder.iv_image, dollListInfoModel.getDoll_img(), null);
        holder.tv_name.setText(dollListInfoModel.getDollName());
        holder.tv_time.setText(dollListInfoModel.getCreate_time());
        holder.selectRl.setVisibility(dollListInfoModel.getIsCheck().equals("0") ? View.GONE : View.VISIBLE);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (holder.selectRl.getVisibility() == View.VISIBLE) {

                    holder.selectRl.setVisibility(View.GONE);
                    dollListInfoModel.setIsCheck("0");
                    onCheckedListener.OnChecked(dollListInfoModel.getOrderId(), false, position);

                } else {

                    holder.selectRl.setVisibility(View.VISIBLE);
                    dollListInfoModel.setIsCheck("1");
                    onCheckedListener.OnChecked(dollListInfoModel.getOrderId(), true, position);

                }

//                holder.cbBaby.setChecked(!holder.cbBaby.isChecked());
//                dollListInfoModel.setIsCheck(dollListInfoModel.getIsCheck().equals("0") ? "1" : "0");
//                onCheckedListener.OnChecked(dollListInfoModel.getOrderId(), holder.cbBaby.isChecked(), position);
            }
        });
    }

    public void setOnCheckedListener(OnCheckedListener onCheckedListener) {
        this.onCheckedListener = onCheckedListener;
    }

    @Override
    public int getLayoutId() {
        return R.layout.item_catch_send;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.tv_name)
        TextView tv_name;
        @BindView(R.id.tv_time)
        TextView tv_time;
        @BindView(R.id.iv_image)
        RoundedImageView iv_image;
        @BindView(R.id.tv_sending)
        TextView tvSending;
        @BindView(R.id.image_rl)
        RelativeLayout imageRl;
        @BindView(R.id.select_rl)
        RelativeLayout selectRl;
        @BindView(R.id.item_catch)
        BoraxShaderLinearLayoutWithPadding itemCatch;

        public ViewHolder(View itemView) {
            super(itemView);
            KnifeKit.bind(this, itemView);
        }
    }

    public interface OnCheckedListener {
        void OnChecked(String orderId, boolean isChecked, int position);
    }
}
