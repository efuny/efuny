package cn.legendream.wawa.view;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;

/**
 * @version V1.0 <>
 * @FileName: LoginDialog
 * @author: Samson.Sun
 * @date: 2018-1-23 10:57
 * @email: s_xin@neusoft.com
 */
public class LoginDialog extends Dialog {
    public LoginDialog(Context context, int theme) {
        super(context, theme);
    }

    public static class Builder {
        private Context context;
        private String negativeButtonText;
        private OnLoginClickListener onLoginClickListener;

        public Builder(Context context) {
            this.context = context;
        }

        public LoginDialog.Builder setOnLoginClickListener(OnLoginClickListener onLoginClickListener) {
            this.onLoginClickListener = onLoginClickListener;
            return this;
        }

        public LoginDialog create() {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final LoginDialog dialog = new LoginDialog(context, R.style.Dialog);
            View layout = inflater.inflate(R.layout.dialog_login, null);

            final EditText et_username = layout.findViewById(R.id.et_username);
            final EditText et_password = layout.findViewById(R.id.et_password);

            ((Button) layout.findViewById(R.id.negativeButton)).setTypeface(Utils.getGoTrialFont(context));
            if (negativeButtonText != null) {
                ((Button) layout.findViewById(R.id.negativeButton))
                        .setText(negativeButtonText);
            }
            if (onLoginClickListener != null) {
                ((Button) layout.findViewById(R.id.negativeButton))
                        .setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {
                                onLoginClickListener.onClick(dialog,
                                        et_username.getEditableText().toString(), et_password.getEditableText().toString());
                            }
                        });
            }
            dialog.setContentView(layout);
            return dialog;
        }
    }

    public interface OnLoginClickListener {
        void onClick(DialogInterface dialog, String userName, String password);
    }
}
