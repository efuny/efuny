package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: DollInfo
 * @author: Samson.Sun
 * @date: 2017-12-16 18:58
 * @email: s_xin@neusoft.com
 */
public class DollInfo {
    public DollInfo() {
    }
    private String dollImg;
    private String dollHeight;
    private String dollName;

    public String getDollImg() {
        return dollImg;
    }

    public void setDollImg(String dollImg) {
        this.dollImg = dollImg;
    }

    public String getDollHeight() {
        return dollHeight;
    }

    public void setDollHeight(String dollHeight) {
        this.dollHeight = dollHeight;
    }

    public String getDollName() {
        return dollName;
    }

    public void setDollName(String dollName) {
        this.dollName = dollName;
    }
}
