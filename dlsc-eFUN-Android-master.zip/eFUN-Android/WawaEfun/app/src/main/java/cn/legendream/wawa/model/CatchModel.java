package cn.legendream.wawa.model;

import java.io.Serializable;

/**
 * @version V1.0 <>
 * @FileName: CatchModel
 * @author: Samson.Sun
 * @date: 2017-12-20 22:59
 * @email: s_xin@neusoft.com
 */
public class CatchModel implements Serializable {
    public CatchModel() {
    }

    private String dollImage;
    private String dollName;
    private String dollScore;
    private String statusText;
    private String dateTime;
    private String expressStatus;
    private String expressUrl;
    private String orderId;
    private String releaseText;

    public String getDollImage() {
        return dollImage;
    }

    public void setDollImage(String dollImage) {
        this.dollImage = dollImage;
    }

    public String getDollName() {
        return dollName;
    }

    public void setDollName(String dollName) {
        this.dollName = dollName;
    }

    public String getStatusText() {
        return statusText;
    }

    public void setStatusText(String statusText) {
        this.statusText = statusText;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getExpressStatus() {
        return expressStatus;
    }

    public void setExpressStatus(String expressStatus) {
        this.expressStatus = expressStatus;
    }

    public String getDollScore() {
        return dollScore;
    }

    public void setDollScore(String dollScore) {
        this.dollScore = dollScore;
    }

    public String getExpressUrl() {
        return expressUrl;
    }

    public void setExpressUrl(String expressUrl) {
        this.expressUrl = expressUrl;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getReleaseText() {
        return releaseText;
    }

    public void setReleaseText(String releaseText) {
        this.releaseText = releaseText;
    }
}
