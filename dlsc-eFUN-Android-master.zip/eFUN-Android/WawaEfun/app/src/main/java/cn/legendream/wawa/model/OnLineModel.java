package cn.legendream.wawa.model;

import java.util.List;

/**
 * @version V1.0 <>
 * @FileName: OnLineModel
 * @author: Samson.Sun
 * @date: 2017-12-16 19:07
 * @email: s_xin@neusoft.com
 */
public class OnLineModel {
    public OnLineModel() {
    }
    private int memberCount;
    private List<OnLineImageModel> memberList;

    public int getMemberCount() {
        return memberCount;
    }

    public void setMemberCount(int memberCount) {
        this.memberCount = memberCount;
    }

    public List<OnLineImageModel> getMemberList() {
        return memberList;
    }

    public void setMemberList(List<OnLineImageModel> memberList) {
        this.memberList = memberList;
    }

    public class OnLineImageModel{
        public OnLineImageModel() {
        }
        private String headUrl;

        public String getHeadUrl() {
            return headUrl;
        }

        public void setHeadUrl(String headUrl) {
            this.headUrl = headUrl;
        }
    }
}
