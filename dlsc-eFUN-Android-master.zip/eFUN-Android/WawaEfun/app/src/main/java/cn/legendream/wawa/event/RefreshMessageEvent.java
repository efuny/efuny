package cn.legendream.wawa.event;

import cn.droidlover.xdroidmvp.event.IBus;

/**
 * @version V1.0 <>
 * @FileName: RefreshMessageEvent
 * @author: Samson.Sun
 * @date: 2018-6-13 11:30
 * @email: s_xin@neusoft.com
 */
public class RefreshMessageEvent implements IBus.IEvent{
    @Override
    public int getTag() {
        return 0;
    }
}
