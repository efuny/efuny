package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: ConsumptionModel
 * @author: Samson.Sun
 * @date: 2018-4-3 9:40
 * @email: s_xin@neusoft.com
 */
public class ConsumptionModel {
    public ConsumptionModel() {
    }

    private String gameMoney;
    private String type;
    private String content;
    private String dateTime;

    public String getGameMoney() {
        return gameMoney;
    }

    public void setGameMoney(String gameMoney) {
        this.gameMoney = gameMoney;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }
}
