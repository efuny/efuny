package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: PayModel
 * @author: Samson.Sun
 * @date: 2018-1-9 9:06
 * @email: s_xin@neusoft.com
 */
public class PayModel {
    public PayModel() {
    }

    private String orderNumber;
    private String orderTitle;
    private String orderPrice;

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getOrderTitle() {
        return orderTitle;
    }

    public void setOrderTitle(String orderTitle) {
        this.orderTitle = orderTitle;
    }

    public String getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(String orderPrice) {
        this.orderPrice = orderPrice;
    }
}
