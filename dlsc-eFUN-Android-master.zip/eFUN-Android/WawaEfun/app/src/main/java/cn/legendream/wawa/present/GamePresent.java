package cn.legendream.wawa.present;

import android.util.Log;

import org.reactivestreams.Subscription;

import java.util.List;
import java.util.concurrent.TimeUnit;

import cn.droidlover.xdroidmvp.log.XLog;
import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.CatchMemberModel;
import cn.legendream.wawa.model.GameBeginModel;
import cn.legendream.wawa.model.MachineInfoModel;
import cn.legendream.wawa.model.MachineInfoParam;
import cn.legendream.wawa.model.MachineStatusModel;
import cn.legendream.wawa.model.OnLineModel;
import cn.legendream.wawa.model.OrderParam;
import cn.legendream.wawa.model.OrderStatusModel;
import cn.legendream.wawa.model.StringModel;
import cn.legendream.wawa.model.UserOrderParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.GameActivity;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.schedulers.Schedulers;

/**
 * @version V1.0 <>
 * @FileName: GamePresent
 * @author: Samson.Sun
 * @date: 2017-12-8 17:50
 * @email: s_xin@neusoft.com
 */
public class GamePresent extends XPresent<GameActivity> {
    private CompositeDisposable machineStatusDisposable;
    private CompositeDisposable goDisposable;
    private CompositeDisposable gameDisposable;

    public void getMachineInfo(MachineInfoParam machineInfoParam) {
        Api.getSimpleService().getMachineInfo(NetUtil.createRequestBody(machineInfoParam))
                .compose(XApi.<BaseModel<MachineInfoModel>>getApiTransformer())
                .compose(XApi.<BaseModel<MachineInfoModel>>getScheduler())
                .compose(getV().<BaseModel<MachineInfoModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<MachineInfoModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<MachineInfoModel> machineResult) {
                        getV().hideProgress();
                        getV().showData(machineResult);
                    }
                });
    }

    public void gameOnlineList(MachineInfoParam machineInfoParam) {
        Api.getSimpleService().gameOnlineList(NetUtil.createRequestBody(machineInfoParam))
                .compose(XApi.<BaseModel<OnLineModel>>getApiTransformer())
                .compose(XApi.<BaseModel<OnLineModel>>getScheduler())
                .compose(getV().<BaseModel<OnLineModel>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<OnLineModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<OnLineModel> machineResult) {
                        getV().onlineNum(machineResult);
                    }
                });
    }

    public void getMachineOrderList(MachineInfoParam machineInfoParam) {
        Api.getSimpleService().getMachineOrderList(NetUtil.createRequestBody(machineInfoParam))
                .compose(XApi.<BaseModel<List<CatchMemberModel>>>getApiTransformer())
                .compose(XApi.<BaseModel<List<CatchMemberModel>>>getScheduler())
                .compose(getV().<BaseModel<List<CatchMemberModel>>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<List<CatchMemberModel>>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<List<CatchMemberModel>> machineResult) {
                        getV().showCatchList(machineResult);
                    }
                });
    }

    /**
     * 上机操作
     *
     * @param machineInfoParam
     */
    public void machineLogin(MachineInfoParam machineInfoParam) {
        Api.getSimpleService().machineLogin(NetUtil.createRequestBody(machineInfoParam))
                .compose(XApi.<BaseModel>getApiTransformer())
                .compose(XApi.<BaseModel>getScheduler())
                .compose(getV().<BaseModel>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel machineResult) {
                    }
                });
    }

    /**
     * 下机操作
     *
     * @param machineInfoParam
     */
    public void machineLogout(MachineInfoParam machineInfoParam) {
        Api.getSimpleService().machineLogout(NetUtil.createRequestBody(machineInfoParam))
                .compose(XApi.<BaseModel>getApiTransformer())
                .compose(XApi.<BaseModel>getScheduler())
                .compose(getV().<BaseModel>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel machineResult) {
                    }
                });
    }

    public void doGet1Second() {
        machineStatusDisposable = new CompositeDisposable();
        machineStatusDisposable.add(
                Observable
                        .interval(Keys.INTERVAL_GET_STATUS, TimeUnit.SECONDS)
                        .subscribeWith(new DisposableObserver<Long>() {

                            @Override
                            public void onNext(Long value) {
                                getV().doGetMachineStatus();
                            }

                            @Override
                            public void onError(Throwable e) {

                            }

                            @Override
                            public void onComplete() {
                            }
                        }));
    }

    /**
     * 倒计时321go
     */
    public void doGetGo() {
        goDisposable = new CompositeDisposable();
        goDisposable.add(
                Observable
                        .interval(Keys.INTERVAL_GET_GO, TimeUnit.MILLISECONDS)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribeWith(new DisposableObserver<Long>() {

                            @Override
                            public void onNext(Long value) {
                                try {
                                    getV().start321(value);
                                } catch (IllegalStateException l) {

                                }
                            }

                            @Override
                            public void onError(Throwable e) {

                            }

                            @Override
                            public void onComplete() {
                            }
                        }));
    }

    public void disposeGoDisposable() {
        if (goDisposable != null) {
            goDisposable.dispose();
            goDisposable = null;
        }
    }

    /**
     * 倒计时-游戏时间
     *
     * @param count
     */
    public void doStartGameTime(final long count) {
        gameDisposable = new CompositeDisposable();
        gameDisposable.add(
                Observable
                        .interval(Keys.INTERVAL_GET_GAME, TimeUnit.SECONDS)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribeWith(new DisposableObserver<Long>() {

                            @Override
                            public void onNext(Long value) {
                                try {
                                    if (value < count) {
                                        getV().startGameTime(count - value - 1);
                                    } else {
                                        getV().grab();
                                    }
                                } catch (IllegalStateException l) {

                                }
                            }

                            @Override
                            public void onError(Throwable e) {

                            }

                            @Override
                            public void onComplete() {
                            }
                        }));
    }

    public void disGameTime() {
        if (gameDisposable != null) {
            gameDisposable.dispose();
            gameDisposable = null;
        }
    }

    public void delayPlaySound() {
        Observable
                .timer(3000, TimeUnit.MILLISECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<Long>() {

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onComplete() {
                        try {
                            getV().playSoundBg();
                        } catch (IllegalStateException l) {

                        }
                    }

                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(Long value) {
                    }
                });
    }

    public void delayGetOrderStatus(long delayTime) {
        Observable
                .timer(delayTime, TimeUnit.MILLISECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<Long>() {

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onComplete() {
                        try {
                            getV().doGetOrderStatus();
                        } catch (IllegalStateException l) {

                        }
                    }

                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(Long value) {
                    }
                });
    }

    public void getMachineStatus(MachineInfoParam machineInfoParam) {
        Api.getSimpleService().getMachineStatus(NetUtil.createRequestBody(machineInfoParam))
                .compose(XApi.<BaseModel<MachineStatusModel>>getApiTransformer())
                .compose(XApi.<BaseModel<MachineStatusModel>>getScheduler())
                .compose(getV().<BaseModel<MachineStatusModel>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<MachineStatusModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<MachineStatusModel> machineResult) {
                        try {
                            getV().updateMachineStatus(machineResult);
                        } catch (Exception e) {
                        }
                    }
                });
    }

    public void userGameStart(MachineInfoParam machineInfoParam) {
        Api.getSimpleService().userGameStart(NetUtil.createRequestBody(machineInfoParam))
                .compose(XApi.<BaseModel<GameBeginModel>>getApiTransformer())
                .compose(XApi.<BaseModel<GameBeginModel>>getScheduler())
                .compose(getV().<BaseModel<GameBeginModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<GameBeginModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<GameBeginModel> result) {
                        getV().hideProgress();
                        getV().startLoadingGame(result);
                    }
                });
    }

    public void getOrderStatus(UserOrderParam userOrderParam) {
        Api.getSimpleService().getOrderStatus(NetUtil.createRequestBody(userOrderParam))
                .compose(XApi.<BaseModel<OrderStatusModel>>getApiTransformer())
                .compose(XApi.<BaseModel<OrderStatusModel>>getScheduler())
                .compose(getV().<BaseModel<OrderStatusModel>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<OrderStatusModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<OrderStatusModel> result) {
                        getV().hideProgress();
                        getV().doGetCatchResult(result);
                    }
                });
    }

    public void doUp(String url) {
        Api.getControlService().doUp(url)
                .compose(XApi.<StringModel>getApiTransformer())
                .compose(XApi.<StringModel>getScheduler())
                .compose(getV().<StringModel>bindToLifecycle())
                .subscribe(new ApiSubscriber<StringModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(StringModel result) {
                        XLog.d("TAG===", "++++++++");
                        getV().doControlResult(result);
                    }
                });
    }

    public void doDown(String url) {
        Api.getControlService().doDown(url)
                .compose(XApi.<StringModel>getApiTransformer())
                .compose(XApi.<StringModel>getScheduler())
                .compose(getV().<StringModel>bindToLifecycle())
                .subscribe(new ApiSubscriber<StringModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(StringModel result) {
                        XLog.d("TAG===", "--------------------" + System.currentTimeMillis());
                        getV().doControlResult(result);
                    }
                });
    }

    public void doLeft(String url) {
        Api.getControlService().doLeft(url)
                .compose(XApi.<StringModel>getApiTransformer())
                .compose(XApi.<StringModel>getScheduler())
                .compose(getV().<StringModel>bindToLifecycle())
                .subscribe(new ApiSubscriber<StringModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(StringModel result) {
                        XLog.d("TAG===", "--------------------" + System.currentTimeMillis());
                        getV().doControlResult(result);
                    }
                });
    }

    public void doRight(String url) {
        Api.getControlService().doRight(url)
                .compose(XApi.<StringModel>getApiTransformer())
                .compose(XApi.<StringModel>getScheduler())
                .compose(getV().<StringModel>bindToLifecycle())
                .subscribe(new ApiSubscriber<StringModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(StringModel result) {
                        XLog.d("TAG===", "--------------------" + System.currentTimeMillis());
                        getV().doControlResult(result);
                    }
                });
    }

    public void doGrab(String url) {
        Api.getControlService().doGrab(url)
                .compose(XApi.<StringModel>getApiTransformer())
                .compose(XApi.<StringModel>getScheduler())
                .compose(getV().<StringModel>bindToLifecycle())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new ApiSubscriber<StringModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(StringModel result) {
                        getV().hideProgress();
                        getV().doGrabResult(result);
                    }
                });
    }

    public void unSubscribedSchedulers() {
        if (machineStatusDisposable != null) {
            machineStatusDisposable.dispose();
            machineStatusDisposable = null;
        }
        if (gameDisposable != null) {
            gameDisposable.dispose();
            gameDisposable = null;
        }
        if (goDisposable != null) {
            goDisposable.dispose();
            goDisposable = null;
        }
    }
}
