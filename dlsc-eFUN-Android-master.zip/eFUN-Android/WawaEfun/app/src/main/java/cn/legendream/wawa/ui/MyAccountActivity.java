package cn.legendream.wawa.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.alipay.sdk.app.PayTask;
import com.tencent.mm.opensdk.modelpay.PayReq;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.BuildConfig;
import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.event.BusProvider;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.router.Router;
import cn.droidlover.xdroidmvp.view.refreshlayout.SmartRefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.MaterialHeader;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.RefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.listener.OnRefreshListener;
import cn.droidlover.xrecyclerview.RecyclerItemCallback;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.adapter.RechargeAdapter;
import cn.legendream.wawa.alipay.PayResult;
import cn.legendream.wawa.event.PayEvent;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.Account;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.PayCreateOrderModel;
import cn.legendream.wawa.model.PayCreateOrderParam;
import cn.legendream.wawa.model.PayModel;
import cn.legendream.wawa.model.PayParam;
import cn.legendream.wawa.model.RechargeListModel;
import cn.legendream.wawa.model.RechargeModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.model.WxPayOrderModel;
import cn.legendream.wawa.model.WxPayOrderParam;
import cn.legendream.wawa.present.MyAccountPresent;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: MyAccountActivity
 * @author: Samson.Sun
 * @date: 2017-12-14 17:10
 * @email: s_xin@neusoft.com
 */
public class MyAccountActivity extends XActivity<MyAccountPresent> implements AppBarLayout.OnOffsetChangedListener {
    @BindView(R.id.app_bar)
    AppBarLayout app_bar;
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.toolbar_layout)
    CollapsingToolbarLayout toolbar_layout;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    @BindView(R.id.tv_score)
    TextView tv_score;
    @BindView(R.id.toolbar_title)
    TextView toolbar_title;
    @BindView(R.id.contentLayout)
    XRecyclerView contentLayout;
    @BindView(R.id.layout_content)
    View layout_content;
    private int maxMarginTop = 0;
    private int maxMarginLeft = 0;
    private int maxMarginRight = 0;
    private int EXPEND_MARGIN_TOP = 0;//展开后margin
    private RechargeAdapter adapter;
    private List<RechargeListModel> rechargeListModelList;
    private RechargeListModel rechargeListModel;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        setSupportActionBar(toolbar);
        Utils.awakeApp(context);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(false);
        }
        Utils.awakeApp(context);
        EXPEND_MARGIN_TOP = Kits.Dimens.dpToPxInt(context, 10);
        ViewGroup.MarginLayoutParams marginParams = getMarginLayoutParams(refreshLayout);
        maxMarginTop = marginParams.topMargin;
        maxMarginLeft = marginParams.leftMargin;
        maxMarginRight = marginParams.rightMargin;
        app_bar.addOnOffsetChangedListener(this);
        initAdapter();
        final UserParam userParam = new UserParam();
        userParam.setUserId(AppContext.getAccount().getUserId());
        getP().getRechargeList(userParam);
        refreshLayout.setRefreshHeader(new MaterialHeader(context).setShowBezierWave(false));
        refreshLayout.autoRefresh();
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(RefreshLayout refreshlayout) {
                getP().getRechargeList(userParam);
            }
        });

        adapter.setRecItemClick(new RecyclerItemCallback<RechargeListModel, RechargeAdapter.ViewHolder>() {
            @Override
            public void onItemClick(int position, RechargeListModel model, int tag, RechargeAdapter.ViewHolder holder) {
                for (int i = 0; i < rechargeListModelList.size(); i++) {
                    if (rechargeListModelList.get(i).isSelect()) {
                        rechargeListModelList.get(i).setSelect(false);
                        adapter.updateElement(rechargeListModelList.get(i), i);
                    }
                }
                model.setSelect(true);
                adapter.updateElement(model, position);
                rechargeListModel = model;
            }
        });

        TypedValue tv = new TypedValue();
        int actionBarHeight = 0;
        if (getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {
            actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, getResources().getDisplayMetrics());
        }
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        int fullHeight = wm.getDefaultDisplay().getHeight() - actionBarHeight - Kits.Dimens.dpToPxInt(context, 100);
        int fullWidth = wm.getDefaultDisplay().getWidth() - Kits.Dimens.dpToPxInt(context, 40);
        ViewGroup.LayoutParams layoutParams = layout_content.getLayoutParams();
        layoutParams.width = fullWidth;
        layoutParams.height = fullHeight;
        layout_content.setLayoutParams(layoutParams);
        tv_score.setTypeface(Utils.getCondensedBold(context));
        BusProvider.getBus().toFlowable(PayEvent.class)
                .subscribe(new Consumer<PayEvent>() {
                    @Override
                    public void accept(PayEvent payEvent) throws Exception {
                        getP().getRechargeList(new UserParam(AppContext.getAccount().getUserId()));
                    }
                });
    }

    private void initAdapter() {
        rechargeListModelList = new ArrayList<>();
        adapter = new RechargeAdapter(context);
        contentLayout.setItemAnimator(new DefaultItemAnimator());
        contentLayout.gridLayoutManager(context, 2);
        contentLayout.setAdapter(adapter);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_my_account;
    }

    @Override
    public MyAccountPresent newP() {
        return new MyAccountPresent();
    }

    @OnClick(R.id.layout_alipay)
    void payByAlipay() {
        createOrder(true);
    }

    @OnClick(R.id.layout_wechat)
    void payByWechat() {
        createOrder(false);
    }

    private void createOrder(boolean isAli) {
        if (rechargeListModel == null || Kits.Empty.check(rechargeListModel.getPackageId())) {
            return;
        }
        PayParam payParam = new PayParam();
        payParam.setUserId(AppContext.getAccount().getUserId());
        payParam.setPackageId(rechargeListModel.getPackageId());
        payParam.setPayType(isAli ? "2" : "1");
        getP().userCreateRechargeOrder(payParam, isAli);
    }

    private void payWechat(final WxPayOrderModel wxPayOrderModel) {
        final IWXAPI api = WXAPIFactory.createWXAPI(this, BuildConfig.wechatKey);
        try {
            PayReq req = new PayReq();
            req.appId = BuildConfig.wechatKey;
            req.partnerId = wxPayOrderModel.getPartnerid();
            req.prepayId = wxPayOrderModel.getPrepayid();
            req.nonceStr = wxPayOrderModel.getNoncestr();
            req.timeStamp = wxPayOrderModel.getTimestamp();
            req.packageValue = wxPayOrderModel.getPackageValue();
            req.sign = wxPayOrderModel.getSign();
            req.extData = "app data";
            // 在支付之前，如果应用没有注册到微信，应该先调用IWXMsg.registerApp将应用注册到微信
            api.sendReq(req);
        } catch (Exception e) {
        }
    }

    private void alipay(final String orderInfo) {
        Runnable payRunnable = new Runnable() {

            @Override
            public void run() {
                PayTask alipay = new PayTask(context);
                Map<String, String> result = alipay.payV2(orderInfo, true);

                Message msg = new Message();
                msg.obj = result;
                mHandler.sendMessage(msg);
            }
        };

        Thread payThread = new Thread(payRunnable);
        payThread.start();
    }

    public void alipayOrder(BaseModel<PayCreateOrderModel> result) {
        alipay(result.getData().getStr());
    }

    public void wechatOrder(BaseModel<WxPayOrderModel> result) {
        payWechat(result.getData());
    }

    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {
        @SuppressWarnings("unused")
        public void handleMessage(Message msg) {
            @SuppressWarnings("unchecked")
            PayResult payResult = new PayResult((Map<String, String>) msg.obj);
            /**
             对于支付结果，请商户依赖服务端的异步通知结果。同步通知结果，仅作为支付结束的通知。
             */
            String resultInfo = payResult.getResult();// 同步返回需要验证的信息
            String resultStatus = payResult.getResultStatus();
            // 判断resultStatus 为9000则代表支付成功
            if (TextUtils.equals(resultStatus, "9000")) {
                // 该笔订单是否真实支付成功，需要依赖服务端的异步通知。
                Toast.makeText(context, "支付成功", Toast.LENGTH_SHORT).show();
                final UserParam userParam = new UserParam();
                userParam.setUserId(AppContext.getAccount().getUserId());
                getP().getRechargeList(userParam);
            } else {
                // 该笔订单真实的支付结果，需要依赖服务端的异步通知。
                Toast.makeText(context, "支付失败", Toast.LENGTH_SHORT).show();
            }
        }
    };

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(MyAccountActivity.class)
                .launch();
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    @Override
    public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
        int maxHeight = toolbar.getHeight() - app_bar.getHeight();
        if (verticalOffset == 0) {
            setMargin(maxMarginTop);
            toolbar_title.setAlpha(0);
        } else if (verticalOffset == maxHeight) {
            setMargin(EXPEND_MARGIN_TOP);
            toolbar_title.setAlpha(1);
        } else {
            setMargin(maxMarginTop * (maxHeight - verticalOffset) / maxHeight + EXPEND_MARGIN_TOP * verticalOffset / maxHeight);
            toolbar_title.setAlpha(0);
        }
    }

    private void setMargin(int px) {
        ViewGroup.MarginLayoutParams marginParams = getMarginLayoutParams(refreshLayout);
        marginParams.setMargins(maxMarginLeft, px, maxMarginRight, 0);
        refreshLayout.setLayoutParams(marginParams);
    }

    public void showError(NetError error) {
        super.showError(error);
        refreshLayout.finishRefresh();
    }

    public void rechargeList(BaseModel<RechargeModel> result) {
        refreshLayout.finishRefresh();
        rechargeListModelList = result.getData().getList();
        if (!Kits.Empty.check(rechargeListModelList)) {
            rechargeListModelList.get(0).setSelect(true);
            rechargeListModel = rechargeListModelList.get(0);
        }
        Account account = AppContext.getAccount();
        account.setGameMoney(result.getData().getUserMoney());
        SharedPref.getInstance(context).put(Keys.ACCOUNT, account);
        AppContext.setAccount(account);
        tv_score.setText(result.getData().getUserMoney());
        adapter.setData(rechargeListModelList);
    }

    public void createOrder(BaseModel<PayModel> result, boolean isAli) {
        if (isAli) {
            PayCreateOrderParam payCreateOrderParam = new PayCreateOrderParam();
            payCreateOrderParam.setOrderNumber(result.getData().getOrderNumber());
            payCreateOrderParam.setDeviceInfo("Android APPV2");
            getP().aliPayCreateOrder(payCreateOrderParam);
        } else {
            WxPayOrderParam wxPayOrderParam = new WxPayOrderParam();
            wxPayOrderParam.setOrderNumber(result.getData().getOrderNumber());
            wxPayOrderParam.setDeviceInfo("Android APPV2");
            getP().wxPayCreateOrder(wxPayOrderParam);
        }
    }
}
