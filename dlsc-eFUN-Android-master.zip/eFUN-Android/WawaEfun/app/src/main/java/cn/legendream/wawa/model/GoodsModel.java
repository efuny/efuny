package cn.legendream.wawa.model;

import java.io.Serializable;

/**
 * @version V1.0 <>
 * @FileName: GoodsModel
 * @author: Samson.Sun
 * @date: 2018-7-9 23:47
 * @email: s_xin@neusoft.com
 */
public class GoodsModel implements Serializable {
    public GoodsModel() {
    }

    private String goodName;
    private String goodImageUrl;
    private String goodId;
    private String goodType;
    private String price;
    private String integral;

    public String getGoodName() {
        return goodName;
    }

    public void setGoodName(String goodName) {
        this.goodName = goodName;
    }

    public String getGoodImageUrl() {
        return goodImageUrl;
    }

    public void setGoodImageUrl(String goodImageUrl) {
        this.goodImageUrl = goodImageUrl;
    }

    public String getGoodId() {
        return goodId;
    }

    public void setGoodId(String goodId) {
        this.goodId = goodId;
    }

    public String getGoodType() {
        return goodType;
    }

    public void setGoodType(String goodType) {
        this.goodType = goodType;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }
}
