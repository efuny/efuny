package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: MachineStatusModel
 * @author: Samson.Sun
 * @date: 2017-12-27 15:35
 * @email: s_xin@neusoft.com
 */
public class MachineStatusModel {
    public MachineStatusModel() {
    }
    private String MachineStatus;

    public String getMachineStatus() {
        return MachineStatus;
    }

    public void setMachineStatus(String machineStatus) {
        MachineStatus = machineStatus;
    }
}
