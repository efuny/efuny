package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: TestLoginParam
 * @author: Samson.Sun
 * @date: 2018-1-23 11:23
 * @email: s_xin@neusoft.com
 */
public class TestLoginParam {
    public TestLoginParam() {
    }

    private String username;
    private String password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
