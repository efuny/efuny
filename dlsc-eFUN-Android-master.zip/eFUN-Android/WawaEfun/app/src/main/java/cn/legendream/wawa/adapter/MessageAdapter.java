package cn.legendream.wawa.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xdroidmvp.kit.KnifeKit;
import cn.legendream.wawa.R;
import cn.legendream.wawa.model.MessageModel;

/**
 * @version V1.0 <>
 * @FileName: MessageAdapter
 * @author: Samson.Sun
 * @date: 2017-12-14 14:26
 * @email: s_xin@neusoft.com
 */
public class MessageAdapter extends SimpleRecAdapter<MessageModel, MessageAdapter.ViewHolder> {
    public MessageAdapter(Context context) {
        super(context);
    }

    @Override
    public ViewHolder newViewHolder(View itemView) {
        return new ViewHolder(itemView);
    }

    @Override
    public int getLayoutId() {
        return R.layout.item_message;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final MessageModel model = data.get(position);
        holder.tv_title.setText(model.getContent());
        holder.tv_content.setText(model.getDateTime());
        if (model.getMessageType().equals("1")) {
            holder.tv_arrow.setVisibility(View.VISIBLE);
        } else {
            holder.tv_arrow.setVisibility(View.INVISIBLE);
        }
        holder.item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getRecItemClick().onItemClick(position, model, 0, holder);
            }
        });
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.item)
        View item;
        @BindView(R.id.tv_title)
        TextView tv_title;
        @BindView(R.id.tv_content)
        TextView tv_content;
        @BindView(R.id.tv_arrow)
        TextView tv_arrow;

        public ViewHolder(View itemView) {
            super(itemView);
            KnifeKit.bind(this, itemView);
        }
    }
}
