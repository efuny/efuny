package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: ExchangeGoodInfoModel
 * @author: Samson.Sun
 * @date: 2018-7-20 1:14
 * @email: s_xin@neusoft.com
 */
public class ExchangeGoodInfoModel {
    public ExchangeGoodInfoModel() {
    }

    private String code;
    private String exchangeImageUrl;
    private String expiryTime;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getExchangeImageUrl() {
        return exchangeImageUrl;
    }

    public void setExchangeImageUrl(String exchangeImageUrl) {
        this.exchangeImageUrl = exchangeImageUrl;
    }

    public String getExpiryTime() {
        return expiryTime;
    }

    public void setExpiryTime(String expiryTime) {
        this.expiryTime = expiryTime;
    }
}
