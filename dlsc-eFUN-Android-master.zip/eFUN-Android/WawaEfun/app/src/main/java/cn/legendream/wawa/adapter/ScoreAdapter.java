package cn.legendream.wawa.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.kit.KnifeKit;
import cn.legendream.wawa.R;
import cn.legendream.wawa.model.Score;

/**
 * @version V1.0 <>
 * @FileName: ScoreAdapter
 * @author: Samson.Sun
 * @date: 2017-12-20 17:23
 * @email: s_xin@neusoft.com
 */
public class ScoreAdapter extends SimpleRecAdapter<Score, ScoreAdapter.ViewHolder> {
    private int type = 1;

    public ScoreAdapter(Context context, int type) {
        super(context);
    }

    @Override
    public ViewHolder newViewHolder(View itemView) {
        return new ViewHolder(itemView);
    }

    @Override
    public int getLayoutId() {
        return R.layout.item_score;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Score score = data.get(position);
        ILFactory.getLoader().loadNet(holder.iv_image, score.getDollImageUrl(), null);
        holder.tv_name.setText(score.getDollName());
        holder.tv_time.setText(score.getDateTime());
        holder.tv_event.setText(score.getPointContent());
        holder.tv_score.setText((type == 1 ? "+" : "-") + score.getPoint());
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.iv_image)
        ImageView iv_image;
        @BindView(R.id.tv_name)
        TextView tv_name;
        @BindView(R.id.tv_time)
        TextView tv_time;
        @BindView(R.id.tv_event)
        TextView tv_event;
        @BindView(R.id.tv_score)
        TextView tv_score;

        public ViewHolder(View itemView) {
            super(itemView);
            KnifeKit.bind(this, itemView);
        }
    }
}
