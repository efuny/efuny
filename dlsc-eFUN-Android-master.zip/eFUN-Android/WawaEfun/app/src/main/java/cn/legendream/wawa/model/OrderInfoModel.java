package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: OrderInfoModel
 * @author: Samson.Sun
 * @date: 2018-7-19 23:51
 * @email: s_xin@neusoft.com
 */
public class OrderInfoModel {
    public OrderInfoModel() {
    }

    private ExpressInfoModel expressInfo;
    private OrderInfoChildModel orderInfo;
    private GoodInfoModel goodInfo;
    private ExchangeGoodInfoModel exchangeGoodInfo;

    public ExpressInfoModel getExpressInfo() {
        return expressInfo;
    }

    public void setExpressInfo(ExpressInfoModel expressInfo) {
        this.expressInfo = expressInfo;
    }

    public OrderInfoChildModel getOrderInfo() {
        return orderInfo;
    }

    public void setOrderInfo(OrderInfoChildModel orderInfo) {
        this.orderInfo = orderInfo;
    }

    public GoodInfoModel getGoodInfo() {
        return goodInfo;
    }

    public void setGoodInfo(GoodInfoModel goodInfo) {
        this.goodInfo = goodInfo;
    }

    public ExchangeGoodInfoModel getExchangeGoodInfo() {
        return exchangeGoodInfo;
    }

    public void setExchangeGoodInfo(ExchangeGoodInfoModel exchangeGoodInfo) {
        this.exchangeGoodInfo = exchangeGoodInfo;
    }
}
