package cn.legendream.wawa.ui.gamev2;

import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.tencent.rtmp.ITXLivePlayListener;
import com.tencent.rtmp.TXLiveConstants;
import com.tencent.rtmp.TXLivePlayConfig;
import com.tencent.rtmp.TXLivePlayer;
import com.tencent.rtmp.ui.TXCloudVideoView;

import java.lang.ref.WeakReference;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.kit.IMAudioManager;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.log.XLog;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.adapter.GameCatchAdapter;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.CatchMemberModel;
import cn.legendream.wawa.model.GameBeginModel;
import cn.legendream.wawa.model.MachineInfoModel;
import cn.legendream.wawa.model.MachineInfoParam;
import cn.legendream.wawa.model.MachineStatusModel;
import cn.legendream.wawa.model.OnLineModel;
import cn.legendream.wawa.model.OrderStatusModel;
import cn.legendream.wawa.model.PostGameResultParam;
import cn.legendream.wawa.model.StringModel;
import cn.legendream.wawa.model.UserOrderParam;
import cn.legendream.wawa.ui.GameActivity;
import cn.legendream.wawa.ui.MyAccountActivity;
import cn.legendream.wawa.ui.WebActivity;
import cn.legendream.wawa.ui.gamev2.socks.SockAPP;
import cn.legendream.wawa.view.CatchStateDialog;
import cn.legendream.wawa.view.FullyLinearLayoutManager;
import de.hdodenhof.circleimageview.CircleImageView;
import me.drakeet.materialdialog.MaterialDialog;

public class GameV2Activity extends XActivity<GameV2Present> implements ITXLivePlayListener {

    //    private final String CONTROL_HOST = "http://control.efuny.net"; //"39.105.104.139"
    private final String CONTROL_HOST = "47.92.52.6";

    @BindView(R.id.layout_full_screen)
    View layout_full_screen;
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.video_container)
    View video_container;
    @BindView(R.id.iv_photo)
    ImageView iv_photo;
    @BindView(R.id.layout_button)
    View layout_button;
    @BindView(R.id.layout_holding)
    View layout_holding;
    @BindView(R.id.tv_money)
    TextView tv_money;
    @BindView(R.id.tv_catch_title)
    TextView tv_catch_title;
    @BindView(R.id.tv_intro)
    TextView tv_intro;
    @BindView(R.id.layout_start_game)
    View layout_start_game;
    @BindView(R.id.tv_start_game)
    TextView tv_start_game;
    @BindView(R.id.tv_money_num)
    TextView tv_money_num;
    @BindView(R.id.cvv_negative)
    TXCloudVideoView cvv_negative;
    @BindView(R.id.cvv_front)
    TXCloudVideoView cvv_front;
    @BindView(R.id.layout_video)
    View layout_video;
    @BindView(R.id.ic_head1)
    CircleImageView ic_head1;
    @BindView(R.id.ic_head2)
    CircleImageView ic_head2;
    @BindView(R.id.ic_head3)
    CircleImageView ic_head3;
    @BindView(R.id.tv_people_num)
    TextView tv_people_num;
    @BindView(R.id.rv_list)
    XRecyclerView rv_list;
    @BindView(R.id.iv_detail_image)
    ImageView iv_detail_image;
    @BindView(R.id.tv_name)
    TextView tv_name;
    @BindView(R.id.tv_height)
    TextView tv_height;
    @BindView(R.id.tv_time)
    TextView tv_time;
    @BindView(R.id.layout_time)
    View layout_time;
    @BindView(R.id.iv_num)
    ImageView iv_num;
    @BindView(R.id.iv_grab)
    ImageView iv_grab;
    @BindView(R.id.iv_up)
    ImageView ivUp;
    @BindView(R.id.iv_left)
    ImageView ivLeft;
    @BindView(R.id.iv_down)
    ImageView ivDown;
    @BindView(R.id.iv_right)
    ImageView ivRight;

    private TXLivePlayer mLivePlayerFront = null;
    private TXLivePlayer mLivePlayerNegative = null;
    public static final String PARAM_MACHINE_ID = "machine_id";
    public static final String PARAM_FACE_CAMERA = "face_camera";
    public static final String PARAM_SIDE_CAMERA = "side_camera";
    private String machineId;
    private MachineInfoModel machineInfoModel;
    private MachineInfoParam machineInfoParam;
    private GameCatchAdapter adapter;

    private static final double LIVE_SIZE = 1.34;
    private static final int STATUS_BAR_HEIGHT = 25;
    private boolean isMachineRight = false;
    private boolean mVideoPlay = false;
    private boolean mVideoPause = false;
    private boolean mHWDecode = true;
    private int mPlayType = TXLivePlayer.PLAY_TYPE_LIVE_RTMP;
    private int mCurrentRenderMode;
    private int mCurrentRenderRotation;
    private PhoneStateListener mPhoneListener = null;
    private TXLivePlayConfig mPlayConfig;
    private String faceCamera = "";
    private String sideCamera = "";
    private boolean isFront = false;
    private static final int CACHE_STRATEGY_FAST = 1;  //极速
    private static final int CACHE_STRATEGY_SMOOTH = 2;  //流畅
    private static final int CACHE_STRATEGY_AUTO = 3;  //自动
    private static final float CACHE_TIME_FAST = 1.0f;
    private static final float CACHE_TIME_SMOOTH = 5.0f;
    private GameActivity.MachineStates machineStates = GameActivity.MachineStates.FREE;
    private String helpUrl = "";
    private String gameTime;//游戏倒计时时间
    private String toContineTime;//等待时间，是否继续游戏
    private String orderMsec;//游戏结束调取娃娃是否抓中
    private String orderId;
    private String orderMachineId;

    private String audioUrl1 = "play_wawa.mp3";
    private String audioUrl2 = "sort_get_wawa.mp3";
    private String audioUrl3 = "go.wav";
    private String audioUrl4 = "321.wav";
    private String audioUrl5 = "get_wawa.wav";
    private String audioUrl6 = "not_get_wawa.wav";

    private BaseModel<GameBeginModel> startGameResult;

    private boolean isPlayBg = true;
    private boolean isPlaySound = true;

    private long startTime = 0L;
    private AudioManager audio;

    private SockAPP sendThread;

    private boolean b_start_new_game = false;

//    private boolean isGameStarted = false;

    public enum MachineStates {
        FREE, BUSY, PLAYING, OVER;
    }

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar).init();
    }

    public static void launch(Activity activity, String machineId) {
        Router.newIntent(activity)
                .to(GameV2Activity.class)
                .putString(PARAM_MACHINE_ID, machineId)
                .launch();
    }

    @Override
    public void initData(Bundle savedInstanceState) {

        Utils.awakeApp(context);
        machineId = getIntent().getStringExtra(PARAM_MACHINE_ID);
        isPlayBg = SharedPref.getInstance(context).getBoolean(Keys.IS_BACKGROUND_MUSIC, true);
        isPlaySound = SharedPref.getInstance(context).getBoolean(Keys.IS_SOUND, true);
//        faceCamera = "rtmp://16165.liveplay.myqcloud.com/live/16165_ipc01";
//        sideCamera = "rtmp://16165.liveplay.myqcloud.com/live/16165_ipc01";
        machineInfoParam = new MachineInfoParam();
        machineInfoParam.setMachineId(machineId);
        machineInfoParam.setUserId(AppContext.getAccount().getUserId());
        /*___________________________________设置屏幕高度_________________________________*/
        TypedValue tv = new TypedValue();
        int actionBarHeight = 0;
        if (getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {
            actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, getResources().getDisplayMetrics());
        }
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        int fullWidth = wm.getDefaultDisplay().getWidth();
        int fullHeight = wm.getDefaultDisplay().getHeight();
        //不含toolbar高度
        fullHeight = fullHeight - actionBarHeight - Kits.Dimens.dpToPxInt(context, STATUS_BAR_HEIGHT);
        FrameLayout.LayoutParams fullLayoutParams = (FrameLayout.LayoutParams) layout_full_screen.getLayoutParams();
        fullLayoutParams.width = fullWidth;
        fullLayoutParams.height = fullHeight;
        layout_full_screen.setLayoutParams(fullLayoutParams);

        /*___________________________________设置live屏幕高度_________________________________*/
        int width = fullWidth;
        int height = (int) (width * LIVE_SIZE);
        int bottomHeight = fullHeight - height;
        if (height > fullHeight - Kits.Dimens.dpToPxInt(context, 100)) {
            height = fullHeight - Kits.Dimens.dpToPxInt(context, 100);
            width = (int) (height / LIVE_SIZE);
            bottomHeight = Kits.Dimens.dpToPxInt(context, 100);
        }
        RelativeLayout.LayoutParams liveParam = (RelativeLayout.LayoutParams) video_container.getLayoutParams();
        liveParam.width = width;
        liveParam.height = height;
        video_container.setLayoutParams(liveParam);
        RelativeLayout.LayoutParams videoParam = (RelativeLayout.LayoutParams) layout_video.getLayoutParams();
        videoParam.width = width;
        videoParam.height = height;
        layout_video.setLayoutParams(videoParam);
        /*___________________________________设置控制/开始游戏高度_________________________________*/
        RelativeLayout.LayoutParams buttonParam = (RelativeLayout.LayoutParams) layout_button.getLayoutParams();
        buttonParam.width = fullWidth;
        buttonParam.height = bottomHeight + Kits.Dimens.dpToPxInt(context, 10);
        layout_button.setLayoutParams(buttonParam);
        layout_holding.setLayoutParams(buttonParam);
        /*___________________________________初始状态_________________________________*/
        setCantPlay();
        getP().getMachineInfo(machineInfoParam);
        refreshData();

        /*___________________________________列表初始化_________________________________*/
        tv_start_game.setTypeface(Utils.getGoTrialFont(context));
        tv_money.setTypeface(Utils.getCondensedBold(context));
        tv_catch_title.setTypeface(Utils.getGoTrialFont(context));
        tv_intro.setTypeface(Utils.getGoTrialFont(context));
        tv_people_num.setTypeface(Utils.getCondensedBold(context));
        tv_time.setTypeface(Utils.getCondensedBold(context));
        adapter = new GameCatchAdapter(context);
        rv_list.setAdapter(adapter);
        FullyLinearLayoutManager fullyLinearLayoutManager = new FullyLinearLayoutManager(context);
        rv_list.setLayoutManager(fullyLinearLayoutManager);
        getP().getMachineOrderList(machineInfoParam);
        if (isPlayBg || isPlaySound) {
            IMAudioManager.instance().init(this);
        }
        if (isPlayBg) {
            playSoundBg();
        }

    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_game_v2;
    }

    private void initLive() {
        mCurrentRenderMode = TXLiveConstants.RENDER_MODE_FULL_FILL_SCREEN;
        mCurrentRenderRotation = TXLiveConstants.RENDER_ROTATION_PORTRAIT;
        mPlayConfig = new TXLivePlayConfig();
        if (mLivePlayerFront == null) {
            mLivePlayerFront = new TXLivePlayer(this);
        }
        if (mLivePlayerNegative == null) {
            mLivePlayerNegative = new TXLivePlayer(this);
        }

        mPhoneListener = new TXPhoneStateListener(mLivePlayerFront, mLivePlayerNegative);
        TelephonyManager tm = (TelephonyManager) getApplicationContext().getSystemService(Service.TELEPHONY_SERVICE);
        tm.listen(mPhoneListener, PhoneStateListener.LISTEN_CALL_STATE);

        cvv_front.disableLog(true);
        cvv_negative.disableLog(true);
        //开始播放
        startLivePlayer();
    }

    private void startLivePlayer() {
        if (mVideoPlay) {
            if (mPlayType == TXLivePlayer.PLAY_TYPE_VOD_FLV || mPlayType == TXLivePlayer.PLAY_TYPE_VOD_HLS || mPlayType == TXLivePlayer.PLAY_TYPE_VOD_MP4 || mPlayType == TXLivePlayer.PLAY_TYPE_LOCAL_VIDEO) {
                if (!mLivePlayerFront.isPlaying()) {
                    mLivePlayerFront.resume();
                } else {
                    mLivePlayerFront.pause();
                }
                if (!mLivePlayerNegative.isPlaying()) {
                    mLivePlayerNegative.resume();
                } else {
                    mLivePlayerNegative.pause();
                }
                mVideoPause = !mVideoPause;
            } else {
                stopPlayRtmp();
            }
        } else {
            mVideoPlay = startPlayRtmp(faceCamera, sideCamera);
        }
    }

    private boolean startPlayRtmp(String playUrl1, String playUrl2) {
        if (!checkPlayUrl(playUrl1) || !checkPlayUrl(playUrl2)) {
            return false;
        }
        mLivePlayerNegative.setPlayerView(cvv_negative);
        mLivePlayerFront.setPlayerView(cvv_front);
        mLivePlayerFront.setPlayListener(this);
        mLivePlayerNegative.setPlayListener(this);
//        mLivePlayer.setRate(1.5f);
        // 硬件加速在1080p解码场景下效果显著，但细节之处并不如想象的那么美好：
        // (1) 只有 4.3 以上android系统才支持
        // (2) 兼容性我们目前还仅过了小米华为等常见机型，故这里的返回值您先不要太当真
        mLivePlayerFront.enableHardwareDecode(mHWDecode);
        mLivePlayerNegative.enableHardwareDecode(mHWDecode);
        mLivePlayerFront.setRenderRotation(mCurrentRenderRotation);
        mLivePlayerNegative.setRenderRotation(mCurrentRenderRotation);
        mLivePlayerFront.setRenderMode(mCurrentRenderMode);
//        mLivePlayerFront.setRenderRotation(TXLiveConstants.);
        mLivePlayerNegative.setRenderMode(mCurrentRenderMode);
        //设置播放器缓存策略
        //这里将播放器的策略设置为自动调整，调整的范围设定为1到4s，您也可以通过setCacheTime将播放器策略设置为采用
        //固定缓存时间。如果您什么都不调用，播放器将采用默认的策略（默认策略为自动调整，调整范围为1到4s）
        //mLivePlayer.setCacheTime(5);
        mPlayConfig.setCacheFolderPath(null);

        mPlayConfig.setAutoAdjustCacheTime(true);
        mPlayConfig.setMaxAutoAdjustCacheTime(CACHE_TIME_FAST);
        mPlayConfig.setMinAutoAdjustCacheTime(CACHE_TIME_FAST);
        mLivePlayerFront.setConfig(mPlayConfig);
        mLivePlayerNegative.setConfig(mPlayConfig);
        mLivePlayerFront.setAutoPlay(true);
        mLivePlayerNegative.setAutoPlay(true);

        int result2 = mLivePlayerNegative.startPlay(playUrl2, mPlayType); // result返回值：0 success;  -1 empty url; -2 invalid url; -3 invalid playType;
        int result1 = mLivePlayerFront.startPlay(playUrl1, mPlayType); // result返回值：0 success;  -1 empty url; -2 invalid url; -3 invalid playType;

        showProgress();
        return true;
    }

    private void stopPlayRtmp() {
        hideProgress();
        if (mLivePlayerFront != null) {
            mLivePlayerFront.stopRecord();
            mLivePlayerFront.setPlayListener(null);
            mLivePlayerFront.stopPlay(true);
        }
        if (mLivePlayerNegative != null) {
            mLivePlayerNegative.stopRecord();
            mLivePlayerNegative.setPlayListener(null);
            mLivePlayerNegative.stopPlay(true);
        }
        mVideoPause = false;
        mVideoPlay = false;
    }

    private boolean checkPlayUrl(final String playUrl) {
//        由于iOS AppStore要求新上架的app必须使用https,所以后续腾讯云的视频连接会支持https,但https会有一定的性能损耗,所以android将统一替换会http
        if (TextUtils.isEmpty(playUrl) || (!playUrl.startsWith("http://") && !playUrl.startsWith("https://") && !playUrl.startsWith("rtmp://") && !playUrl.startsWith("/"))) {
            Toast.makeText(getApplicationContext(), "播放地址不合法o(╥﹏╥)o", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    @Override
    public GameV2Present newP() {
        return new GameV2Present();
    }

    private void refreshData() {
        getP().gameOnlineList(machineInfoParam);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ButtonListener buttonListener = new ButtonListener();
        ivUp.setOnTouchListener(buttonListener);
        ivDown.setOnTouchListener(buttonListener);
        ivLeft.setOnTouchListener(buttonListener);
        ivRight.setOnTouchListener(buttonListener);
        iv_grab.setOnTouchListener(buttonListener);
//        layout_start_game.setOnTouchListener(buttonListener);

    }

    @Override
    protected void onResume() {

        IMAudioManager.instance().resume();
        if (mVideoPlay && !mVideoPause) {
            if (mPlayType == TXLivePlayer.PLAY_TYPE_VOD_FLV
                    || mPlayType == TXLivePlayer.PLAY_TYPE_VOD_HLS
                    || mPlayType == TXLivePlayer.PLAY_TYPE_VOD_MP4
                    || mPlayType == TXLivePlayer.PLAY_TYPE_LOCAL_VIDEO) {
                if (mLivePlayerFront != null) {
                    mLivePlayerFront.resume();
                }
                if (mLivePlayerNegative != null) {
                    mLivePlayerNegative.resume();
                }
            } else {
                if (cvv_front != null) {
                    cvv_front.onResume();
                }
                if (cvv_negative != null) {
                    cvv_negative.onResume();
                }
            }
        }
        getP().machineLogin(machineInfoParam);
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
        IMAudioManager.instance().pause();
        getP().machineLogout(machineInfoParam);
        if (mPlayType == TXLivePlayer.PLAY_TYPE_VOD_FLV || mPlayType == TXLivePlayer.PLAY_TYPE_VOD_HLS || mPlayType == TXLivePlayer.PLAY_TYPE_VOD_MP4 || mPlayType == TXLivePlayer.PLAY_TYPE_LOCAL_VIDEO) {
            if (mLivePlayerFront != null) {
                mLivePlayerFront.pause();
            }
            if (mLivePlayerNegative != null) {
                mLivePlayerNegative.pause();
            }
        } else {
            if (cvv_front != null) {
                cvv_front.onPause();
            }
            if (cvv_negative != null) {
                cvv_negative.onPause();
            }
        }
    }

    @Override
    protected void onDestroy() {

        if (sendThread != null) {
            sendThread.SendOutCommand(new CommandEntity(CommandConstants.DO_EXIT));
        }

//        if (sendThread != null) {
//            sendThread.StopNow();
//            sendThread = null;
//        }

        super.onDestroy();

        if (mLivePlayerFront != null) {
            mLivePlayerFront.stopPlay(true);
            mLivePlayerFront = null;
        }
        if (mLivePlayerNegative != null) {
            mLivePlayerNegative.stopPlay(true);
            mLivePlayerNegative = null;
        }
        if (cvv_front != null) {
            cvv_front.onDestroy();
            cvv_front = null;
        }
        if (cvv_negative != null) {
            cvv_negative.onDestroy();
            cvv_negative = null;
        }
        mPlayConfig = null;
        IMAudioManager.instance().clear();
        TelephonyManager tm = (TelephonyManager) getApplicationContext().getSystemService(Service.TELEPHONY_SERVICE);
        tm.listen(mPhoneListener, PhoneStateListener.LISTEN_NONE);
        getP().unSubscribedSchedulers();
    }


    public void showData(BaseModel<MachineInfoModel> machineResult) {

        machineInfoModel = machineResult.getData();
        if (isFront) {
            faceCamera = machineInfoModel.getFaceCamera();
            sideCamera = machineInfoModel.getSideCamera();
        } else {
            faceCamera = machineInfoModel.getSideCamera();
            sideCamera = machineInfoModel.getFaceCamera();
        }

//        faceCamera = "rtmp://16165.liveplay.myqcloud.com/live/16165_ipc03";
//        faceCamera = "rtmp://16181.liveplay.myqcloud.com/live/16181_ipc09";

        orderMachineId = machineInfoModel.getMachineId();
        tv_money_num.setText(Utils.formatStrings(context, R.string.game_money, machineInfoModel.getMachineGameMoney()));
        tv_money.setText(machineInfoModel.getUserGameMoney());
        helpUrl = machineResult.getData().getHelpUrl();
        ILFactory.getLoader().loadNet(iv_detail_image, machineInfoModel.getDollInfo().getDollImg(), null);
        tv_name.setText(Utils.formatStrings(context, R.string.game_detail_name, machineInfoModel.getDollInfo().getDollName()));
        tv_height.setText(Utils.formatStrings(context, R.string.game_detail_height, machineInfoModel.getDollInfo().getDollHeight()));
        if (machineInfoModel.getMachineStatus().equals("3")) {
            toast(R.string.machine_status_not_1);
        } else {
            isMachineRight = true;
            initLive();
            getP().doGet1Second();
            getP().getMachineStatus(machineInfoParam);
        }
    }

    public void onlineNum(BaseModel<OnLineModel> machineResult) {
        List<OnLineModel.OnLineImageModel> onLineImageModelList = machineResult.getData().getMemberList();
        if (onLineImageModelList.size() == 1) {
            ILFactory.getLoader().loadNet(ic_head1, onLineImageModelList.get(0).getHeadUrl(), null);
        } else if (onLineImageModelList.size() == 2) {
            ILFactory.getLoader().loadNet(ic_head1, onLineImageModelList.get(0).getHeadUrl(), null);
            ILFactory.getLoader().loadNet(ic_head2, onLineImageModelList.get(1).getHeadUrl(), null);
        } else if (onLineImageModelList.size() >= 3) {
            ILFactory.getLoader().loadNet(ic_head1, onLineImageModelList.get(0).getHeadUrl(), null);
            ILFactory.getLoader().loadNet(ic_head2, onLineImageModelList.get(1).getHeadUrl(), null);
            ILFactory.getLoader().loadNet(ic_head3, onLineImageModelList.get(2).getHeadUrl(), null);
        } else {
            ILFactory.getLoader().loadResource(ic_head1, R.drawable.ic_default_head, null);
            ILFactory.getLoader().loadResource(ic_head2, R.drawable.ic_default_head, null);
            ILFactory.getLoader().loadResource(ic_head3, R.drawable.ic_default_head, null);
        }
        tv_people_num.setText(Utils.formatStrings(context, R.string.people_num, machineResult.getData().getMemberCount() + ""));
    }

    public void showCatchList(BaseModel<List<CatchMemberModel>> result) {
        adapter.setData(result.getData());
    }

    private void setCanPlay() {
        machineStates = GameActivity.MachineStates.FREE;
        layout_button.setVisibility(View.VISIBLE);
        layout_holding.setVisibility(View.GONE);
        layout_start_game.setBackgroundResource(R.drawable.bg_corner_play);
        tv_start_game.setAlpha(1f);
        tv_money_num.setAlpha(1f);
    }

    private void setCantPlay() {
        machineStates = GameActivity.MachineStates.BUSY;
        layout_button.setVisibility(View.VISIBLE);
        layout_holding.setVisibility(View.GONE);
        layout_start_game.setBackgroundResource(R.drawable.bg_corner_unplay);
        tv_start_game.setAlpha(0.5f);
        tv_money_num.setAlpha(0.5f);
    }

    private void setPlaying() {
        machineStates = GameActivity.MachineStates.PLAYING;
        layout_button.setVisibility(View.GONE);
        layout_holding.setVisibility(View.VISIBLE);
    }

    @Override
    public void onPlayEvent(int event, Bundle param) {
        if (event == TXLiveConstants.PLAY_EVT_PLAY_BEGIN) {
            hideProgress();
        } else if (event == TXLiveConstants.PLAY_EVT_PLAY_PROGRESS) {
            return;
        } else if (event == TXLiveConstants.PLAY_ERR_NET_DISCONNECT || event == TXLiveConstants.PLAY_EVT_PLAY_END) {
            stopPlayRtmp();
            mVideoPlay = false;
            mVideoPause = false;
        } else if (event == TXLiveConstants.PLAY_EVT_PLAY_LOADING) {
            showProgress();
        } else if (event == TXLiveConstants.PLAY_EVT_RCV_FIRST_I_FRAME) {
            hideProgress();
        } else if (event == TXLiveConstants.PLAY_EVT_CHANGE_RESOLUTION) {
        }
        if (event < 0) {
            Toast.makeText(getApplicationContext(), param.getString(TXLiveConstants.EVT_DESCRIPTION), Toast.LENGTH_SHORT).show();
        } else if (event == TXLiveConstants.PLAY_EVT_PLAY_BEGIN) {
            hideProgress();
        }
    }

    @Override
    public void onNetStatus(Bundle status) {
        XLog.d("onNetStatus", "Current status, CPU:" + status.getString(TXLiveConstants.NET_STATUS_CPU_USAGE) +
                ", RES:" + status.getInt(TXLiveConstants.NET_STATUS_VIDEO_WIDTH) + "*" + status.getInt(TXLiveConstants.NET_STATUS_VIDEO_HEIGHT) +
                ", SPD:" + status.getInt(TXLiveConstants.NET_STATUS_NET_SPEED) + "Kbps" +
                ", FPS:" + status.getInt(TXLiveConstants.NET_STATUS_VIDEO_FPS) +
                ", ARA:" + status.getInt(TXLiveConstants.NET_STATUS_AUDIO_BITRATE) + "Kbps" +
                ", VRA:" + status.getInt(TXLiveConstants.NET_STATUS_VIDEO_BITRATE) + "Kbps");
    }

    static class TXPhoneStateListener extends PhoneStateListener {
        WeakReference<TXLivePlayer> mPlayer1;
        WeakReference<TXLivePlayer> mPlayer2;

        public TXPhoneStateListener(TXLivePlayer player1, TXLivePlayer player2) {
            mPlayer1 = new WeakReference<TXLivePlayer>(player1);
            mPlayer2 = new WeakReference<TXLivePlayer>(player2);
        }

        @Override
        public void onCallStateChanged(int state, String incomingNumber) {
            super.onCallStateChanged(state, incomingNumber);
            TXLivePlayer player1 = mPlayer1.get();
            TXLivePlayer player2 = mPlayer2.get();
            switch (state) {
                //电话等待接听
                case TelephonyManager.CALL_STATE_RINGING:
                    if (player1 != null) player1.setMute(true);
                    if (player2 != null) player2.setMute(true);
                    break;
                //电话接听
                case TelephonyManager.CALL_STATE_OFFHOOK:
                    if (player1 != null) player1.setMute(true);
                    if (player2 != null) player2.setMute(true);
                    break;
                //电话挂机
                case TelephonyManager.CALL_STATE_IDLE:
                    if (player1 != null) player1.setMute(false);
                    if (player2 != null) player2.setMute(false);
                    break;
            }
        }
    }

    public void doGetMachineStatus() {
        if (machineStates == GameActivity.MachineStates.FREE || machineStates == GameActivity.MachineStates.BUSY) {
            getP().getMachineStatus(machineInfoParam);
        }
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        if (machineStates == GameActivity.MachineStates.PLAYING) {
            final MaterialDialog materialDialog = new MaterialDialog(context);
            materialDialog.setTitle(R.string.tips)
                    .setMessage(R.string.is_quit_game)
                    .setCanceledOnTouchOutside(true)
                    .setNegativeButton(R.string.cancel, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            materialDialog.dismiss();
                        }
                    })
                    .setPositiveButton(R.string.confirm, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            materialDialog.dismiss();
                            finish();
                        }
                    });
            materialDialog.show();
        } else {
            finish();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        audio = (AudioManager) getSystemService(Service.AUDIO_SERVICE);
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                finishActivity();
                return true;
            case KeyEvent.KEYCODE_VOLUME_UP:
                audio.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        AudioManager.ADJUST_RAISE,
                        AudioManager.FLAG_PLAY_SOUND | AudioManager.FLAG_SHOW_UI);
                return true;
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                audio.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        AudioManager.ADJUST_LOWER,
                        AudioManager.FLAG_PLAY_SOUND | AudioManager.FLAG_SHOW_UI);
                return true;
            default:
                break;
        }
        return super.onKeyDown(keyCode, event);
    }

    @OnClick(R.id.iv_photo)
    void changeCamera() {
        if (!isMachineRight) {
            toast(R.string.machine_status_not_1);
            return;
        }
        isFront = !isFront;
        cvv_front.setVisibility(!isFront ? View.VISIBLE : View.GONE);
        cvv_negative.setVisibility(!isFront ? View.GONE : View.VISIBLE);
    }

    @OnClick(R.id.layout_add_money)
    void addMoney() {
        if (!Utils.isFastClick()) {
            MyAccountActivity.launch(context);
        }
    }

    @OnClick(R.id.toolbar_title)
    void help() {
        if (!Utils.isFastClick()) {
            WebActivity.launch(context, helpUrl, getString(R.string.help));
        }
    }

    @OnClick(R.id.layout_start_game)
    void startGame() {

        if (!isMachineRight) {
            toast(R.string.machine_status_not_1);
            return;
        }
        if (machineInfoParam == null) {
            machineInfoParam = new MachineInfoParam();
            machineInfoParam.setMachineId(machineId);
            machineInfoParam.setUserId(AppContext.getAccount().getUserId());
        }
        if (machineStates == GameActivity.MachineStates.FREE) {

            showProgress();

            sendThread = new SockAPP();
            sendThread.StartWokring(handler, CONTROL_HOST, 7771);

        }
    }

    private void doStartGame() {

        layout_start_game.setEnabled(false);
        MachineInfoParam infoParam = new MachineInfoParam();
        infoParam.setMachineId(orderMachineId);
        infoParam.setUserId(AppContext.getAccount().getUserId());
        getP().userGameStart(infoParam);

    }

    private boolean cantRequest() {
        Log.d("TAG===", System.currentTimeMillis() - startTime + "");
        boolean isCantRequest = System.currentTimeMillis() - startTime < 300;
        if (!isCantRequest) {
            startTime = System.currentTimeMillis();
        }
        return isCantRequest;
    }

    @OnClick(R.id.iv_grab)
    public void grab() {


        doGrap();

    }

    private void doUp() {
        if (sendThread != null) {
            sendThread.SendOutCommand(new CommandEntity(CommandConstants.DO_UP));
        }
    }

    private void doDown() {
        if (sendThread != null) {
            sendThread.SendOutCommand(new CommandEntity(CommandConstants.DO_DOWN));
        }
    }

    private void doLeft() {
        if (sendThread != null) {
            sendThread.SendOutCommand(new CommandEntity(CommandConstants.DO_LEFT));
        }
    }

    private void doRight() {
        if (sendThread != null) {
            sendThread.SendOutCommand(new CommandEntity(CommandConstants.DO_RIGHT));
        }
    }

    private void doGrap() {

        if (sendThread != null) {
            sendThread.SendOutCommand(new CommandEntity(CommandConstants.DO_GRAP));
        }

    }

    public void startLoadingGame(BaseModel<GameBeginModel> result) {
        if (!TextUtils.isEmpty(result.getData().getOrderId())) {

            startGameResult = result;

            CommandEntity command = new CommandEntity(CommandConstants.START,
                    Integer.parseInt(startGameResult.getData().getNewMachineData().getTimeOut()),
                    Integer.parseInt(startGameResult.getData().getNewMachineData().getCatchResult()),
                    Integer.parseInt(startGameResult.getData().getNewMachineData().getPowerCatch()),
                    Integer.parseInt(startGameResult.getData().getNewMachineData().getPowerOntop()),
                    Integer.parseInt(startGameResult.getData().getNewMachineData().getPowerMove()),
                    Integer.parseInt(startGameResult.getData().getNewMachineData().getPowerMax()),
                    Integer.parseInt(startGameResult.getData().getNewMachineData().getHoldHeight()));

            if (sendThread != null) {
                sendThread.SendOutCommand(command);
            }
        }
    }

    public void start321(long value) {
        switch ((int) value) {
            case 0:
                layout_time.setVisibility(View.VISIBLE);
                layout_time.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                    }
                });
                IMAudioManager.instance().release();
                if (isPlaySound) {
                    IMAudioManager.instance().playSound(audioUrl4);
                }
                iv_num.setImageResource(R.drawable.third);
                break;
            case 4:
                iv_num.setImageResource(R.drawable.second);
                break;
            case 8:
                iv_num.setImageResource(R.drawable.first);
                break;
            case 12:
                IMAudioManager.instance().release();
                if (isPlaySound) {
                    IMAudioManager.instance().playSound(audioUrl3);
                }
                iv_num.setImageResource(R.drawable.go);
                break;
            case 16:

                Toast.makeText(GameV2Activity.this, "长按方向键有惊喜！", Toast.LENGTH_SHORT).show();

                layout_time.setVisibility(View.GONE);
                IMAudioManager.instance().release();
                if (isPlaySound) {
                    IMAudioManager.instance().playSound(audioUrl1, true);
                }
                getP().disposeGoDisposable();
                getP().doStartGameTime(Long.valueOf(gameTime));
                break;
            default:
                break;
        }
    }

    public void startGameTime(long sec) {
        tv_time.setText(sec + "\"");
    }

    public void gameOver() {
        machineStates = GameActivity.MachineStates.OVER;
        getP().disGameTime();
//        getP().delayGetOrderStatus(Long.valueOf(orderMsec));
        getP().delayGetOrderStatus(2000);
    }

    public void doGetOrderStatus() {
        showProgress();
        UserOrderParam userOrderParam = new UserOrderParam();
        userOrderParam.setOrderId(orderId);
        getP().getOrderStatus(userOrderParam);
    }

    /**
     * 更新机器状态
     *
     * @param machineResult
     */
    public void updateMachineStatus(BaseModel<MachineStatusModel> machineResult) {
        if (machineStates != GameActivity.MachineStates.PLAYING && machineStates != GameActivity.MachineStates.OVER) {
            if (machineResult.getData().getMachineStatus().equals("1")) {
                machineStates = GameActivity.MachineStates.FREE;
                setCanPlay();
            } else {
                machineStates = GameActivity.MachineStates.BUSY;
                setCantPlay();
            }
        }
    }

    /**
     * 获取抓取结果
     *
     * @param result
     */
    public void doGetCatchResult(BaseModel<OrderStatusModel> result) {
        setCantPlay();
        iv_grab.setEnabled(true);
        machineInfoModel.setUserGameMoney(result.getData().getUserGameMoney());
        tv_money.setText(machineInfoModel.getUserGameMoney());
        if (result.getData().getOrderStatus().equals("1")) {
            IMAudioManager.instance().release();
            if (isPlaySound) {
                IMAudioManager.instance().playSound(audioUrl5,
                        false, new MediaPlayer.OnCompletionListener() {
                            @Override
                            public void onCompletion(MediaPlayer mediaPlayer) {
                                IMAudioManager.instance().release();
                                if (isPlayBg) {
                                    playSoundBg();
                                }
                            }
                        });
            } else {
                if (!isPlaySound && isPlayBg) {
                    getP().delayPlaySound();
                }
            }
            CatchStateDialog.Builder builder = new CatchStateDialog
                    .Builder(this)
                    .setTitleImage(R.drawable.ic_default_image)
                    .setTextView1(getString(R.string.con_catch_success))
                    .setBtn_text1(getString(R.string.confirm))
                    .setSuccess(true)
                    .setNegativeButtonClickListener(
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
            builder.create().show();
        } else {
            IMAudioManager.instance().release();
            if (isPlaySound) {
                IMAudioManager.instance().playSound(audioUrl6,
                        false, new MediaPlayer.OnCompletionListener() {
                            @Override
                            public void onCompletion(MediaPlayer mediaPlayer) {
                                IMAudioManager.instance().release();
                                if (isPlayBg) {
                                    IMAudioManager.instance().playSound(audioUrl2, true);
                                }
                            }
                        });
            } else {
                if (!isPlaySound && isPlayBg) {
                    getP().delayPlaySound();
                }
            }
            CatchStateDialog.Builder builder = new CatchStateDialog
                    .Builder(this)
                    .setTitleImage(R.drawable.ic_default_image)
                    .setTextView1(getString(R.string.con_catch_failed))
                    .setBtn_text1(getString(R.string.confirm))
                    .setSuccess(false)
                    .setNegativeButtonClickListener(
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
            builder.create().show();
        }
    }

    public void playSoundBg() {
        IMAudioManager.instance().playSound(audioUrl2, true);
    }

    //移动结果
    public void doControlResult(StringModel result) {
    }

    //抓取结果
    public void doGrabResult(StringModel result) {
    }

    Handler handler = new Handler() {

        @Override
        public void handleMessage(Message msg) {

            Log.e("msg.what", msg.what + "");

            switch (msg.what) {

                case 0: {

//                    hideProgress();

                    Toast.makeText(getApplicationContext(), "连接成功", Toast.LENGTH_SHORT).show();

                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(1000);
                                //enter machine
                                CommandEntity command = new CommandEntity(CommandConstants.ENTER, machineInfoModel.getNewMachineData().getMacAddress());
                                if (sendThread != null) {
                                    sendThread.SendOutCommand(command);
                                }

                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        doStartGame();
                                    }
                                });

                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }).start();

                    break;
                }

                case 10: {

                    int msg_len = msg.arg1;
                    byte test_data[] = (byte[]) (msg.obj);
                    if (check_com_data(test_data, msg_len) == false) {
                        Log.e("=====data recv===", "-----com check error-----");
                        break;
                    }
                    int cmd = (test_data[7] & 0xff);
                    Log.e("==onhandle==", Integer.toString(cmd));
                    switch (cmd) {
                        case 0x31://new game result notify from server.
                        {

                            gameTime = startGameResult.getData().getGameTime();
                            orderMsec = startGameResult.getData().getOrderMsec();
                            orderId = startGameResult.getData().getOrderId();
                            machineStates = GameActivity.MachineStates.PLAYING;
                            tv_time.setText(startGameResult.getData().getGameTime() + "\"");
                            setPlaying();
                            layout_start_game.setEnabled(true);
                            getP().doGetGo();


                        }
                        break;
                        case 0x33: {
                            //when the doll machine is reset to state available. it will notify the grasp result to playing player--and other people in the room.

                            int zhuawawaret = (test_data[8] & 0xff);

                            Log.d("zhuawawaret", zhuawawaret + "");

                            if (zhuawawaret == 1) {
//                                Toast.makeText(getApplicationContext(), "You grasp the doll!", Toast.LENGTH_SHORT).show();
                                //SUCCESS
                                showProgress();
                                PostGameResultParam postGameResultParam = new PostGameResultParam();
                                postGameResultParam.setOrderId(orderId);
                                postGameResultParam.setOrderStatus("3");
                                getP().postGameResult(postGameResultParam);

                            } else if (zhuawawaret == 0) {

                                //FAIL
                                showProgress();
                                PostGameResultParam postGameResultParam = new PostGameResultParam();
                                postGameResultParam.setOrderId(orderId);
                                postGameResultParam.setOrderStatus("2");
                                getP().postGameResult(postGameResultParam);


//                                Toast.makeText(getApplicationContext(), "You lose", Toast.LENGTH_SHORT).show();
                            } else//other result see in document
                            {
                                Toast.makeText(getApplicationContext(), "other code:" + zhuawawaret, Toast.LENGTH_SHORT).show();
                            }

                            gameOver();

                            break;

                        }
                    }

                    break;
                }

            }
            super.handleMessage(msg);
        }
    };

    //check the data is valid or not
    boolean check_com_data(byte[] data, int len) {

        if (len < 6) return false;
        int check_total = 0;

        //check sum
        for (int i = 0; i < len; i++) {
            if ((i >= 6) && (i < len - 1))
                check_total += (data[i] & 0xff);
        }

        if (data[0] != (byte) (~data[3] & 0xff) && data[1] != (byte) (~data[4] & 0xff) && data[2] != (byte) (~data[5] & 0xff))
            return false;

        if (check_total % 100 != data[len - 1]) {
            return false;
        }

        return true;
    }

    //construct the send packet
    int g_packget_id = 0;

    byte[] user_uart_sendcom(int... params) {
        byte send_buf[] = new byte[8 + params.length];
        send_buf[0] = (byte) 0xfe;
        send_buf[1] = (byte) (g_packget_id);
        send_buf[2] = (byte) (g_packget_id >> 8);
        send_buf[3] = (byte) ~send_buf[0];
        send_buf[4] = (byte) ~send_buf[1];
        send_buf[5] = (byte) ~send_buf[2];
        send_buf[6] = (byte) (8 + params.length);
        for (int i = 0; i < params.length; i++) {
            send_buf[7 + i] = (byte) (params[i]);
        }

        int sum = 0;
        for (int i = 6; i < (8 + params.length - 1); i++) {
            sum += (send_buf[i] & 0xff);
        }

        send_buf[8 + params.length - 1] = (byte) (sum % 100);

        g_packget_id++;
        return send_buf;
    }

    class ButtonListener implements View.OnTouchListener {

        @Override
        public boolean onTouch(View v, MotionEvent event) {

            if (event.getAction() == MotionEvent.ACTION_UP) {

                if (sendThread != null) {
                    sendThread.SendOutCommand(new CommandEntity(CommandConstants.DO_STOP));
                }
            }

            if (event.getAction() == MotionEvent.ACTION_DOWN) {

                if (ButtonUtil.isFastDoubleClick() == true) {

                    ButtonUtil.count++;

                    if (ButtonUtil.count == 3) {
                        Toast.makeText(GameV2Activity.this, "长按方向键有惊喜！", Toast.LENGTH_SHORT).show();
                        ButtonUtil.count = 0;
                    }

                } else {

                    switch (v.getId()) {

                        case R.id.iv_up: {

                            doUp();

                            break;
                        }

                        case R.id.iv_down: {

                            doDown();

                            break;
                        }

                        case R.id.iv_left: {

                            doLeft();

                            break;
                        }

                        case R.id.iv_right: {

                            doRight();

                            break;
                        }
                    }
                }
            }

            return false;
        }
    }

}
