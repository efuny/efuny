package cn.legendream.wawa.ui.v3.mine.reward;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import cn.legendream.wawa.R;
import cn.legendream.wawa.model.RewardModel;

/**
 * Created by zhaoyuefeng on 2019/5/2.
 * Description 
 */
public class RewardRecyclerAdapter extends RecyclerView.Adapter {

    List<RewardModel.ListBean> list = new ArrayList<>();
    Context context;

    public RewardRecyclerAdapter(Context context) {

        this.context = context;

    }

    public void refreshData(List<RewardModel.ListBean> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.reward_list_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        ViewHolder vh = (ViewHolder) holder;

        RewardModel.ListBean data = list.get(position);

        vh.nameTv.setText(data.getNick_name());
        vh.dateTv.setText(data.getDate_time());
        vh.moneyTv.setText(data.getMoney());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.name_tv)
        TextView nameTv;
        @BindView(R.id.date_tv)
        TextView dateTv;
        @BindView(R.id.money_tv)
        TextView moneyTv;

        ViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }
}
