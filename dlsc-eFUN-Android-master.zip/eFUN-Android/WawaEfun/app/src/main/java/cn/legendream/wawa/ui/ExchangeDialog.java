package cn.legendream.wawa.ui;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.ImageView;

import cn.legendream.wawa.R;

/**
 * Created by zhaoyuefeng on 2018/9/27.
 * Description
 */

public class ExchangeDialog extends Dialog {

    ImageView closeIv;
    ImageView aliIv;
    ImageView wechatIv;

    String orderNo;

    GoodDetailActivity goodDetailActivity;

    public ExchangeDialog(@NonNull Context context, GoodDetailActivity goodDetailActivity, String orderNo) {
        this(context, R.style.Dialog);
        this.goodDetailActivity = goodDetailActivity;
        this.orderNo = orderNo;
    }

    public ExchangeDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.send_baby_dialog);

        closeIv = findViewById(R.id.close_iv);
        aliIv = findViewById(R.id.ali_iv);
        wechatIv = findViewById(R.id.wechat_iv);

        closeIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        aliIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goodDetailActivity.createAliOrder(orderNo);
                dismiss();
            }
        });

        wechatIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goodDetailActivity.createWechatOrder(orderNo);
                dismiss();
            }
        });

    }
}
