package cn.legendream.wawa.view;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;

/**
 * @version V1.0 <>
 * @FileName: ScoreChoiceDialog
 * @author: Samson.Sun
 * @date: 2018-6-7 22:42
 * @email: s_xin@neusoft.com
 */
public class ScoreChoiceDialog extends Dialog {
    public ScoreChoiceDialog(@NonNull Context context) {
        super(context);
    }

    public interface OnSubmitClickListener {
        void onScoreChange(DialogInterface dialog, String money, String score, boolean isMoney);
    }

    public ScoreChoiceDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    public static class Builder {
        private Context context;
        private String name;
        private String money;
        private String score;
        private boolean isMoney = true;
        private OnSubmitClickListener onSubmitClickListener;

        public Builder(Context context) {
            this.context = context;
        }

        public Builder setMessage(String name, String money, String score, boolean isMoney) {
            this.name = name;
            this.money = money;
            this.score = score;
            this.isMoney = isMoney;
            return this;
        }

        public Builder setOnSubmitClickListener(OnSubmitClickListener onSubmitClickListener) {
            this.onSubmitClickListener = onSubmitClickListener;
            return this;
        }

        public ScoreDialog create() {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final ScoreDialog dialog = new ScoreDialog(context, R.style.Dialog);
            View layout = inflater.inflate(R.layout.dialog_choice_score, null);
            TextView contentTv = layout.findViewById(R.id.content_tv);
//            View layout_money = layout.findViewById(R.id.layout_money);
            final TextView tv_money = layout.findViewById(R.id.money_tv);
//            TextView tv_money = layout.findViewById(R.id.tv_money);
//            View layout_score = layout.findViewById(R.id.layout_score);
            final TextView tv_score = layout.findViewById(R.id.score_tv);
//            TextView tv_score = layout.findViewById(R.id.tv_score);
            Button negativeButton = layout.findViewById(R.id.negativeButton);
            negativeButton.setTypeface(Utils.getGoTrialFont(context));
//            String content = context.getResources().getString(R.string.dialog_sure_use)
//                    + "<font color='#FF7F7D'>" + name + "</font>"
//                    + context.getResources().getString(R.string.exchange)
//                    + "<font color='#FF7F7D'>" + score + "</font>"
//                    + context.getResources().getString(R.string.dialog_score);
//            tv_content.setText(Html.fromHtml(content));
            contentTv.setText(name);
            if (!TextUtils.isEmpty(money)) {
                tv_money.setText(money);
            } else {
                tv_money.setVisibility(View.INVISIBLE);
            }
            if (!TextUtils.isEmpty(score)) {
                tv_score.setText(score);
            } else {
                tv_score.setVisibility(View.INVISIBLE);
            }
            if (isMoney) {
                tv_money.setSelected(true);
                tv_score.setSelected(false);
            } else {
                tv_money.setSelected(false);
                tv_score.setSelected(true);
            }
            tv_money.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (isMoney) {
                        tv_money.setSelected(true);
                        tv_score.setSelected(false);
                        return;
                    } else {
                        isMoney = true;
                        tv_money.setSelected(true);
                        tv_score.setSelected(false);
                    }
                }
            });
            tv_score.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (isMoney) {
                        isMoney = false;
                        tv_money.setSelected(false);
                        tv_score.setSelected(true);
                    } else {
                        tv_money.setSelected(false);
                        tv_score.setSelected(true);
                        return;
                    }
                }
            });
            negativeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onSubmitClickListener.onScoreChange(dialog, money, score, isMoney);
                }
            });
            dialog.setContentView(layout);
            return dialog;
        }
    }
}