package cn.legendream.wawa.kit;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import cn.droidlover.xdroidmvp.BuildConfig;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * @version V1.0 <>
 * @FileName: AES128
 * @author: Samson.Sun
 * @date: 2017-12-6 9:48
 * @email: s_xin@neusoft.com
 */
public class AES128 {
    /*
    * 加密用的Key 可以用26个字母和数字组成 此处使用AES-128-CBC加密模式，key需要为16位。
    */
    private String sKey = BuildConfig.AESKey;
    private String ivParameter = BuildConfig.AESParameter;
    private static AES128 instance = null;

    private AES128() {

    }

    public static AES128 getInstance() {
        if (instance == null)
            instance = new AES128();
        return instance;
    }

    // 加密
    public String encrypt(String sSrc) {
        String result = "";
        try {
            Cipher cipher;
            cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            byte[] raw = sKey.getBytes();
            SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
            IvParameterSpec iv = new IvParameterSpec(ivParameter.getBytes());// 使用CBC模式，需要一个向量iv，可增加加密算法的强度
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
            byte[] encrypted = cipher.doFinal(sSrc.getBytes("utf-8"));
            result = new BASE64Encoder().encode(encrypted);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 此处使用BASE64做转码。
        return result;

    }

    // 解密
    public String decrypt(String sSrc) {
        try {
            byte[] raw = sKey.getBytes("ASCII");
            SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            IvParameterSpec iv = new IvParameterSpec(ivParameter.getBytes());
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
            byte[] encrypted1 = new BASE64Decoder().decodeBuffer(sSrc);// 先用base64解密
            byte[] original = cipher.doFinal(encrypted1);
            String originalString = new String(original, "utf-8");
            return originalString;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) {
        System.out.println("密码：" + AES128.getInstance().sKey);
        System.out.println("偏移量：" + AES128.getInstance().ivParameter);
        // 需要加密的字串
        String cSrc = "{\"gender\":\"0\",\"headUrl\":\"http://avatar.csdn.net/4/7/2/1_zbasd.jpg\",\"nickName\":\"前堂客\",\"unionId\":\"123456\"}";
        System.out.println(cSrc);
        System.out.println("长度为" + cSrc.length());
        // 加密
        long lStart = System.currentTimeMillis();
        String enString = AES128.getInstance().encrypt(cSrc);
        System.out.println("加密后的字串是：" + enString);
        System.out.println("长度为" + enString.length());

        long lUseTime = System.currentTimeMillis() - lStart;
        System.out.println("加密耗时：" + lUseTime + "毫秒");
        // 解密
        lStart = System.currentTimeMillis();
        String DeString = AES128.getInstance().decrypt(enString);
        System.out.println("解密后的字串是：" + DeString);
        lUseTime = System.currentTimeMillis() - lStart;
        System.out.println("解密耗时：" + lUseTime + "毫秒");
    }

    /**
     * 修改字符串中的unicode码
     *
     * @param s 源str
     * @return 修改后的str
     */
    public static String decode2(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        char[] chars = s.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            char c = chars[i];
            if (c == '\\' && chars[i + 1] == 'u') {
                char cc = 0;
                for (int j = 0; j < 4; j++) {
                    char ch = Character.toLowerCase(chars[i + 2 + j]);
                    if ('0' <= ch && ch <= '9' || 'a' <= ch && ch <= 'f') {
                        cc |= (Character.digit(ch, 16) << (3 - j) * 4);
                    } else {
                        cc = 0;
                        break;
                    }
                }
                if (cc > 0) {
                    i += 5;
                    sb.append(cc);
                    continue;
                }
            }
            sb.append(c);
        }
        return sb.toString();
    }
}
