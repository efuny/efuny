package cn.legendream.wawa.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.router.Router;
import cn.droidlover.xdroidmvp.view.refreshlayout.SmartRefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.MaterialHeader;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.RefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.listener.OnRefreshLoadmoreListener;
import cn.droidlover.xrecyclerview.RecyclerItemCallback;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.adapter.GoodsAdapter;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.GoodsModel;
import cn.legendream.wawa.model.MallGoodListParam;
import cn.legendream.wawa.present.GoodsListPresent;

/**
 * @version V1.0 <>
 * @FileName: GoodsListActivity
 * @author: Samson.Sun
 * @date: 2018-7-9 23:34
 * @email: s_xin@neusoft.com
 */
public class GoodsListActivity extends XActivity<GoodsListPresent> {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.rv_list)
    XRecyclerView rv_list;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    private GoodsAdapter mAdapter;
    List<GoodsModel> goodsModelList;
    public static final String PARAM_ID = "param_id";
    private String categoryId;
    private int page = 1;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar)
                .statusBarDarkFont(true, 0.2f).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        categoryId = getIntent().getStringExtra(PARAM_ID);
        initAdapter();
        refreshLayout.setRefreshHeader(new MaterialHeader(context).setShowBezierWave(false));
        refreshLayout.autoRefresh();
        final MallGoodListParam mallGoodListParam = new MallGoodListParam();
        mallGoodListParam.setUserId(AppContext.getAccount().getUserId());
        mallGoodListParam.setCategoryId(categoryId);
        mallGoodListParam.setPage(page + "");
        refreshLayout.setOnRefreshLoadmoreListener(new OnRefreshLoadmoreListener() {
            @Override
            public void onLoadmore(RefreshLayout refreshlayout) {
                page++;
                mallGoodListParam.setPage(page + "");
                getP().getMallGoodList(false, mallGoodListParam);
            }

            @Override
            public void onRefresh(RefreshLayout refreshlayout) {
                page = 1;
                mallGoodListParam.setPage(page + "");
                getP().getMallGoodList(true, mallGoodListParam);
            }
        });
    }

    private void initAdapter() {
        goodsModelList = new ArrayList<>();
        mAdapter = new GoodsAdapter(context);
        rv_list.setItemAnimator(new DefaultItemAnimator());
        rv_list.gridLayoutManager(context, 2);
        rv_list.setAdapter(mAdapter);
        mAdapter.setRecItemClick(new RecyclerItemCallback<GoodsModel, GoodsAdapter.ViewHolder>() {
            @Override
            public void onItemClick(int position, GoodsModel model, int tag, GoodsAdapter.ViewHolder holder) {
                if (!Utils.isFastClick()) {
                    GoodDetailActivity.launch(context, model.getGoodId(), model.getGoodName(), model.getGoodType());
                }
            }
        });
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_goods_list;
    }

    @Override
    public GoodsListPresent newP() {
        return new GoodsListPresent();
    }

    public static void launch(Activity activity, String categoryId) {
        Router.newIntent(activity)
                .to(GoodsListActivity.class)
                .putString(PARAM_ID, categoryId)
                .launch();
    }

    public void showError(NetError error) {
        super.showError(error);
        refreshLayout.finishRefresh();
    }

    public void showData(boolean isRefresh, BaseModel<List<GoodsModel>> result) {
        if (isRefresh) {
            refreshLayout.finishRefresh();
            refreshLayout.resetNoMoreData();
        } else {
            refreshLayout.finishLoadmore();
        }
        if (page > 1) {
            mAdapter.addData(result.getData());
        } else {
            mAdapter.setData(result.getData());
        }
    }
}
