package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: MallExchangeModel
 * @author: Samson.Sun
 * @date: 2018-7-21 16:17
 * @email: s_xin@neusoft.com
 */
public class MallExchangeModel {
    public MallExchangeModel() {
    }

    private String orderNumber;
    private String price;
    private String userPoint;

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getUserPoint() {
        return userPoint;
    }

    public void setUserPoint(String userPoint) {
        this.userPoint = userPoint;
    }
}
