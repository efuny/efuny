package cn.legendream.wawa.model;

import java.util.List;

/**
 * @version V1.0 <>
 * @FileName: UserAddressModel
 * @author: Samson.Sun
 * @date: 2017-12-22 16:17
 * @email: s_xin@neusoft.com
 */
public class UserAddressModel {
    public UserAddressModel() {
    }
    private List<AddressModel> addressList;

    public List<AddressModel> getAddressList() {
        return addressList;
    }

    public void setAddressList(List<AddressModel> addressList) {
        this.addressList = addressList;
    }
}
