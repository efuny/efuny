package cn.legendream.wawa.wxapi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.widget.Toast;

import com.tencent.mm.opensdk.modelbase.BaseReq;
import com.tencent.mm.opensdk.modelbase.BaseResp;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.umeng.socialize.weixin.view.WXCallbackActivity;

import cn.droidlover.xdroidmvp.log.XLog;
import cn.legendream.wawa.kit.Constants;

/**
 * @version V1.0 <>
 * @FileName: WXEntryActivity
 * @author: Samson.Sun
 * @date: 2017-12-7 21:24
 * @email: s_xin@neusoft.com
 */
public class WXEntryActivity extends WXCallbackActivity {
    // IWXAPI 是第三方app和微信通信的openapi接口
    /*private IWXAPI api;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        api = WXAPIFactory.createWXAPI(this, Constants.APP_ID, false);
        api.registerApp(Constants.APP_ID);
        try {
            api.handleIntent(getIntent(), this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onReq(BaseReq baseReq) {
        XLog.d("req:", baseReq);
    }

    @Override
    public void onResp(BaseResp resp) {
        Toast.makeText(this, "resp.errCode = " + resp.errCode, Toast.LENGTH_SHORT).show();

        switch (resp.errCode) {
            case BaseResp.ErrCode.ERR_OK:
                Toast.makeText(this, "授权成功", Toast.LENGTH_LONG).show();
                break;
            default:
                Toast.makeText(this, "授权失败" + resp.errCode, Toast.LENGTH_LONG).show();
                break;
        }
        finish();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        setIntent(intent);
        api.handleIntent(intent, this);
    }*/
}
