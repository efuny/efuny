package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: RecordParam
 * @author: Samson.Sun
 * @date: 2017-12-20 22:48
 * @email: s_xin@neusoft.com
 */
public class RecordParam {
    public RecordParam() {
    }

    private String userId;
    private String type;
    private String page;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }
}
