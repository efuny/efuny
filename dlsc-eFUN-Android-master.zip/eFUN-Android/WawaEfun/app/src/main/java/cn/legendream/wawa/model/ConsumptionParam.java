package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: ConsumptionParam
 * @author: Samson.Sun
 * @date: 2018-4-3 9:38
 * @email: s_xin@neusoft.com
 */
public class ConsumptionParam {
    public ConsumptionParam() {
    }

    private String userId;
    private String page;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }
}
