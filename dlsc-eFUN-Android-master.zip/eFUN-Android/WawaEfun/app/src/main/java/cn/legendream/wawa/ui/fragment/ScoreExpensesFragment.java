package cn.legendream.wawa.ui.fragment;


import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.adapter.ScoreAdapter;

/**
 * @version V1.0 <>
 * @FileName: ScoreExpensesFragment
 * @author: Samson.Sun
 * @date: 2017-12-16 23:39
 * @email: s_xin@neusoft.com
 */
public class ScoreExpensesFragment extends BaseScoreFragment {
    ScoreAdapter adapter;

    public static ScoreExpensesFragment newInstance(ScoreChanged scoreChanged) {
        scoreChangeListener = scoreChanged;
        return new ScoreExpensesFragment();
    }

    @Override
    public SimpleRecAdapter getAdapter() {
        if (adapter == null) {
            adapter = new ScoreAdapter(context, 2);
        }
        return adapter;
    }

    @Override
    public void setLayoutManager(XRecyclerView recyclerView) {
        recyclerView.verticalLayoutManager(context);
    }

    @Override
    public String getType() {
        return "2";
    }
}
