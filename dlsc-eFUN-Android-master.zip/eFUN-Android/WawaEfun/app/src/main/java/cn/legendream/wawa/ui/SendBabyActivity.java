package cn.legendream.wawa.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.alipay.sdk.app.PayTask;
import com.tencent.mm.opensdk.modelpay.PayReq;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.BuildConfig;
import cn.droidlover.xdroidmvp.event.BusProvider;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.droidlover.xdroidmvp.view.refreshlayout.SmartRefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.MaterialHeader;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.RefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.listener.OnRefreshListener;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.adapter.SendBabyAdapter;
import cn.legendream.wawa.alipay.PayResult;
import cn.legendream.wawa.event.PayEvent;
import cn.legendream.wawa.event.RefreshCatchEvent;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.AddressInfoModel;
import cn.legendream.wawa.model.AddressModel;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.DeliverSubmitParam;
import cn.legendream.wawa.model.DollDeliverModel;
import cn.legendream.wawa.model.DollDeliverParam;
import cn.legendream.wawa.model.DollListInfoModel;
import cn.legendream.wawa.model.GetExpressPriceOrderModel;
import cn.legendream.wawa.model.GetExpressPriceOrderParam;
import cn.legendream.wawa.model.GetExpressPriceParam;
import cn.legendream.wawa.model.PayCreateOrderModel;
import cn.legendream.wawa.model.SendBabyModel;
import cn.legendream.wawa.model.WxPayOrderModel;
import cn.legendream.wawa.present.SendBabyPresent;
import cn.legendream.wawa.view.SendConfirmDialog;
import io.reactivex.functions.Consumer;

import static android.support.v7.widget.DividerItemDecoration.VERTICAL;

/**
 * 发货
 *
 * @version V1.0 <>
 * @FileName: SendBabyActivity
 * @author: Samson.Sun
 * @date: 2017-12-13 21:44
 * @email: s_xin@neusoft.com
 */
public class SendBabyActivity extends XActivity<SendBabyPresent> {
    @BindView(R.id.tv_user_name)
    TextView tv_user_name;
    @BindView(R.id.tv_phone_no)
    TextView tv_phone_no;
    @BindView(R.id.tv_address_tag)
    TextView tv_address_tag;
    @BindView(R.id.tv_address)
    TextView tv_address;
    @BindView(R.id.tv_create_address)
    TextView tv_create_address;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    @BindView(R.id.rv_my_baby)
    XRecyclerView rv_my_baby;
    @BindView(R.id.layout_content)
    View layout_content;
    private int maxMarginTop = 0;
    private int maxMarginLeft = 0;
    private int maxMarginRight = 0;
    private int EXPEND_MARGIN_TOP = 0;//展开后margin
    private SendBabyAdapter adapter;
    private List<DollListInfoModel> dollDeliverModelList;
    private AddressInfoModel addressInfoModel;
    private List<String> choiceList;
    private String expressPrice;

    public static final String PARAM_ORDER_ID = "order_id";
    private String orderId;


    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(false);
        }
        orderId = getIntent().getStringExtra(PARAM_ORDER_ID);
        EXPEND_MARGIN_TOP = Kits.Dimens.dpToPxInt(context, 10);
        ViewGroup.MarginLayoutParams marginParams = getMarginLayoutParams(refreshLayout);
        maxMarginTop = marginParams.topMargin;
        maxMarginLeft = marginParams.leftMargin;
        maxMarginRight = marginParams.rightMargin;
        initAdapter();
        refreshLayout.setRefreshHeader(new MaterialHeader(context).setShowBezierWave(false));
        refreshLayout.autoRefresh();
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(RefreshLayout refreshlayout) {
                refreshList();
            }
        });


        TypedValue tv = new TypedValue();
        int actionBarHeight = 0;
        if (getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {
            actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, getResources().getDisplayMetrics());
        }
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        int fullHeight = wm.getDefaultDisplay().getHeight() - actionBarHeight - Kits.Dimens.dpToPxInt(context, 100);
        int fullWidth = wm.getDefaultDisplay().getWidth() - Kits.Dimens.dpToPxInt(context, 40);
        ViewGroup.LayoutParams layoutParams = layout_content.getLayoutParams();
        layoutParams.width = fullWidth;
        layoutParams.height = fullHeight;
        layout_content.setLayoutParams(layoutParams);

        BusProvider.getBus().toFlowable(PayEvent.class)
                .subscribe(new Consumer<PayEvent>() {
                    @Override
                    public void accept(PayEvent payEvent) throws Exception {
                        toastMessage("支付成功", "");
                        finish();
                    }
                });

    }

    private void initAdapter() {
        dollDeliverModelList = new ArrayList<>();
        choiceList = new ArrayList<>();

        int width = Utils.getScreenWidth(this);

        int itemWidth = (width - Utils.dip2px(this, 20)) / 2;

        adapter = new SendBabyAdapter(context, itemWidth);
        rv_my_baby.setItemAnimator(new DefaultItemAnimator());
        rv_my_baby.setLayoutManager(new GridLayoutManager(context, 2));
//        rv_my_baby.addItemDecoration(new DividerItemDecoration(context, VERTICAL));
        rv_my_baby.setAdapter(adapter);
        adapter.setOnCheckedListener(new SendBabyAdapter.OnCheckedListener() {
            @Override
            public void OnChecked(String orderId, boolean isChecked, int position) {
                if (isChecked) {
                    choiceList.add(orderId);
                } else {
                    if (!Kits.Empty.check(choiceList)) {
                        for (int i = 0; i < choiceList.size(); i++) {
                            if (choiceList.get(i).equals(orderId)) {
                                choiceList.remove(i);
                                break;
                            }
                        }
                    }
                }
//                setSendButton();
            }
        });
    }

    private void refreshList() {
        DollDeliverParam dollDeliverParam = new DollDeliverParam();
        dollDeliverParam.setUserId(AppContext.getAccount().getUserId());
        dollDeliverParam.setOrderId(orderId);
        getP().userDollDeliver(dollDeliverParam);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_send;
    }

    @Override
    public SendBabyPresent newP() {
        return new SendBabyPresent();
    }

    private void setMargin(int px) {
        ViewGroup.MarginLayoutParams marginParams = getMarginLayoutParams(refreshLayout);
        marginParams.setMargins(maxMarginLeft, px, maxMarginRight, 0);
        refreshLayout.setLayoutParams(marginParams);
    }

    @OnClick(R.id.address_ll)
    void editAddress() {
        if (!Utils.isFastClick()) {
            ChoiceAddressActivity.launch(context);
        }
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    @OnClick(R.id.tv_create_address)
    void send() {
        if (!Utils.isFastClick()) {
            if (addressInfoModel == null || Kits.Empty.check(addressInfoModel.getAddressId())) {
                toast(R.string.please_choice_add);
                return;
            }
            if (!Kits.Empty.check(choiceList)) {

                String choiceIds = choiceList.get(0);

                if (choiceList.size() > 1) {

                    for (int i = 1; i < choiceList.size(); i++) {
                        choiceIds += "," + choiceList.get(i);
                    }
                    DeliverSubmitParam deliverSubmitParam = new DeliverSubmitParam();
//                    deliverSubmitParam.setAddressId(addressInfoModel.getAddress());
                    deliverSubmitParam.setAddressId(addressInfoModel.getAddressId());
                    deliverSubmitParam.setOrderIds(choiceIds);
                    deliverSubmitParam.setUserId(AppContext.getAccount().getUserId());
                    getP().userDeliverSubmit(deliverSubmitParam);

                } else {

                    final String finalChoiceIds = choiceIds;
                    SendConfirmDialog.Builder builder = new SendConfirmDialog.Builder(context)
                            .setExpressPrice(expressPrice)
                            .setOnSubmitClickListener(new SendConfirmDialog.OnConfirmClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog) {

                                    GetExpressPriceParam getExpressPriceParam = new GetExpressPriceParam();
                                    getExpressPriceParam.setUserId(AppContext.getAccount().getUserId());
                                    getExpressPriceParam.setExpressPrice(expressPrice);
                                    getExpressPriceParam.setAddressId(addressInfoModel.getAddressId());
                                    getExpressPriceParam.setOrderId(finalChoiceIds);
                                    getP().getExpressPriceOrderId(getExpressPriceParam);

                                    dialog.dismiss();

                                }
                            });

                    builder.create().show();


                }

            }
        }
    }

    public static void launch(Activity activity, String orderId) {
        Router.newIntent(activity)
                .to(SendBabyActivity.class)
                .putString(PARAM_ORDER_ID, orderId)
                .launch();
    }

    public void showData(BaseModel<DollDeliverModel> result) {
        refreshLayout.finishRefresh();
        dollDeliverModelList.clear();
        List<DollListInfoModel> dollList = result.getData().getDollList();
        dollDeliverModelList.addAll(dollList);
        addressInfoModel = result.getData().getAddressInfo();
        setAddress();
        adapter.setData(dollDeliverModelList);
        choiceList.clear();
        for (int i = 0; i < dollList.size(); i++) {
            if (dollList.get(i).getIsCheck().equals("1")) {
                choiceList.add(dollList.get(i).getOrderId());
            }
        }
        expressPrice = result.getData().getAddressInfo().getPayCreateExpressPrice();
//        setSendButton();
    }

    private void setSendButton() {
        if (!Kits.Empty.check(choiceList) && !Kits.Empty.check(expressPrice)) {
            if (choiceList.size() == 1) {
                tv_create_address.setText(Utils.formatStrings(context, R.string.send_1_tips, expressPrice));
            } else {
                tv_create_address.setText(getString(R.string.send_more_tips));
            }
        }
    }

    public void deliverResult(BaseModel result) {
        BusProvider.getBus().post(new RefreshCatchEvent());
        toast(R.string.send_baby_submit);
        finish();
    }

    public void getExpressPriceResult(BaseModel<GetExpressPriceOrderModel> getExpressPriceOrderModelBaseModel) {

        SendBabyDialog sendBabyDialog = new SendBabyDialog(this, this, getExpressPriceOrderModelBaseModel.getData().getOrderNo());
        sendBabyDialog.show();

    }

    public void createWechatOrder(String orderNo) {

        GetExpressPriceOrderParam param = new GetExpressPriceOrderParam();
        param.setUserId(AppContext.getAccount().getUserId());
        param.setOrderNo(orderNo);

        getP().getExpressWxPayCreateOrder(param);

    }

    public void createAliOrder(String orderNo) {

        GetExpressPriceOrderParam param = new GetExpressPriceOrderParam();
        param.setUserId(AppContext.getAccount().getUserId());
        param.setOrderNo(orderNo);

        getP().getExpressAliPayCreateOrder(param);

    }

    public void wechatOrder(BaseModel<WxPayOrderModel> result) {
        payWechat(result.getData());
    }

    public void aliPayOrder(BaseModel<PayCreateOrderModel> payCreateOrderModelBaseModel) {
        alipay(payCreateOrderModelBaseModel.getData().getStr());
    }

    private void payWechat(final WxPayOrderModel wxPayOrderModel) {
        final IWXAPI api = WXAPIFactory.createWXAPI(this, BuildConfig.wechatKey);
        try {
            PayReq req = new PayReq();
            req.appId = BuildConfig.wechatKey;
            req.partnerId = wxPayOrderModel.getPartnerid();
            req.prepayId = wxPayOrderModel.getPrepayid();
            req.nonceStr = wxPayOrderModel.getNoncestr();
            req.timeStamp = wxPayOrderModel.getTimestamp();
            req.packageValue = wxPayOrderModel.getPackageValue();
            req.sign = wxPayOrderModel.getSign();
            req.extData = "app data";
            // 在支付之前，如果应用没有注册到微信，应该先调用IWXMsg.registerApp将应用注册到微信
            api.sendReq(req);
        } catch (Exception e) {
        }
    }

    private void alipay(final String orderInfo) {
        Runnable payRunnable = new Runnable() {

            @Override
            public void run() {
                PayTask alipay = new PayTask(context);
                Map<String, String> result = alipay.payV2(orderInfo, true);

                Message msg = new Message();
                msg.obj = result;
                mHandler.sendMessage(msg);
            }
        };

        Thread payThread = new Thread(payRunnable);
        payThread.start();
    }

    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {
        @SuppressWarnings("unused")
        public void handleMessage(Message msg) {
            @SuppressWarnings("unchecked")
            PayResult payResult = new PayResult((Map<String, String>) msg.obj);
            /**
             对于支付结果，请商户依赖服务端的异步通知结果。同步通知结果，仅作为支付结束的通知。
             */
            String resultInfo = payResult.getResult();// 同步返回需要验证的信息
            String resultStatus = payResult.getResultStatus();
            // 判断resultStatus 为9000则代表支付成功
            if (TextUtils.equals(resultStatus, "9000")) {
                // 该笔订单是否真实支付成功，需要依赖服务端的异步通知。
                BusProvider.getBus().post(new PayEvent());
            } else {
                // 该笔订单真实的支付结果，需要依赖服务端的异步通知。
                Toast.makeText(context, "支付失败", Toast.LENGTH_SHORT).show();
            }
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case Keys.CHOICE_ADDRESS:
                    AddressModel model = (AddressModel) data.getSerializableExtra(Keys.CHOICE_ADDRESS_RESULT);
                    addressInfoModel.setAddress(model.getAddress());
                    addressInfoModel.setIsDefault(model.getIsDefault());
                    addressInfoModel.setMobile(model.getMobile());
                    addressInfoModel.setPerson(model.getPerson());
                    addressInfoModel.setAddressId(model.getAddressId());
                    setAddress();
                    break;
            }
        }
    }

    private void setAddress() {
        tv_user_name.setText(addressInfoModel.getPerson());
        tv_phone_no.setText(Utils.hidePhone(addressInfoModel.getMobile()));
        tv_address_tag.setVisibility(addressInfoModel.getIsDefault().equals("0") ? View.GONE : View.VISIBLE);
        tv_address.setText(addressInfoModel.getAddress());
    }
}
