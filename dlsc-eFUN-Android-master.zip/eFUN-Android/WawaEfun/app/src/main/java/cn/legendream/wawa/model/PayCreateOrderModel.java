package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: PayCreateOrderModel
 * @author: Samson.Sun
 * @date: 2018-1-20 0:09
 * @email: s_xin@neusoft.com
 */
public class PayCreateOrderModel {
    public PayCreateOrderModel() {
    }

    private String str;

    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }
}
