package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: MallInfoModel
 * @author: Samson.Sun
 * @date: 2018-7-18 0:32
 * @email: s_xin@neusoft.com
 */
public class MallInfoModel {
    public MallInfoModel() {
    }

    private UserAddressInfoModel userAddressInfo;
    private String goodImageUrl;
    private String goodId;
    private String goodName;
    private String goodType;
    private String integral;
    private String price;
    private String expressPriceText;
    private String expressPrice;
    private String goodDetail;
    private String userPoint;

    public UserAddressInfoModel getUserAddressInfo() {
        return userAddressInfo;
    }

    public void setUserAddressInfo(UserAddressInfoModel userAddressInfo) {
        this.userAddressInfo = userAddressInfo;
    }

    public String getGoodImageUrl() {
        return goodImageUrl;
    }

    public void setGoodImageUrl(String goodImageUrl) {
        this.goodImageUrl = goodImageUrl;
    }

    public String getGoodId() {
        return goodId;
    }

    public void setGoodId(String goodId) {
        this.goodId = goodId;
    }

    public String getGoodName() {
        return goodName;
    }

    public void setGoodName(String goodName) {
        this.goodName = goodName;
    }

    public String getGoodType() {
        return goodType;
    }

    public void setGoodType(String goodType) {
        this.goodType = goodType;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getExpressPriceText() {
        return expressPriceText;
    }

    public void setExpressPriceText(String expressPriceText) {
        this.expressPriceText = expressPriceText;
    }

    public String getExpressPrice() {
        return expressPrice;
    }

    public void setExpressPrice(String expressPrice) {
        this.expressPrice = expressPrice;
    }

    public String getGoodDetail() {
        return goodDetail;
    }

    public void setGoodDetail(String goodDetail) {
        this.goodDetail = goodDetail;
    }

    public String getUserPoint() {
        return userPoint;
    }

    public void setUserPoint(String userPoint) {
        this.userPoint = userPoint;
    }
}
