package cn.legendream.wawa.kit;

/**
 * @version V1.0 <>
 * @FileName: Keys
 * @author: Samson.Sun
 * @date: 2017-12-6 11:05
 * @email: s_xin@neusoft.com
 */
public class Keys {
    public static final String ACCOUNT = "10000";
    public static final String IS_LOGIN = "10001";
    public static final String IS_BACKGROUND_MUSIC = "10002";//背景音乐
    public static final String IS_SOUND = "10003";//音效
    public static final String CATEGORY = "10004";//首页分类
    public static final String IS_EDIT = "10005";
    public static final String EDIT_ADDRESS = "10006";
    public static final int ADD_ADDRESS = 2001;//添加地址
    public static final int IMAGE_PICKER = 2002;
    public static final int CHOICE_ADDRESS = 2003;//选择地址
    public static final String ADD_ADDRESS_RESULT = "2001";
    public static final String CHOICE_ADDRESS_RESULT = "2002";
    public static final String TEST_LOGIN_SHOW = "1";
    public static final String TEST_LOGIN_DISMISS= "0";
    public static final int INTERVAL_GET_STATUS = 1;//获取机器状态
    public static final long INTERVAL_GET_GO = 250;//321go 毫秒
    public static final long INTERVAL_GET_GAME = 1;
    public static final String VERSION_CODE = "10007";//版本号
    public static final String SCORE_SHOP_URL = "10008";//积分商店url
}
