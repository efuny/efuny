package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: MallInfoParam
 * @author: Samson.Sun
 * @date: 2018-7-18 0:34
 * @email: s_xin@neusoft.com
 */
public class MallInfoParam {
    public MallInfoParam() {
    }

    private String goodId;
    private String userId;

    public String getGoodId() {
        return goodId;
    }

    public void setGoodId(String goodId) {
        this.goodId = goodId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
