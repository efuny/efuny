package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: PostModel
 * @author: Samson.Sun
 * @date: 2017-12-8 10:18
 * @email: s_xin@neusoft.com
 */
public class PostModel {
    private String data;
    public PostModel(String data) {
        this.data = data;
    }
    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
