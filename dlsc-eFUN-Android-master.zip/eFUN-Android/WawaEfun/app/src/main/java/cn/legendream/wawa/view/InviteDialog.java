package cn.legendream.wawa.view;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;

/**
 * @version V1.0 <>
 * @FileName: InviteDialog
 * @author: Samson.Sun
 * @date: 2017-12-21 9:51
 * @email: s_xin@neusoft.com
 */
public class InviteDialog extends Dialog {
    public InviteDialog(@NonNull Context context) {
        super(context);
    }

    public InviteDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    public interface OnSubmitClickListener {
        void onCodeChange(DialogInterface dialog, String code);
    }

    public static class Builder {
        private Context context;
        private OnSubmitClickListener onSubmitClickListener;
        private String code;


        public Builder(Context context) {
            this.context = context;
        }


        public Builder setCode(String code) {
            this.code = code;
            return this;
        }

        public Builder setOnSubmitClickListener(OnSubmitClickListener onSubmitClickListener) {
            this.onSubmitClickListener = onSubmitClickListener;
            return this;
        }

        public InviteDialog create() {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final InviteDialog dialog = new InviteDialog(context, R.style.Dialog);
            View layout = inflater.inflate(R.layout.dialog_invite, null);
            final EditText et_code_1 = layout.findViewById(R.id.et_code_1);
            final EditText et_code_2 = layout.findViewById(R.id.et_code_2);
            final EditText et_code_3 = layout.findViewById(R.id.et_code_3);
            final EditText et_code_4 = layout.findViewById(R.id.et_code_4);
            final EditText et_code_5 = layout.findViewById(R.id.et_code_5);
            final EditText et_code_6 = layout.findViewById(R.id.et_code_6);
            final EditText et_code_7 = layout.findViewById(R.id.et_code_7);
            EditText etCodes[] = {et_code_1, et_code_2, et_code_3, et_code_4, et_code_5, et_code_6, et_code_7};
            for (int i = 0; i < etCodes.length; i++) {
                etCodes[i].setInputType(InputType.TYPE_CLASS_NUMBER);
                etCodes[i].setTypeface(Utils.getCondensedBold(context));
                if (i != 6) {
                    editToEdit(etCodes[i], etCodes[i + 1]);
                }
            }
            Button negativeButton = layout.findViewById(R.id.negativeButton);
            if (!TextUtils.isEmpty(code) && code.length() == 7) {
                for (int i = 0; i < etCodes.length; i++) {
                    etCodes[i].setText(String.valueOf(code.toCharArray()[i]));
                }
            }
            negativeButton.setTypeface(Utils.getGoTrialFont(context));
            if (onSubmitClickListener != null) {
                negativeButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String code = getText(et_code_1)
                                + getText(et_code_2) + getText(et_code_3)
                                + getText(et_code_4) + getText(et_code_5)
                                + getText(et_code_6) + getText(et_code_7);
                        onSubmitClickListener.onCodeChange(dialog, code);
                    }
                });
            }
            dialog.setContentView(layout);
            return dialog;
        }

        private String getText(EditText editText) {
            return editText.getEditableText().toString();
        }

        private void editToEdit(EditText editText1, final EditText editText2) {
            editText1.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    if (charSequence.length() >= 1) {
                        editText2.requestFocus();
                    }
                }

                @Override
                public void afterTextChanged(Editable editable) {

                }
            });
        }
    }

}
