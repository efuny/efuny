package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.DeliverSubmitParam;
import cn.legendream.wawa.model.DollDeliverModel;
import cn.legendream.wawa.model.DollDeliverParam;
import cn.legendream.wawa.model.GetExpressPriceOrderModel;
import cn.legendream.wawa.model.GetExpressPriceOrderParam;
import cn.legendream.wawa.model.GetExpressPriceParam;
import cn.legendream.wawa.model.PayCreateOrderModel;
import cn.legendream.wawa.model.WxPayOrderModel;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.SendBabyActivity;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: SendBabyPresent
 * @author: Samson.Sun
 * @date: 2017-12-13 21:45
 * @email: s_xin@neusoft.com
 */
public class SendBabyPresent extends XPresent<SendBabyActivity> {
    public void userDollDeliver(DollDeliverParam dollDeliverParam) {
        Api.getSimpleService().userDollDeliver(NetUtil.createRequestBody(dollDeliverParam))
                .compose(XApi.<BaseModel<DollDeliverModel>>getApiTransformer())
                .compose(XApi.<BaseModel<DollDeliverModel>>getScheduler())
                .compose(getV().<BaseModel<DollDeliverModel>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<DollDeliverModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<DollDeliverModel> result) {
                        getV().hideProgress();
                        getV().showData(result);
                    }
                });
    }

    public void userDeliverSubmit(DeliverSubmitParam deliverSubmitParam) {
        Api.getSimpleService().userDeliverSubmit(NetUtil.createRequestBody(deliverSubmitParam))
                .compose(XApi.<BaseModel>getApiTransformer())
                .compose(XApi.<BaseModel>getScheduler())
                .compose(getV().<BaseModel>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel result) {
                        getV().hideProgress();
                        getV().deliverResult(result);
                    }
                });
    }

    public void getExpressPriceOrderId(GetExpressPriceParam getExpressPriceParam) {
        Api.getSimpleService().getExpressPriceOrder(NetUtil.createRequestBody(getExpressPriceParam))
                .compose(XApi.<BaseModel<GetExpressPriceOrderModel>>getApiTransformer())
                .compose(XApi.<BaseModel<GetExpressPriceOrderModel>>getScheduler())
                .compose(getV().<BaseModel<GetExpressPriceOrderModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<GetExpressPriceOrderModel>>() {
                    @Override
                    protected void onFail(NetError error) {

                    }

                    @Override
                    public void onNext(BaseModel<GetExpressPriceOrderModel> getExpressPriceOrderModelBaseModel) {
                        getV().hideProgress();
                        getV().getExpressPriceResult(getExpressPriceOrderModelBaseModel);
                    }
                });
    }

    public void getExpressWxPayCreateOrder(GetExpressPriceOrderParam getExpressPriceOrderParam) {

        Api.getSimpleService().wxPayCreateExpressPriceOrder(NetUtil.createRequestBody(getExpressPriceOrderParam))
                .compose(XApi.<BaseModel<WxPayOrderModel>>getApiTransformer())
                .compose(XApi.<BaseModel<WxPayOrderModel>>getScheduler())
                .compose(getV().<BaseModel<WxPayOrderModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                }).subscribe(new ApiSubscriber<BaseModel<WxPayOrderModel>>() {
            @Override
            protected void onFail(NetError error) {

            }

            @Override
            public void onNext(BaseModel<WxPayOrderModel> wxPayOrderModelBaseModel) {
                getV().hideProgress();
                getV().wechatOrder(wxPayOrderModelBaseModel);
            }
        });
    }

    public void getExpressAliPayCreateOrder(GetExpressPriceOrderParam getExpressPriceOrderParam) {

        Api.getSimpleService().aliPayCreateExpressPriceOrder(NetUtil.createRequestBody(getExpressPriceOrderParam))
                .compose(XApi.<BaseModel<PayCreateOrderModel>>getApiTransformer())
                .compose(XApi.<BaseModel<PayCreateOrderModel>>getScheduler())
                .compose(getV().<BaseModel<PayCreateOrderModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                }).subscribe(new ApiSubscriber<BaseModel<PayCreateOrderModel>>() {
            @Override
            protected void onFail(NetError error) {

            }

            @Override
            public void onNext(BaseModel<PayCreateOrderModel> payCreateOrderModelBaseModel) {
                getV().hideProgress();
                getV().aliPayOrder(payCreateOrderModelBaseModel);
            }
        });
    }
}
