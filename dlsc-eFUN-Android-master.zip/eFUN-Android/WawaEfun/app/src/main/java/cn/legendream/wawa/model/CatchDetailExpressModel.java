package cn.legendream.wawa.model;

/**
 * Created by zhaoyuefeng on 2019/5/17.
 * Description 
 */
public class CatchDetailExpressModel {


    /**
     * number : 21928772203726
     * company : 圆通
     * record : 快件已到达大连甘井子中转站
     * address : 辽宁省大连市高新园区创业e港999号
     * contacts : 收件人
     * phone : 13999999990
     */

    private String number;
    private String company;
    private String record;
    private String address;
    private String contacts;
    private String phone;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getRecord() {
        return record;
    }

    public void setRecord(String record) {
        this.record = record;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContacts() {
        return contacts;
    }

    public void setContacts(String contacts) {
        this.contacts = contacts;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
