package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: MachineListParam
 * @author: Samson.Sun
 * @date: 2017-12-11 10:26
 * @email: s_xin@neusoft.com
 */
public class MachineListParam {
    public MachineListParam() {
    }

    private String categoryId;
    private String userId;

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
