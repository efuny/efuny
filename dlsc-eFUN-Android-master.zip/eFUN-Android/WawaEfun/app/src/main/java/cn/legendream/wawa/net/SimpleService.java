package cn.legendream.wawa.net;

import java.util.List;

import cn.legendream.wawa.model.AboutModel;
import cn.legendream.wawa.model.BannerModel;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.BillModel;
import cn.legendream.wawa.model.CatchDetailExpressModel;
import cn.legendream.wawa.model.CatchDetailModel;
import cn.legendream.wawa.model.CatchMemberModel;
import cn.legendream.wawa.model.CategoryModel;
import cn.legendream.wawa.model.ConactInfoModel;
import cn.legendream.wawa.model.ConsumptionModel;
import cn.legendream.wawa.model.DollDeliverModel;
import cn.legendream.wawa.model.ExchangeLogModel;
import cn.legendream.wawa.model.FeedbackTypeModel;
import cn.legendream.wawa.model.GameBeginModel;
import cn.legendream.wawa.model.GetExchangeOrderModel;
import cn.legendream.wawa.model.GetExpressPriceOrderModel;
import cn.legendream.wawa.model.GoodsModel;
import cn.legendream.wawa.model.InvitationCodeModel;
import cn.legendream.wawa.model.MachineInfoModel;
import cn.legendream.wawa.model.MachineModel;
import cn.legendream.wawa.model.MachineStatusModel;
import cn.legendream.wawa.model.MallExchangeModel;
import cn.legendream.wawa.model.MallHomeModel;
import cn.legendream.wawa.model.MallInfoModel;
import cn.legendream.wawa.model.MessageModel;
import cn.legendream.wawa.model.OnLineModel;
import cn.legendream.wawa.model.OrderExchangeInfoModel;
import cn.legendream.wawa.model.OrderInfoModel;
import cn.legendream.wawa.model.OrderStatusModel;
import cn.legendream.wawa.model.PayCreateOrderModel;
import cn.legendream.wawa.model.PayModel;
import cn.legendream.wawa.model.RechargeModel;
import cn.legendream.wawa.model.RecordModel;
import cn.legendream.wawa.model.RewardModel;
import cn.legendream.wawa.model.ScoreModel;
import cn.legendream.wawa.model.ShareInfoModel;
import cn.legendream.wawa.model.SignScoreModel;
import cn.legendream.wawa.model.SystemStartPageInfoModel;
import cn.legendream.wawa.model.SystemUpdateModel;
import cn.legendream.wawa.model.UserAddressModel;
import cn.legendream.wawa.model.UserInfoModel;
import cn.legendream.wawa.model.UserMessageInfoModel;
import cn.legendream.wawa.model.UserOrderModel;
import cn.legendream.wawa.model.UserSignModel;
import cn.legendream.wawa.model.WxPayOrderModel;
import io.reactivex.Flowable;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * @version V1.0 <>
 * @FileName: SimpleService
 * @author: Samson.Sun
 * @date: 2017-12-5 21:23
 * @email: s_xin@neusoft.com
 */
public interface SimpleService {
    @POST("systemUpdate")
    Flowable<BaseModel<SystemUpdateModel>> getSystemUpdate();

    @POST("getMachineCategoryList")
    Flowable<BaseModel<List<CategoryModel>>> getMachineCategoryList();

    @POST("getMachineList")
    Flowable<BaseModel<List<MachineModel>>> getMachineList(@Body RequestBody body);

    @POST("getMachineInfo")
    Flowable<BaseModel<MachineInfoModel>> getMachineInfo(@Body RequestBody body);

    @POST("gameOnlineList")
    Flowable<BaseModel<OnLineModel>> gameOnlineList(@Body RequestBody body);

    @POST("machineLogout")
    Flowable<BaseModel> machineLogout(@Body RequestBody body);

    @POST("machineLogin")
    Flowable<BaseModel> machineLogin(@Body RequestBody body);

    @POST("getMachineStatus")
    Flowable<BaseModel<MachineStatusModel>> getMachineStatus(@Body RequestBody body);

    @POST("getMachineOrderList")
    Flowable<BaseModel<List<CatchMemberModel>>> getMachineOrderList(@Body RequestBody body);

    @POST("getUserPointRecord")
    Flowable<BaseModel<ScoreModel>> getUserPointRecord(@Body RequestBody body);

    @POST("userGrabRecordList")
    Flowable<BaseModel<RecordModel>> userGrabRecordList(@Body RequestBody body);

    @POST("getContactInfo")
    Flowable<BaseModel<ConactInfoModel>> getContactInfo();

    @POST("getUserInvitationCode")
    Flowable<BaseModel<InvitationCodeModel>> getUserInvitationCode(@Body RequestBody body);

    @POST("submitUserCode")
    Flowable<BaseModel> submitUserCode(@Body RequestBody body);

    @POST("getAbout")
    Flowable<BaseModel<AboutModel>> getAbout();

    @POST("getUserAddressList")
    Flowable<BaseModel<UserAddressModel>> getUserAddressList(@Body RequestBody body);

    @POST("getRechargeList")
    Flowable<BaseModel<RechargeModel>> getRechargeList(@Body RequestBody body);

    @POST("userEstablishAddress")
    Flowable<BaseModel> userEstablishAddress(@Body RequestBody body);

    @POST("userDeleteAddress")
    Flowable<BaseModel> userDeleteAddress(@Body RequestBody body);

    @POST("setUserAddressDefault")
    Flowable<BaseModel> setUserAddressDefault(@Body RequestBody body);

    @POST("getFeedbackType")
    Flowable<BaseModel<FeedbackTypeModel>> getFeedbackType();

    @POST("submitFeedback")
    Flowable<BaseModel> submitFeedback(@Body RequestBody body);

    @POST("userDollDeliver")
    Flowable<BaseModel<DollDeliverModel>> userDollDeliver(@Body RequestBody body);

    @POST("getUserRechargeOrderList")
    Flowable<BaseModel<List<BillModel>>> getUserRechargeOrderList(@Body RequestBody body);

    @POST("getUserConsumptionList")
    Flowable<BaseModel<List<ConsumptionModel>>> getUserConsumptionList(@Body RequestBody body);

    @POST("getUserInfo")
    Flowable<BaseModel<UserInfoModel>> getUserInfo(@Body RequestBody body);

    @POST("userLogout")
    Flowable<BaseModel> userLogout(@Body RequestBody body);

    @POST("getUserMessageList")
    Flowable<BaseModel<List<MessageModel>>> getUserMessageList(@Body RequestBody body);

    @POST("userGameStart")
    Flowable<BaseModel<GameBeginModel>> userGameStart(@Body RequestBody body);

    @POST("getOrderStatus")
    Flowable<BaseModel<OrderStatusModel>> getOrderStatus(@Body RequestBody body);

    @POST("getBannerList")
    Flowable<BaseModel<List<BannerModel>>> getBannerList(@Body RequestBody body);

    @POST("userCreateRechargeOrder")
    Flowable<BaseModel<PayModel>> userCreateRechargeOrder(@Body RequestBody body);

    @POST("userDeliverSubmit")
    Flowable<BaseModel> userDeliverSubmit(@Body RequestBody body);

    @POST("userOrderChangeScore")
    Flowable<BaseModel<UserOrderModel>> userOrderChangeScore(@Body RequestBody body);

    @POST("aliPayCreateOrder")
    Flowable<BaseModel<PayCreateOrderModel>> aliPayCreateOrder(@Body RequestBody body);

    @POST("wxPayCreateOrder")
    Flowable<BaseModel<WxPayOrderModel>> wxPayCreateOrder(@Body RequestBody body);

    @POST("setUserPushToken")
    Flowable<BaseModel> setUserPushToken(@Body RequestBody body);

    @POST("getShareInfo")
    Flowable<BaseModel<ShareInfoModel>> getShareInfo(@Body RequestBody body);

    @POST("userGrabRecordInfo")
    Flowable<BaseModel<CatchDetailModel>> userGrabRecordInfo(@Body RequestBody body);

    @POST("userSignView")
    Flowable<BaseModel<UserSignModel>> userSignView(@Body RequestBody body);

    @POST("userSignIn")
    Flowable<BaseModel<SignScoreModel>> userSignIn(@Body RequestBody body);

    @POST("orderExchangeInfo")
    Flowable<BaseModel<OrderExchangeInfoModel>> orderExchangeInfo(@Body RequestBody body);

    @POST("userOrderChangeGameIntegral")
    Flowable<BaseModel<UserOrderModel>> userOrderChangeGameIntegral(@Body RequestBody body);

    @POST("logisticsNumber")
    Flowable<BaseModel<CatchDetailExpressModel>> catchDetailExpress(@Body RequestBody body);

    @POST("systemStartPageInfo")
    Flowable<BaseModel<SystemStartPageInfoModel>> systemStartPageInfo();

    @POST("getUserMessageInfo")
    Flowable<BaseModel<UserMessageInfoModel>> getUserMessageInfo(@Body RequestBody body);

    @POST("mall_home")
    Flowable<BaseModel<MallHomeModel>> getMallHome(@Body RequestBody body);

    @POST("mall_info")
    Flowable<BaseModel<MallInfoModel>> getMallInfo(@Body RequestBody body);

    @POST("mall_exchange_log")
    Flowable<BaseModel<List<ExchangeLogModel>>> exchangeLog(@Body RequestBody body);

    @POST("mall_order_info")
    Flowable<BaseModel<OrderInfoModel>> orderInfo(@Body RequestBody body);

    @POST("mall_exchange")
    Flowable<BaseModel<MallExchangeModel>> mallExchange(@Body RequestBody body);

    @POST("mall_good_list")
    Flowable<BaseModel<List<GoodsModel>>> getMallGoodList(@Body RequestBody body);

    @POST("order_callback")
    Flowable<BaseModel> postGameResult(@Body RequestBody body);

    @POST("aliPayCreateExpressPriceOrder")
    Flowable<BaseModel<PayCreateOrderModel>> aliPayCreateExpressPriceOrder(@Body RequestBody body);

    @POST("wxPayCreateExpressPriceOrder")
    Flowable<BaseModel<WxPayOrderModel>> wxPayCreateExpressPriceOrder(@Body RequestBody body);

    @POST("userCreatePayExpressPriceOrder")
    Flowable<BaseModel<GetExpressPriceOrderModel>> getExpressPriceOrder(@Body RequestBody body);

    @POST("mall_good_pay")
    Flowable<BaseModel<GetExchangeOrderModel>> getExchangeOrder(@Body RequestBody body);

    @POST("aliMallPayCreatePriceOrder")
    Flowable<BaseModel<PayCreateOrderModel>> aliPayCreateExchangeOrder(@Body RequestBody body);

    @POST("wxMallPayCreatePriceOrder")
    Flowable<BaseModel<WxPayOrderModel>> wxPayCreateExchangeOrder(@Body RequestBody body);

    @POST("rechargeTopList")
    Flowable<BaseModel<RewardModel>> rewardListInfo(@Body RequestBody body);

}
