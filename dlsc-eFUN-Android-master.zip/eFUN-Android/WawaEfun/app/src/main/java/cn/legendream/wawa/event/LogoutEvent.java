package cn.legendream.wawa.event;

import cn.droidlover.xdroidmvp.event.IBus;

/**
 * @version V1.0 <>
 * @FileName: LogoutEvent
 * @author: Samson.Sun
 * @date: 2018-1-23 22:35
 * @email: s_xin@neusoft.com
 */
public class LogoutEvent implements IBus.IEvent {
    @Override
    public int getTag() {
        return 0;
    }
}
