package cn.legendream.wawa.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.router.Router;
import cn.droidlover.xdroidmvp.view.refreshlayout.SmartRefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.MaterialHeader;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.RefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.enumvo.SpinnerStyle;
import cn.droidlover.xdroidmvp.view.refreshlayout.footer.BallPulseFooter;
import cn.droidlover.xdroidmvp.view.refreshlayout.listener.OnRefreshLoadmoreListener;
import cn.droidlover.xrecyclerview.RecyclerItemCallback;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.adapter.ExchangeAdapter;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.ExchangeLogModel;
import cn.legendream.wawa.present.ExchangePresent;
import cn.legendream.wawa.present.PageParam;

import static android.support.v7.widget.DividerItemDecoration.VERTICAL;

/**
 * 兑换记录
 *
 * @version V1.0 <>
 * @FileName: ExchangeActivity
 * @author: Samson.Sun
 * @date: 2018-7-18 23:26
 * @email: s_xin@neusoft.com
 */
public class ExchangeActivity extends XActivity<ExchangePresent> {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.rv_list)
    XRecyclerView rv_list;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    private ExchangeAdapter mAdapter;
    private List<ExchangeLogModel> exchangeLogModelList;
    private int page = 1;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar)
                .statusBarDarkFont(true, 0.2f).init();
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_exchange;
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        initAdapter();
        //设置 Header 为 Material风格
        refreshLayout.setRefreshHeader(new MaterialHeader(context).setShowBezierWave(false));
        //设置 Footer 为 球脉冲
        refreshLayout.setRefreshFooter(new BallPulseFooter(context).setSpinnerStyle(SpinnerStyle.Scale));
        refreshLayout.autoRefresh();//第一次进入触发自动刷新，演示效果
        final PageParam pageParam = new PageParam();
        pageParam.setUserId(AppContext.getAccount().getUserId());
        pageParam.setPage(page + "");
        refreshLayout.setOnRefreshLoadmoreListener(new OnRefreshLoadmoreListener() {
            @Override
            public void onLoadmore(RefreshLayout refreshlayout) {
                page++;
                pageParam.setPage(page + "");
                getP().exchangeLog(false, pageParam);
            }

            @Override
            public void onRefresh(RefreshLayout refreshlayout) {
                page = 1;
                pageParam.setPage(page + "");
                getP().exchangeLog(true, pageParam);
            }
        });
    }

    @Override
    public ExchangePresent newP() {
        return new ExchangePresent();
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    private void initAdapter() {
        exchangeLogModelList = new ArrayList<>();
        mAdapter = new ExchangeAdapter(context);
        mAdapter.setRecItemClick(new RecyclerItemCallback<ExchangeLogModel, ExchangeAdapter.ViewHolder>() {
            @Override
            public void onItemClick(int position, ExchangeLogModel model, int tag, ExchangeAdapter.ViewHolder holder) {
                if (TextUtils.isEmpty(model.getOrderType())) {
                    toast("订单状态异常");
                    return;
                }
                if (TextUtils.isEmpty(model.getOrderId())) {
                    toast("订单id异常");
                    return;
                }
                //1实体订单 2虚拟商品订单
                if (model.getOrderType().equals("1")) {
                    OrderActivity.launch(context, model.getOrderId());
                } else if (model.getOrderType().equals("2")) {
                    VirtualDetailActivity.launch(context, model.getOrderId(), model.getGoodName());
                }
            }
        });
        rv_list.setItemAnimator(new DefaultItemAnimator());
        rv_list.setLayoutManager(new LinearLayoutManager(context));
        rv_list.addItemDecoration(new DividerItemDecoration(context, VERTICAL));
        rv_list.setAdapter(mAdapter);
    }

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(ExchangeActivity.class)
                .launch();
    }

    public void showError(NetError error) {
        super.showError(error);
        refreshLayout.finishRefresh();
        refreshLayout.finishLoadmore();
    }

    public void showData(boolean isRefresh, BaseModel<List<ExchangeLogModel>> result) {
        if (isRefresh) {
            refreshLayout.finishRefresh();
            refreshLayout.resetNoMoreData();
        } else {
            refreshLayout.finishLoadmore();
        }
        if (page > 1) {
            mAdapter.addData(result.getData());
        } else {
            mAdapter.setData(result.getData());
        }
    }

}
