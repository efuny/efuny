package cn.legendream.wawa.net;

import com.google.gson.Gson;

import cn.droidlover.xdroidmvp.kit.Kits;
import cn.legendream.wawa.kit.AES128;

import cn.droidlover.xdroidmvp.log.XLog;
import cn.legendream.wawa.model.PostModel;
import okhttp3.RequestBody;

/**
 * @version V1.0 <>
 * @FileName: NetUtil
 * @author: Samson.Sun
 * @date: 2017-12-6 10:54
 * @email: s_xin@neusoft.com
 */
public class NetUtil {
    private static final String MULTIPART_FORM_DATA = "application/json";

    public static RequestBody createRequestBody(Object obj) {
        Gson gson = new Gson();
        XLog.json(gson.toJson(obj).trim().toString());
        String enString = AES128.getInstance().encrypt(gson.toJson(obj).trim().toString());
        PostModel postModel = new PostModel(enString.trim().toString());
        XLog.json(gson.toJson(postModel));
        String result = AES128.getInstance().decode2(gson.toJson(postModel));
        return RequestBody.create(okhttp3.MediaType.parse(MULTIPART_FORM_DATA),result);
    }

    public static RequestBody createRequestBody(String obj) {
        String enString = AES128.getInstance().encrypt(obj);
        XLog.xml(enString);
        return RequestBody.create(okhttp3.MediaType.parse(MULTIPART_FORM_DATA),enString);
    }
}
