package cn.legendream.wawa.present;

import java.util.List;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.ConsumptionModel;
import cn.legendream.wawa.model.ConsumptionParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.ConsumptionActivity;

/**
 * @version V1.0 <>
 * @FileName: ConsumptionPresent
 * @author: Samson.Sun
 * @date: 2018-3-28 11:14
 * @email: s_xin@neusoft.com
 */
public class ConsumptionPresent extends XPresent<ConsumptionActivity> {

    public void getUserConsumptionList(final boolean isRefresh, ConsumptionParam consumptionParam) {
        Api.getSimpleService().getUserConsumptionList(NetUtil.createRequestBody(consumptionParam))
                .compose(XApi.<BaseModel<List<ConsumptionModel>>>getApiTransformer())
                .compose(XApi.<BaseModel<List<ConsumptionModel>>>getScheduler())
                .compose(getV().<BaseModel<List<ConsumptionModel>>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<List<ConsumptionModel>>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<List<ConsumptionModel>> result) {
                        getV().showData(isRefresh, result);
                    }
                });
    }
}
