package cn.legendream.wawa.ui.fragment;

import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.mvp.XLazyFragment;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.view.refreshlayout.SmartRefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.MaterialHeader;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.RefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.listener.OnRefreshListener;
import cn.droidlover.xrecyclerview.RecyclerItemCallback;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.adapter.HomeAdapter;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.MachineListParam;
import cn.legendream.wawa.model.MachineModel;
import cn.legendream.wawa.present.HomePresent;
import cn.legendream.wawa.ui.GameActivity;
import cn.legendream.wawa.ui.gamev2.GameV2Activity;
import io.reactivex.Observable;
import io.reactivex.Observer;

/**
 * @version V1.0 <>
 * @FileName: HomeFragment
 * @author: Samson.Sun
 * @date: 2017-12-9 19:46
 * @email: s_xin@neusoft.com
 */
public class HomeFragment extends XLazyFragment<HomePresent> {
    @BindView(R.id.contentLayout)
    XRecyclerView contentLayout;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    private List<MachineModel> machineModelList;
    private HomeAdapter homeAdapter;
    private String categoryId;

    public static HomeFragment newInstance(String categoryId) {
        Bundle bundle = new Bundle();
        bundle.putString("categoryId", categoryId);
        HomeFragment fragment = new HomeFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        categoryId = getArguments().getString("categoryId");
        machineModelList = new ArrayList<>();
        homeAdapter = new HomeAdapter(context);
        homeAdapter.setRecItemClick(new RecyclerItemCallback<MachineModel, HomeAdapter.ViewHolder>() {
            @Override
            public void onItemClick(int position, MachineModel model, int tag, HomeAdapter.ViewHolder holder) {
                if (!Utils.isFastClick()) {

                    if (model.getIsNew().equals("1")) {
                        //new machine
                        GameV2Activity.launch(context, model.getMachineId());
                    } else {
                        //old machine
                        GameActivity.launch(context, model.getMachineId());
                    }

                }
            }
        });
        initAdapter();
        //设置 Header 为 Material风格
        refreshLayout.setRefreshHeader(new MaterialHeader(context).setShowBezierWave(false));
//        refreshLayout.autoRefresh();//第一次进入触发自动刷新，演示效果
        final MachineListParam machineListParam = new MachineListParam();
        machineListParam.setCategoryId(categoryId);
        machineListParam.setUserId(AppContext.getAccount().getUserId());
//        getP().getMachineList(machineListParam);

        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(RefreshLayout refreshlayout) {
                getP().getMachineList(machineListParam);
            }
        });
    }

    @Override
    protected void onStartLazy() {
        super.onStartLazy();
        refreshLayout.autoRefresh();//第一次进入触发自动刷新，演示效果
        final MachineListParam machineListParam = new MachineListParam();
        machineListParam.setCategoryId(categoryId);
        machineListParam.setUserId(AppContext.getAccount().getUserId());
        getP().getMachineList(machineListParam);
    }

    private void initAdapter() {
        contentLayout.noDivider();
        contentLayout.setItemAnimator(new DefaultItemAnimator());
        contentLayout.gridLayoutManager(context, 2);
        contentLayout.setAdapter(homeAdapter);
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_home;
    }

    @Override
    public HomePresent newP() {
        return new HomePresent();
    }

    public void showError(NetError error) {
        super.showError(error);
        refreshLayout.finishRefresh();
    }

    public void showData(BaseModel<List<MachineModel>> machineResult) {
        refreshLayout.finishRefresh();
        List<MachineModel> machineModels = machineResult.getData();
        homeAdapter.setData(machineModels);
    }
}
