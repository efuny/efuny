package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.FeedbackParam;
import cn.legendream.wawa.model.FeedbackTypeModel;
import cn.legendream.wawa.model.RecordParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.FeedbackActivity;
import cn.legendream.wawa.ui.MineActivity;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: FeedbackPresent
 * @author: Samson.Sun
 * @date: 2017-12-8 19:53
 * @email: s_xin@neusoft.com
 */
public class FeedbackPresent extends XPresent<FeedbackActivity> {
    public void getFeedbackType() {
        Api.getSimpleService().getFeedbackType()
                .compose(XApi.<BaseModel<FeedbackTypeModel>>getApiTransformer())
                .compose(XApi.<BaseModel<FeedbackTypeModel>>getScheduler())
                .compose(getV().<BaseModel<FeedbackTypeModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<FeedbackTypeModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<FeedbackTypeModel> result) {
                        getV().hideProgress();
                        getV().showData(result);
                    }
                });
    }

    public void submitFeedback(FeedbackParam feedbackParam) {
        Api.getSimpleService().submitFeedback(NetUtil.createRequestBody(feedbackParam))
                .compose(XApi.<BaseModel>getApiTransformer())
                .compose(XApi.<BaseModel>getScheduler())
                .compose(getV().<BaseModel>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel result) {
                        getV().hideProgress();
                        getV().feedbackResult(result);
                    }
                });
    }
}
