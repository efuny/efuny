package cn.legendream.wawa.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xdroidmvp.kit.KnifeKit;
import cn.legendream.wawa.R;
import cn.legendream.wawa.model.AddressModel;

/**
 * @version V1.0 <>
 * @FileName: ChoiceAddressAdapter
 * @author: Samson.Sun
 * @date: 2017-12-21 14:28
 * @email: s_xin@neusoft.com
 */
public class ChoiceAddressAdapter extends SimpleRecAdapter<AddressModel, ChoiceAddressAdapter.ViewHolder> {
    private OnEditClickListener onEditClickListener;
    private OnLongClickListener onLongClickListener;

    public ChoiceAddressAdapter(Context context) {
        super(context);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final AddressModel addressModel = data.get(position);
        holder.tv_user_name.setText(addressModel.getPerson());
        holder.tv_phone_no.setText(addressModel.getMobile());
        holder.tv_address.setText(addressModel.getAddress());
        holder.cbAddress.setChecked(addressModel.isCheck());
        holder.layout_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onEditClickListener != null) {
                    onEditClickListener.editClick(addressModel, position);
                }
            }
        });
        if (!addressModel.getIsDefault().equals("0")) {
            holder.tv_address_tag.setVisibility(View.VISIBLE);
        } else {
            holder.tv_address_tag.setVisibility(View.GONE);
        }

        holder.item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getRecItemClick() != null) {
                    getRecItemClick().onItemClick(position, addressModel, 0, holder);
                }
            }
        });
        holder.item.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (onLongClickListener != null) {
                    onLongClickListener.onLongClick(position, addressModel);
                }
                return false;
            }
        });
    }

    @Override
    public ViewHolder newViewHolder(View itemView) {
        return new ViewHolder(itemView);
    }

    @Override
    public int getLayoutId() {
        return R.layout.item_choice_address;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.cbAddress)
        CheckBox cbAddress;
        @BindView(R.id.tv_user_name)
        TextView tv_user_name;
        @BindView(R.id.tv_phone_no)
        TextView tv_phone_no;
        @BindView(R.id.tv_address_tag)
        TextView tv_address_tag;
        @BindView(R.id.tv_address)
        TextView tv_address;
        @BindView(R.id.layout_edit)
        View layout_edit;
        @BindView(R.id.item)
        View item;

        public ViewHolder(View itemView) {
            super(itemView);
            KnifeKit.bind(this, itemView);
        }
    }

    public interface OnEditClickListener {
        void editClick(AddressModel model, int position);
    }

    public interface OnLongClickListener {
        void onLongClick(int position, AddressModel model);
    }


    public void setOnEditClickListener(OnEditClickListener onEditClickListener) {
        this.onEditClickListener = onEditClickListener;
    }

    public void setOnLongClickListener(OnLongClickListener onLongClickListener) {
        this.onLongClickListener = onLongClickListener;
    }
}
