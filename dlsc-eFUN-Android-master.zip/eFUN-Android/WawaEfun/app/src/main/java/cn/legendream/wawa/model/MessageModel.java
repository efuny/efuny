package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: MessageModel
 * @author: Samson.Sun
 * @date: 2017-12-14 14:25
 * @email: s_xin@neusoft.com
 */
public class MessageModel {
    public MessageModel() {
    }

    private String content;
    private String messageType;
    private String messageUrl;
    private String dateTime;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getMessageUrl() {
        return messageUrl;
    }

    public void setMessageUrl(String messageUrl) {
        this.messageUrl = messageUrl;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }
}
