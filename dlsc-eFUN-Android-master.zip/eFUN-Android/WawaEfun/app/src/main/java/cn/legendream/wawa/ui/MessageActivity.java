package cn.legendream.wawa.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.event.BusProvider;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.router.Router;
import cn.droidlover.xdroidmvp.view.refreshlayout.SmartRefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.MaterialHeader;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.RefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.enumvo.SpinnerStyle;
import cn.droidlover.xdroidmvp.view.refreshlayout.footer.BallPulseFooter;
import cn.droidlover.xdroidmvp.view.refreshlayout.listener.OnRefreshLoadmoreListener;
import cn.droidlover.xrecyclerview.RecyclerItemCallback;
import cn.droidlover.xrecyclerview.XRecyclerContentLayout;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.adapter.MessageAdapter;
import cn.legendream.wawa.event.RefreshCatchEvent;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.BillModel;
import cn.legendream.wawa.model.MessageModel;
import cn.legendream.wawa.model.MessageParam;
import cn.legendream.wawa.present.MessagePresent;

import static android.support.v7.widget.DividerItemDecoration.VERTICAL;

/**
 * @version V1.0 <>
 * @FileName: MessageActivity
 * @author: Samson.Sun
 * @date: 2017-12-8 20:32
 * @email: s_xin@neusoft.com
 */
public class MessageActivity extends XActivity<MessagePresent> {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.rv_list)
    XRecyclerView rv_list;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    private MessageAdapter mAdapter;
    private List<MessageModel> messageModelList;
    private int page = 1;
    private boolean isFirst = true;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar)
                .statusBarDarkFont(true, 0.2f).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        initAdapter();
        //设置 Header 为 Material风格
        refreshLayout.setRefreshHeader(new MaterialHeader(context).setShowBezierWave(false));
        //设置 Footer 为 球脉冲
        refreshLayout.setRefreshFooter(new BallPulseFooter(context).setSpinnerStyle(SpinnerStyle.Scale));
        refreshLayout.autoRefresh();//第一次进入触发自动刷新，演示效果
        final MessageParam messageParam = new MessageParam();
        messageParam.setUserId(AppContext.getAccount().getUserId());
        messageParam.setPage(page+"");
        getP().getUserMessageList(true, messageParam);
        refreshLayout.setOnRefreshLoadmoreListener(new OnRefreshLoadmoreListener() {
            @Override
            public void onLoadmore(RefreshLayout refreshlayout) {
                page++;
                messageParam.setPage(page + "");
                getP().getUserMessageList(false, messageParam);
            }

            @Override
            public void onRefresh(RefreshLayout refreshlayout) {
                page = 1;
                messageParam.setPage(page + "");
                getP().getUserMessageList(true, messageParam);
            }
        });
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_message;
    }

    @Override
    public MessagePresent newP() {
        return new MessagePresent();
    }

    private void initAdapter() {
        messageModelList = new ArrayList<>();
        mAdapter = new MessageAdapter(context);
        rv_list.setItemAnimator(new DefaultItemAnimator());
        rv_list.setLayoutManager(new LinearLayoutManager(context));
        rv_list.addItemDecoration(new DividerItemDecoration(context, VERTICAL));
        rv_list.setAdapter(mAdapter);
        mAdapter.setRecItemClick(new RecyclerItemCallback<MessageModel, MessageAdapter.ViewHolder>() {
            @Override
            public void onItemClick(int position, MessageModel model, int tag, MessageAdapter.ViewHolder holder) {
                if (!Utils.isFastClick()) {
                    if (model.getMessageType().equals("1") && !TextUtils.isEmpty(model.getMessageUrl())) {
                        WebActivity.launch(context, model.getMessageUrl(), getString(R.string.message));
                    }
                }
            }
        });
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(MessageActivity.class)
                .launch();
    }

    public void showError(NetError error) {
        super.showError(error);
        refreshLayout.finishRefresh();
        refreshLayout.finishLoadmore();
    }

    public void showData(boolean isRefresh, BaseModel<List<MessageModel>> result) {
        if (isFirst){
            isFirst = false;
            BusProvider.getBus().post(new RefreshCatchEvent());
        }
        if (isRefresh) {
            refreshLayout.finishRefresh();
            refreshLayout.resetNoMoreData();
        } else {
            refreshLayout.finishLoadmore();
        }
        if (page > 1) {
            mAdapter.addData(result.getData());
        } else {
            mAdapter.setData(result.getData());
        }
    }
}
