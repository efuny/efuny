package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: PayParam
 * @author: Samson.Sun
 * @date: 2018-1-9 9:07
 * @email: s_xin@neusoft.com
 */
public class PayParam {
    public PayParam() {
    }

    private String userId;
    private String payType;
    private String packageId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getPackageId() {
        return packageId;
    }

    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }
}
