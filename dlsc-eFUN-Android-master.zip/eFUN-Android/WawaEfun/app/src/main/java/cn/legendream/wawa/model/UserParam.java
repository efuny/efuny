package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: UserParam
 * @author: Samson.Sun
 * @date: 2017-12-21 11:53
 * @email: s_xin@neusoft.com
 */
public class UserParam {
    public UserParam() {
    }

    public UserParam(String userId) {
        this.userId = userId;
    }

    private String userId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "UserParam{" +
                "userId='" + userId + '\'' +
                '}';
    }
}
