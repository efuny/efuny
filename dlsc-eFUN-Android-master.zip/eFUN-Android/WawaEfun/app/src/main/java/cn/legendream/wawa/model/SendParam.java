package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: SendParam
 * @author: Samson.Sun
 * @date: 2017-12-21 22:59
 * @email: s_xin@neusoft.com
 */
public class SendParam {
    public SendParam() {
    }
}
