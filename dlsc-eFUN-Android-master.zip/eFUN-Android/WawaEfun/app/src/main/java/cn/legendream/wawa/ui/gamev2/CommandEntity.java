package cn.legendream.wawa.ui.gamev2;

/**
 * Created by zhaoyuefeng on 2018/8/29.
 * Description
 */

public class CommandEntity {


    /**
     * command : start
     * time_out : 60
     * catch_result : 1
     * power_catch : 0
     * power_ontop : 0
     * power_move : 0
     * power_max : 0
     * hold_height : 0
     */

    private int command;
    private int time_out;
    private int catch_result;
    private int power_catch;
    private int power_ontop;
    private int power_move;
    private int power_max;
    private int hold_height;
    private String macStr;

    public CommandEntity() {
    }

    public CommandEntity(int command) {
        this.command = command;
    }

    public CommandEntity(int command, String macStr) {
        this.command = command;
        this.macStr = macStr;
    }

    public CommandEntity(int command, int time_out, int catch_result, int power_catch, int power_ontop, int power_move, int power_max, int hold_height) {
        this.command = command;
        this.time_out = time_out;
        this.catch_result = catch_result;
        this.power_catch = power_catch;
        this.power_ontop = power_ontop;
        this.power_move = power_move;
        this.power_max = power_max;
        this.hold_height = hold_height;
    }

    public int getCommand() {
        return command;
    }

    public void setCommand(int command) {
        this.command = command;
    }

    public int getTime_out() {
        return time_out;
    }

    public void setTime_out(int time_out) {
        this.time_out = time_out;
    }

    public int getCatch_result() {
        return catch_result;
    }

    public void setCatch_result(int catch_result) {
        this.catch_result = catch_result;
    }

    public int getPower_catch() {
        return power_catch;
    }

    public void setPower_catch(int power_catch) {
        this.power_catch = power_catch;
    }

    public int getPower_ontop() {
        return power_ontop;
    }

    public void setPower_ontop(int power_ontop) {
        this.power_ontop = power_ontop;
    }

    public int getPower_move() {
        return power_move;
    }

    public void setPower_move(int power_move) {
        this.power_move = power_move;
    }

    public int getPower_max() {
        return power_max;
    }

    public void setPower_max(int power_max) {
        this.power_max = power_max;
    }

    public int getHold_height() {
        return hold_height;
    }

    public void setHold_height(int hold_height) {
        this.hold_height = hold_height;
    }

    public String getMacStr() {
        return macStr;
    }

    public void setMacStr(String macStr) {
        this.macStr = macStr;
    }
}
