package cn.legendream.wawa.ui;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.tencent.android.tpush.XGIOperateCallback;
import com.tencent.android.tpush.XGPushConfig;
import com.tencent.android.tpush.XGPushManager;
import com.tencent.android.tpush.common.Constants;
import com.tencent.bugly.crashreport.CrashReport;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.listener.OnBannerListener;
import com.youth.banner.loader.ImageLoader;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.base.XFragmentAdapter;
import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.event.BusProvider;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.log.XLog;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.droidlover.xdroidmvp.view.immersionbar.ImmersionBar;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.event.LogoutEvent;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BannerModel;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.CategoryData;
import cn.legendream.wawa.model.CategoryModel;
import cn.legendream.wawa.model.PushTokenParam;
import cn.legendream.wawa.model.SignParam;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.model.UserSignModel;
import cn.legendream.wawa.present.MainPresent;
import cn.legendream.wawa.receiver.NetWorkStateChangeReceiver;
import cn.legendream.wawa.ui.fragment.HomeFragment;
import cn.legendream.wawa.view.SignDialog;
import io.reactivex.functions.Consumer;

public class MainActivity extends XActivity<MainPresent> implements AppBarLayout.OnOffsetChangedListener {
    @BindView(R.id.app_bar)
    AppBarLayout app_bar;
    @BindView(R.id.viewPager)
    ViewPager viewPager;
    @BindView(R.id.tabLayout)
    TabLayout tabLayout;
    @BindView(R.id.vBgTab)
    View vBgTab;
    @BindView(R.id.iv_user)
    ImageView iv_user;
    @BindView(R.id.refreshLayout)
    View refreshLayout;
    @BindView(R.id.banner)
    Banner banner;

    private int maxMarginTop = 0;
    private int EXPEND_MARGIN_TOP = 0;//展开后margin
    List<Fragment> fragmentList = new ArrayList<>();
    private List<BannerModel> bannerModels;

    XFragmentAdapter adapter;

    private static NetWorkStateChangeReceiver netWorkStateChangeReceiver;

    static {

        netWorkStateChangeReceiver = new NetWorkStateChangeReceiver();

    }

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(MainActivity.class)
                .launch();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");

        registerReceiver(netWorkStateChangeReceiver, intentFilter);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(netWorkStateChangeReceiver);
    }

//    @Override
//    protected void initImmersionBar() {
//        super.initImmersionBar();
//        mImmersionBar
//                .statusBarColor(R.color.transparent)
//                .fullScreen(true)
//                .init();
//    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        fragmentList.clear();
        CategoryData categoryData = SharedPref.getInstance(context).get(Keys.CATEGORY, CategoryData.class);
        if (categoryData.getData() == null) {
            return;
        }
        List<CategoryModel> machineResult = categoryData.getData();
        if (machineResult == null) {
            return;
        }
//        List<Integer> images = new ArrayList<>();
//        for (int i = 0; i < 3; i++) {
//            images.add(R.drawable.ic_home_ad);
//        }
        //设置图片加载器
        banner.setImageLoader(new GlideImageLoader());
        banner.setIndicatorGravity(BannerConfig.CENTER);
        banner.isAutoPlay(true);
        banner.setDelayTime(5000);
        //banner设置方法全部调用完毕时最后调用
        banner.start();
        banner.setOnBannerListener(new OnBannerListener() {
            @Override
            public void OnBannerClick(int position) {
                if (Kits.Empty.check(bannerModels)) {
                    return;
                }
                if (!Utils.isFastClick()) {
                    BannerModel bannerModel = bannerModels.get(position);
                    WebActivity.launch(context, bannerModel.getUrl(), bannerModel.getBannerTitle());
                }
            }
        });
        String[] titles = new String[machineResult.size()];
        for (int i = 0; i < machineResult.size(); i++) {
            HomeFragment homeFragment = HomeFragment.newInstance(machineResult.get(i).getCategoryId());
            titles[i] = machineResult.get(i).getCategoryName();
            fragmentList.add(homeFragment);
        }
        if (adapter == null) {
            adapter = new XFragmentAdapter(getSupportFragmentManager(), fragmentList, titles);
        }

        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(machineResult.size());
        tabLayout.setupWithViewPager(viewPager);
        for (int i = 0; i < titles.length; i++) {
            tabLayout.getTabAt(i).setCustomView(getTabText(i, titles));
            if (i == 0) {
                TextView tabViewDefault = tabLayout.getTabAt(0).getCustomView().findViewById(R.id.tv_tab_name);
                tabViewDefault.setTextColor(context.getResources().getColor(R.color.pink_84));
            }
        }
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                final TextView textView = tab.getCustomView().findViewById(R.id.tv_tab_name);
                textView.setTextColor(context.getResources().getColor(R.color.pink_84));
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                final TextView textView = tab.getCustomView().findViewById(R.id.tv_tab_name);
                textView.setTextColor(context.getResources().getColor(R.color.pink_c0));
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        EXPEND_MARGIN_TOP = Kits.Dimens.dpToPxInt(context, 10);
        ViewGroup.MarginLayoutParams marginParams = getMarginLayoutParams(refreshLayout);
        maxMarginTop = marginParams.topMargin;
        viewPager.setCurrentItem(0);
        app_bar.addOnOffsetChangedListener(this);
        registerPush();
        UserParam userParam = new UserParam();
        userParam.setUserId(AppContext.getAccount().getUserId());
        getP().getBannerList(userParam);
        //获取积分商店
//        getP().getDuiBaLoginUrl(new UserParam(AppContext.getAccount().getUserId()));
        //获取签到详情
        getP().userSignView(new SignParam(AppContext.getAccount().getUserId(), "0"));
        BusProvider.getBus().toFlowable(LogoutEvent.class)
                .subscribe(new Consumer<LogoutEvent>() {
                    @Override
                    public void accept(LogoutEvent logoutEvent) throws Exception {
                        finish();
                    }
                });

    }

    public View getTabText(int position, String[] titles) {
        View v = LayoutInflater.from(this).inflate(R.layout.tab_item, null);
        TextView tv = v.findViewById(R.id.tv_tab_name);
        tv.setText(titles[position]);
        tv.setTypeface(Utils.getGoTrialFont(context));
        return v;
    }

    private void registerPush() {
        //TODO 打包关掉
        XGPushConfig.enableDebug(this, false);
        XGPushManager.registerPush(getApplicationContext(),
                new XGIOperateCallback() {
                    @Override
                    public void onSuccess(Object data, int flag) {
                        XLog.d(Constants.LogTag,
                                "+++ register push sucess. token:" + data);
                        PushTokenParam pushTokenParam = new PushTokenParam();
                        pushTokenParam.setPushToken(data.toString());
                        pushTokenParam.setUserId(AppContext.getAccount().getUserId());
                        getP().setUserPushToken(pushTokenParam);
                    }

                    @Override
                    public void onFail(Object data, int errCode, String msg) {
                        XLog.d(Constants.LogTag,
                                "+++ register push fail. token:" + data
                                        + ", errCode:" + errCode + ",msg:"
                                        + msg);
                    }
                });
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_main;
    }

    @Override
    public MainPresent newP() {
        return new MainPresent();
    }

    @OnClick(R.id.layout_user)
    void toUser() {
        if (!Utils.isFastClick()) {
            MineActivity.launch(context);
        }
    }

    @Override
    public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
        int maxHeight = tabLayout.getHeight() - app_bar.getHeight();
        if (verticalOffset == 0) {
//            setMargin(maxMarginTop);
            vBgTab.setAlpha(0);
        } else if (verticalOffset == maxHeight) {
//            setMargin(EXPEND_MARGIN_TOP);
            vBgTab.setAlpha(1);
        } else {
//            setMargin(maxMarginTop * (maxHeight - verticalOffset) / maxHeight + EXPEND_MARGIN_TOP * verticalOffset / maxHeight);
            vBgTab.setAlpha(0);
        }
        float alpha = -1.0f * verticalOffset / app_bar.getHeight();
        if (-verticalOffset == app_bar.getHeight()) {
//            mImmersionBar.statusBarColor(R.color.white).init();
            vBgTab.setAlpha(1f);
//            if (ImmersionBar.isSupportStatusBarDarkFont())
//                mImmersionBar.statusBarDarkFont(true).init();
        } else {
            if (alpha > 0.98) {
//                mImmersionBar.statusBarColor(R.color.transparent_e0).init();
                vBgTab.setAlpha(0.98f);
            } else if (alpha > 0.96) {
//                mImmersionBar.statusBarColor(R.color.transparent_98).init();
                vBgTab.setAlpha(0.76f);
            } else if (alpha > 0.94) {
//                mImmersionBar.statusBarColor(R.color.transparent_76).init();
                vBgTab.setAlpha(0.54f);
            } else if (alpha > 0.92) {
//                mImmersionBar.statusBarColor(R.color.transparent_54).init();
                vBgTab.setAlpha(0.32f);
            } else if (alpha > 0.9) {
//                mImmersionBar.statusBarColor(R.color.transparent_32).init();
                vBgTab.setAlpha(0.1f);
            } else {
//                mImmersionBar.statusBarColor(R.color.transparent).init();
                vBgTab.setAlpha(0f);
            }
//            if (ImmersionBar.isSupportStatusBarDarkFont())
//                mImmersionBar.statusBarDarkFont(false).init();
        }
    }

    private void setMargin(int px) {
        ViewGroup.MarginLayoutParams marginParams = getMarginLayoutParams(refreshLayout);
        marginParams.setMargins(0, px, 0, 0);
        refreshLayout.setLayoutParams(marginParams);
    }

    public class GlideImageLoader extends ImageLoader {
        @Override
        public void displayImage(Context context, Object path, ImageView imageView) {
//            imageView.setImageResource((Integer) path);
            ILFactory.getLoader().loadNet(imageView, (String) path, null);
        }
    }

    public void showBanner(BaseModel<List<BannerModel>> resultModel) {
        if (resultModel == null || Kits.Empty.check(resultModel.getData())) {
            return;
        }
        List<String> images = new ArrayList<>();
        bannerModels = new ArrayList<>();
        bannerModels.addAll(resultModel.getData());
        for (int i = 0; i < resultModel.getData().size(); i++) {
            images.add(resultModel.getData().get(i).getImagesUrl());
        }
        //设置图片集合
        banner.update(images);
    }

    public void showScoreShopUrl(String url) {
        SharedPref.getInstance(context).put(Keys.SCORE_SHOP_URL, url);
    }

    public void showSignDialog(UserSignModel userSignModel) {
        if (userSignModel.getSignList().size() != 7 || userSignModel.getDaySignStauts().equals("1")) {
            return;
        }
        final SignDialog signDialog = new SignDialog
                .Builder(context)
                .setUserSign(userSignModel)
                .setOnSubmitClickListener(new SignDialog.OnSubmitClickListener() {
                    @Override
                    public void onOnSubmit(DialogInterface dialog, String money) {
                        getP().userSignIn(new UserParam(AppContext.getAccount().getUserId()));
                    }
                }).create();
        signDialog.show();
    }

    public void signSuccess(String score, String money) {
//        final MaterialDialog materialDialog = new MaterialDialog(context);
//        materialDialog.setTitle(R.string.tips)
//                .setMessage(Utils.formatStrings(context, R.string.sign_success, money, score))
//                .setCanceledOnTouchOutside(true)
//                .setPositiveButton(R.string.confirm, new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        materialDialog.dismiss();
//                    }
//                });
//        materialDialog.show();
        toastMessage(getString(R.string.sign_success), Utils.formatStrings(context, R.string.sign_gain_score, money, score));
    }

}
