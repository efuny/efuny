package cn.legendream.wawa.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.router.Router;
import cn.droidlover.xdroidmvp.view.refreshlayout.SmartRefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.MaterialHeader;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.RefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.listener.OnRefreshListener;
import cn.droidlover.xrecyclerview.RecyclerItemCallback;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.adapter.ChoiceAddressAdapter;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.AddressModel;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.DeleteAddressParam;
import cn.legendream.wawa.model.UserAddressModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.present.ChoiceAddressPresent;
import me.drakeet.materialdialog.MaterialDialog;

import static android.support.v7.widget.DividerItemDecoration.VERTICAL;

/**
 * @version V1.0 <>
 * @FileName: ChoiceAddressActivity
 * @author: Samson.Sun
 * @date: 2017-12-21 14:57
 * @email: s_xin@neusoft.com
 */
public class ChoiceAddressActivity extends XActivity<ChoiceAddressPresent> {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.tv_create_address)
    TextView tv_create_address;
    @BindView(R.id.rv_list)
    XRecyclerView rv_list;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    private ChoiceAddressAdapter mAdapter;
    List<AddressModel> addressModelList;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar)
                .statusBarDarkFont(true, 0.2f).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        initAdapter();
        refreshLayout.setRefreshHeader(new MaterialHeader(context).setShowBezierWave(false));
        refreshLayout.autoRefresh();
        doQuery();
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(RefreshLayout refreshlayout) {
                doQuery();
            }
        });
    }

    private void doQuery() {
        final UserParam userParam = new UserParam();
        userParam.setUserId(AppContext.getAccount().getUserId());
        getP().getUserAddressList(userParam);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_choice_address;
    }

    @Override
    public ChoiceAddressPresent newP() {
        return new ChoiceAddressPresent();
    }

    private void initAdapter() {
        addressModelList = new ArrayList<>();
        mAdapter = new ChoiceAddressAdapter(context);
        mAdapter.setRecItemClick(new RecyclerItemCallback<AddressModel, ChoiceAddressAdapter.ViewHolder>() {
            @Override
            public void onItemClick(int position, AddressModel model, int tag, ChoiceAddressAdapter.ViewHolder holder) {
                super.onItemClick(position, model, tag, holder);
                for (int i = 0; i < addressModelList.size(); i++) {
                    if (i == position) {
                        addressModelList.get(position).setCheck(true);
                    } else {
                        addressModelList.get(position).setCheck(false);
                    }
                }
                mAdapter.notifyDataSetChanged();
                Bundle bundle = new Bundle();
                bundle.putSerializable(Keys.CHOICE_ADDRESS_RESULT, model);
                setResult(RESULT_OK, new Intent().putExtras(bundle));
                finish();
            }
        });
        mAdapter.setOnEditClickListener(new ChoiceAddressAdapter.OnEditClickListener() {
            @Override
            public void editClick(AddressModel model, int position) {
                AddAddressActivity.launch(context, true, model);
            }
        });
        mAdapter.setOnLongClickListener(new ChoiceAddressAdapter.OnLongClickListener() {
            @Override
            public void onLongClick(int position, final AddressModel model) {
                /*new MaterialDialog.Builder(context)
                        .content(R.string.is_delete)
                        .positiveText(R.string.confirm)
                        .negativeText(R.string.cancel)
                        .onPositive(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                DeleteAddressParam deleteAddressParam = new DeleteAddressParam();
                                deleteAddressParam.setUserId(AppContext.getAccount().getUserId());
                                deleteAddressParam.setAddressId(model.getAddressId());
                                getP().userDeleteAddress(deleteAddressParam);
                            }
                        })
                        .onNegative(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {

                            }
                        })
                        .show();*/
                final MaterialDialog materialDialog = new MaterialDialog(context);
                materialDialog
                        .setMessage(R.string.is_delete)
                        .setCanceledOnTouchOutside(true)
                        .setPositiveButton(R.string.confirm, new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                materialDialog.dismiss();
                                DeleteAddressParam deleteAddressParam = new DeleteAddressParam();
                                deleteAddressParam.setUserId(AppContext.getAccount().getUserId());
                                deleteAddressParam.setAddressId(model.getAddressId());
                                getP().userDeleteAddress(deleteAddressParam);
                            }
                        });
                materialDialog.setNegativeButton(R.string.cancel, new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        materialDialog.dismiss();
                    }
                });
                materialDialog.show();
            }
        });

        rv_list.setItemAnimator(new DefaultItemAnimator());
        rv_list.setLayoutManager(new LinearLayoutManager(context));
        rv_list.addItemDecoration(new DividerItemDecoration(context, VERTICAL));
        rv_list.setAdapter(mAdapter);
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    @OnClick(R.id.tv_create_address)
    void createAddress() {
        AddAddressActivity.launch(context, false, new AddressModel());
    }

    public void showError(NetError error) {
        super.showError(error);
        refreshLayout.finishRefresh();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case Keys.ADD_ADDRESS:
                    boolean isCreate = data.getBooleanExtra(Keys.ADD_ADDRESS_RESULT, false);
                    if (isCreate) {
                        refreshLayout.autoRefresh();
                        doQuery();
                    }
                    break;
            }
        }
    }

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(ChoiceAddressActivity.class)
                .requestCode(Keys.CHOICE_ADDRESS)
                .launch();
    }

    public void showData(BaseModel<UserAddressModel> result) {
        refreshLayout.finishRefresh();
        addressModelList.clear();
        addressModelList = result.getData().getAddressList();
        mAdapter.setData(addressModelList);

    }

    public void deleteResult(BaseModel result) {
        if (result.getResult().equals("1")) {
            toast(R.string.delete_success);
            doQuery();
        } else {
            toast(R.string.delete_failed);
        }
    }
}
