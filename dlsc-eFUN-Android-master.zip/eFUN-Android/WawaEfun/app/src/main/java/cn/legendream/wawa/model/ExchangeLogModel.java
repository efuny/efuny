package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: ExchangeLogModel
 * @author: Samson.Sun
 * @date: 2018-7-18 23:32
 * @email: s_xin@neusoft.com
 */
public class ExchangeLogModel {
    public ExchangeLogModel() {
    }

    private String goodImageUrl;
    private String goodName;
    private String price;
    private String integral;
    private String orderStatus;
    private String orderId;
    private String orderStatusText;
    private String orderType;

    public String getGoodImageUrl() {
        return goodImageUrl;
    }

    public void setGoodImageUrl(String goodImageUrl) {
        this.goodImageUrl = goodImageUrl;
    }

    public String getGoodName() {
        return goodName;
    }

    public void setGoodName(String goodName) {
        this.goodName = goodName;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderStatusText() {
        return orderStatusText;
    }

    public void setOrderStatusText(String orderStatusText) {
        this.orderStatusText = orderStatusText;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }
}
