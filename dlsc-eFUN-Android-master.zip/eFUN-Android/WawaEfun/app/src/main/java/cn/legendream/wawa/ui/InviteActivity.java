package cn.legendream.wawa.ui;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.shareboard.SnsPlatform;
import com.umeng.socialize.utils.ShareBoardlistener;

import java.lang.ref.WeakReference;
import java.util.List;

import butterknife.BindView;
import butterknife.BindViews;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.log.XLog;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.droidlover.xdroidmvp.view.refreshlayout.util.DensityUtil;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.ImageUtils;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.InvitationCodeModel;
import cn.legendream.wawa.model.InviteParam;
import cn.legendream.wawa.model.ShareInfoModel;
import cn.legendream.wawa.model.ShareInfoParam;
import cn.legendream.wawa.model.SubmitCodeParam;
import cn.legendream.wawa.present.InvitePresent;
import cn.legendream.wawa.view.InviteDialog;

/**
 * 邀请码
 *
 * @version V1.0 <>
 * @FileName: InviteActivity
 * @author: Samson.Sun
 * @date: 2017-12-8 20:38
 * @email: s_xin@neusoft.com
 */
public class InviteActivity extends XActivity<InvitePresent> {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.toolbar_title)
    TextView toolbar_title;
    @BindView(R.id.tv_20_money)
    TextView tv_20_money;
    @BindViews({R.id.tv_code_1, R.id.tv_code_2, R.id.tv_code_3, R.id.tv_code_4, R.id.tv_code_5, R.id.tv_code_6, R.id.tv_code_7})
    List<TextView> tvCodes;
    @BindView(R.id.layout_copy)
    View layout_copy;
    @BindView(R.id.btn_share)
    Button btn_share;
    private String shareUrl = "";
    private String codeFull = "";
    private String codePoint = "";
    private String[] code;
    private UMShareListener mShareListener;
    private ShareAction mShareAction;
    private InviteDialog inviteDialog;
    private String infoText = "";
    private String userCode = "";
    private String codeUrl = "";
    private Bitmap qrcodeBitmap;
    private final int fontSize = 12;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        InviteParam inviteParam = new InviteParam();
        inviteParam.setUserId(AppContext.getAccount().getUserId());
        getP().getUserInvitationCode(inviteParam);
        getP().getShareInfo(new ShareInfoParam(AppContext.getAccount().getUserId()));
        layout_copy.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                toast(R.string.code_copy);
                Utils.copy(context, codeFull);
                return false;
            }
        });
        toolbar_title.setTypeface(Utils.getGoTrialFont(context));
        toolbar_title.getPaint().setFakeBoldText(true);
        btn_share.setTypeface(Utils.getGoTrialFont(context));
        for (int i = 0; i < tvCodes.size(); i++) {
            tvCodes.get(i).setTypeface(Utils.getCondensedBold(context));
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_invite;
    }

    @Override
    public InvitePresent newP() {
        return new InvitePresent();
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    @Override
    protected void onDestroy() {
        qrcodeBitmap = null;
        super.onDestroy();
    }

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(InviteActivity.class)
                .launch();
    }

    public void showCode(BaseModel<InvitationCodeModel> result) {
        shareUrl = result.getData().getShareUrl();
        codePoint = result.getData().getCodePoint();
        codeFull = result.getData().getCode();
        code = new String[codeFull.length()];
        tv_20_money.setText(Utils.formatStrings(context, R.string.get_20_money, codePoint));
        for (int i = 0; i < codeFull.length(); i++) {
            code[i] = String.valueOf(codeFull.toCharArray()[i]);
            tvCodes.get(i).setText(code[i]);
        }
    }

    @OnClick(R.id.btn_share)
    void shareUrl() {
        if (TextUtils.isEmpty(infoText)) {
            toast(R.string.share_creating);
            return;
        }
        if (TextUtils.isEmpty(userCode)) {
            toast(R.string.share_creating);
            return;
        }
        final Bitmap bitmap = paintQrCode(createShareImg());
        mShareListener = new CustomShareListener(this);
        /*增加自定义按钮的分享面板*/
        mShareAction = new ShareAction(context).setDisplayList(
                SHARE_MEDIA.WEIXIN, SHARE_MEDIA.WEIXIN_CIRCLE, SHARE_MEDIA.WEIXIN_FAVORITE,
                SHARE_MEDIA.SINA, SHARE_MEDIA.QQ, SHARE_MEDIA.QZONE)
                .setShareboardclickCallback(new ShareBoardlistener() {
                    @Override
                    public void onclick(SnsPlatform snsPlatform, SHARE_MEDIA share_media) {
//                        UMWeb web = new UMWeb(shareUrl);
//                        web.setTitle(Utils.formatStrings(context, R.string.share_title, codePoint));
//                        web.setDescription(Utils.formatStrings(context, R.string.share_content, codeFull));
//                        web.setThumb(new UMImage(context, R.drawable.ic_share_img));
//                        new ShareAction(context).withMedia(web)
//                                .setPlatform(share_media)
//                                .setCallback(mShareListener)
//                                .share();
                        UMImage umImage = new UMImage(context, bitmap);
                        umImage.setTitle(Utils.formatStrings(context, R.string.share_title, codePoint));
                        umImage.setDescription(Utils.formatStrings(context, R.string.share_content, codeFull));
                        umImage.compressFormat = Bitmap.CompressFormat.PNG;
                        new ShareAction(context).withMedia(umImage)
                                .setPlatform(share_media)
                                .setCallback(mShareListener)
                                .share();
                    }
                });
        mShareAction.open();
    }

    @OnClick(R.id.layout_input_code)
    void inputCode() {
        String inputCode = Utils.paste(context);
        if (Kits.Empty.check(inputCode) || inputCode.length() != 7 || !Utils.isNumeric(inputCode)) {
            inputCode = "";
        }
        inviteDialog = new InviteDialog
                .Builder(context)
                .setCode(inputCode)
                .setOnSubmitClickListener(new InviteDialog.OnSubmitClickListener() {
                    @Override
                    public void onCodeChange(DialogInterface dialog, String code) {
                        hideSoftKeyBoard();
                        if (Kits.Empty.check(code)) {
                            toast(R.string.please_input_code);
                            return;
                        }
                        SubmitCodeParam submitCodeParam = new SubmitCodeParam();
                        submitCodeParam.setUserId(AppContext.getAccount().getUserId());
                        submitCodeParam.setCode(code);
                        getP().submitUserCode(submitCodeParam);
                    }
                }).create();
        inviteDialog.show();
    }

    public void inputCodeResult(BaseModel result) {
        if (result.getResult().equals("1")) {
            toast(R.string.input_code_success);
            if (inviteDialog != null) {
                inviteDialog.dismiss();
            }
        } else {
            toast(result.getMsg());
        }
    }

    private static class CustomShareListener implements UMShareListener {

        private WeakReference<InviteActivity> mActivity;

        private CustomShareListener(InviteActivity activity) {
            mActivity = new WeakReference(activity);
        }

        @Override
        public void onStart(SHARE_MEDIA platform) {

        }

        @Override
        public void onResult(SHARE_MEDIA platform) {
            if (platform.name().equals("WEIXIN_FAVORITE")) {
                Toast.makeText(mActivity.get(), platform + " 收藏成功啦", Toast.LENGTH_SHORT).show();
            } else {
                if (platform != SHARE_MEDIA.MORE && platform != SHARE_MEDIA.SMS
                        && platform != SHARE_MEDIA.EMAIL
                        && platform != SHARE_MEDIA.FLICKR
                        && platform != SHARE_MEDIA.FOURSQUARE
                        && platform != SHARE_MEDIA.TUMBLR
                        && platform != SHARE_MEDIA.POCKET
                        && platform != SHARE_MEDIA.PINTEREST

                        && platform != SHARE_MEDIA.INSTAGRAM
                        && platform != SHARE_MEDIA.GOOGLEPLUS
                        && platform != SHARE_MEDIA.YNOTE
                        && platform != SHARE_MEDIA.EVERNOTE) {
                    Toast.makeText(mActivity.get(), " 分享成功啦", Toast.LENGTH_SHORT).show();
                }
            }
        }

        @Override
        public void onError(SHARE_MEDIA platform, Throwable throwable) {
            if (platform != SHARE_MEDIA.MORE && platform != SHARE_MEDIA.SMS
                    && platform != SHARE_MEDIA.EMAIL
                    && platform != SHARE_MEDIA.FLICKR
                    && platform != SHARE_MEDIA.FOURSQUARE
                    && platform != SHARE_MEDIA.TUMBLR
                    && platform != SHARE_MEDIA.POCKET
                    && platform != SHARE_MEDIA.PINTEREST

                    && platform != SHARE_MEDIA.INSTAGRAM
                    && platform != SHARE_MEDIA.GOOGLEPLUS
                    && platform != SHARE_MEDIA.YNOTE
                    && platform != SHARE_MEDIA.EVERNOTE) {
                Toast.makeText(mActivity.get(), " 分享失败啦", Toast.LENGTH_SHORT).show();
                if (throwable != null) {
                    XLog.d("throw", "throw:" + throwable.getMessage());
                }
            }
        }

        @Override
        public void onCancel(SHARE_MEDIA platform) {
            Toast.makeText(mActivity.get(), " 分享取消了", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        /** attention to this below ,must add this**/
        UMShareAPI.get(this).onActivityResult(requestCode, resultCode, data);
    }

    public void showShareInfo(BaseModel<ShareInfoModel> result) {
        infoText = result.getData().getInfoText();
        userCode = result.getData().getUserCode();
        codeUrl = result.getData().getCodeUrl();
        Glide.with(context).load(codeUrl).asBitmap().into(new SimpleTarget<Bitmap>() {
            @Override
            public void onResourceReady(Bitmap resource, GlideAnimation<? super Bitmap> glideAnimation) {
                qrcodeBitmap = resource;
            }
        });
    }

    private Bitmap createShareImg() {
        Bitmap bitmap = drawText();
        return bitmap;
    }

    private Bitmap drawText() {
        //分享语
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_share_bg);
        double withMix = 0.11;
        double heightMix = 0.11;
        int height = bitmap.getHeight();
        int width = bitmap.getWidth();
//        int leftWidth = (int) (width * withMix);
//        int num = (width - leftWidth * 2) / DensityUtil.dp2px(9);
//        for (int i = 0; i <= infoText.length() / num; i++) {
//            int n;
//            if (num > infoText.length() - i * num) {
//                n = infoText.length();
//            } else {
//                n = num;
//            }
//            bitmap = ImageUtils.drawText(context, bitmap, infoText, fontSize, R.color.black, i * num, n, leftWidth, (int) (height * heightMix) + i * DensityUtil.dp2px(fontSize + 3), false);
//        }
        bitmap = ImageUtils.drawShareTxt(bitmap, infoText, fontSize - 2, withMix, heightMix);
        //分享码
        double codeFontMix = 0.43;
        double codeFontHeightMix = 0.248;
        bitmap = ImageUtils.drawText(context, bitmap, getResources().getString(R.string.share_code), fontSize, Color.WHITE, 0, 3, (int) (width * codeFontMix), (int) (height * codeFontHeightMix), false);
        //邀请码
        double codeMix = 0.29;
        Paint sFont = new Paint();
        Rect rect = new Rect();
        sFont.setTextSize(DensityUtil.dp2px(fontSize + 4));
        sFont.getTextBounds(userCode, 0, userCode.length(), rect);
        int fontHeight = rect.width();
        bitmap = ImageUtils.drawText(context, bitmap, userCode, fontSize + 4, R.color.black, 0, userCode.length(), width / 2 - fontHeight / 2, (int) (height * codeMix), true);
        return bitmap;
    }

    private Bitmap paintQrCode(final Bitmap bitmap) {
        if (qrcodeBitmap == null) {
            return bitmap;
        }
        double x = 0.39;
        double y = 0.8;
        return ImageUtils.createWaterMaskBitmap(bitmap, qrcodeBitmap, (int) (x * bitmap.getWidth()), (int) (y * bitmap.getHeight()));
    }
}
