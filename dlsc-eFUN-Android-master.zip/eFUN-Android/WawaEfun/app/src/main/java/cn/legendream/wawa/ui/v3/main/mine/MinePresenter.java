package cn.legendream.wawa.ui.v3.main.mine;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.AboutModel;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.ConactInfoModel;
import cn.legendream.wawa.model.SubmitCodeParam;
import cn.legendream.wawa.model.UserInfoModel;
import cn.legendream.wawa.model.UserMessageInfoModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import io.reactivex.functions.Consumer;

/**
 * Created by zhaoyuefeng on 2019/4/29.
 * Description 
 */
public class MinePresenter extends XPresent<MineFragment> {

    public void getContactInfo() {
        Api.getSimpleService().getContactInfo()
                .compose(XApi.<BaseModel<ConactInfoModel>>getApiTransformer())
                .compose(XApi.<BaseModel<ConactInfoModel>>getScheduler())
                .compose(getV().<BaseModel<ConactInfoModel>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<ConactInfoModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<ConactInfoModel> result) {
                        getV().showConectInfo(result);
                    }
                });
    }

    public void getUserInfo(UserParam userParam) {
        Api.getSimpleService().getUserInfo(NetUtil.createRequestBody(userParam))
                .compose(XApi.<BaseModel<UserInfoModel>>getApiTransformer())
                .compose(XApi.<BaseModel<UserInfoModel>>getScheduler())
                .compose(getV().<BaseModel<UserInfoModel>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<UserInfoModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<UserInfoModel> result) {
                        getV().setUserInfo(result);
                    }
                });
    }

    public void submitUserCode(SubmitCodeParam submitCodeParam) {
        Api.getSimpleService().submitUserCode(NetUtil.createRequestBody(submitCodeParam))
                .compose(XApi.<BaseModel>getApiTransformer())
                .compose(XApi.<BaseModel>getScheduler())
                .compose(getV().<BaseModel>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel result) {
                        getV().hideProgress();
                        getV().inputCodeResult(result);
                    }
                });
    }

    public void getUserMessageInfo(UserParam userParam) {
        Api.getSimpleService().getUserMessageInfo(NetUtil.createRequestBody(userParam))
                .compose(XApi.<BaseModel<UserMessageInfoModel>>getApiTransformer())
                .compose(XApi.<BaseModel<UserMessageInfoModel>>getScheduler())
                .compose(getV().<BaseModel<UserMessageInfoModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress(false);
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<UserMessageInfoModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<UserMessageInfoModel> resultModel) {
                        getV().hideProgress();
                        getV().isShowNewMessage(resultModel);
                    }
                });
    }

}
