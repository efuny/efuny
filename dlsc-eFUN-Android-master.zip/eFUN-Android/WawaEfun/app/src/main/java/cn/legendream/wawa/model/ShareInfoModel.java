package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: ShareInfoModel
 * @author: Samson.Sun
 * @date: 2018-3-21 21:17
 * @email: s_xin@neusoft.com
 */
public class ShareInfoModel {
    public ShareInfoModel() {
    }

    public String infoText;
    public String userCode;
    public String codeUrl;

    public String getInfoText() {
        return infoText;
    }

    public void setInfoText(String infoText) {
        this.infoText = infoText;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getCodeUrl() {
        return codeUrl;
    }

    public void setCodeUrl(String codeUrl) {
        this.codeUrl = codeUrl;
    }
}
