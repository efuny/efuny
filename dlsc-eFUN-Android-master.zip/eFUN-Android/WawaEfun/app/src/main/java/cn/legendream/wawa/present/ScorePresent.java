package cn.legendream.wawa.present;

import java.util.List;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.MachineListParam;
import cn.legendream.wawa.model.MachineModel;
import cn.legendream.wawa.model.ScoreModel;
import cn.legendream.wawa.model.ScoreParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.MineActivity;
import cn.legendream.wawa.ui.ScoreActivity;
import cn.legendream.wawa.ui.fragment.BaseScoreFragment;

/**
 * @version V1.0 <>
 * @FileName: ScorePresent
 * @author: Samson.Sun
 * @date: 2017-12-8 19:55
 * @email: s_xin@neusoft.com
 */
public class ScorePresent extends XPresent<BaseScoreFragment> {
    public void getUserPointRecord(final boolean isRefresh, ScoreParam scoreParam) {
        Api.getSimpleService().getUserPointRecord(NetUtil.createRequestBody(scoreParam))
                .compose(XApi.<BaseModel<ScoreModel>>getApiTransformer())
                .compose(XApi.<BaseModel<ScoreModel>>getScheduler())
                .compose(getV().<BaseModel<ScoreModel>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<ScoreModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<ScoreModel> scoreResult) {
                        getV().showData(isRefresh, scoreResult.getData());
                    }
                });
    }

}
