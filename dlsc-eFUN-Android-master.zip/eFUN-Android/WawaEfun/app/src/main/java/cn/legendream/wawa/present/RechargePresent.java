package cn.legendream.wawa.present;

import java.util.List;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.BillModel;
import cn.legendream.wawa.model.UserRechargeOrderParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.RechargeActivity;

/**
 * @version V1.0 <>
 * @FileName: RechargePresent
 * @author: Samson.Sun
 * @date: 2017-12-8 20:35
 * @email: s_xin@neusoft.com
 */
public class RechargePresent extends XPresent<RechargeActivity> {
    public void getUserRechargeOrderList(final boolean isRefresh, UserRechargeOrderParam userRechargeOrderParam) {
        Api.getSimpleService().getUserRechargeOrderList(NetUtil.createRequestBody(userRechargeOrderParam))
                .compose(XApi.<BaseModel<List<BillModel>>>getApiTransformer())
                .compose(XApi.<BaseModel<List<BillModel>>>getScheduler())
                .compose(getV().<BaseModel<List<BillModel>>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<List<BillModel>>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<List<BillModel>> result) {
                        getV().showData(isRefresh, result);
                    }
                });
    }
}
