package cn.legendream.wawa.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.sdk.android.oss.ClientConfiguration;
import com.alibaba.sdk.android.oss.OSS;
import com.alibaba.sdk.android.oss.OSSClient;
import com.alibaba.sdk.android.oss.common.auth.OSSAuthCredentialsProvider;
import com.alibaba.sdk.android.oss.common.auth.OSSCredentialProvider;
import com.lzy.imagepicker.ImagePicker;
import com.lzy.imagepicker.bean.ImageItem;
import com.lzy.imagepicker.ui.ImageGridActivity;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.BuildConfig;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.OssService;
import cn.legendream.wawa.kit.PicassoImageLoader;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.FeedbackParam;
import cn.legendream.wawa.model.FeedbackTypeModel;
import cn.legendream.wawa.model.TypeModel;
import cn.legendream.wawa.present.FeedbackPresent;
import me.drakeet.materialdialog.MaterialDialog;

/**
 * 意见反馈
 *
 * @version V1.0 <>
 * @FileName: FeedbackActivity
 * @author: Samson.Sun
 * @date: 2017-12-8 19:52
 * @email: s_xin@neusoft.com
 */
public class FeedbackActivity extends XActivity<FeedbackPresent> {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.layout_add)
    View layout_add;
    @BindView(R.id.layout_img1)
    View layout_img1;
    @BindView(R.id.layout_img2)
    View layout_img2;
    @BindView(R.id.layout_img3)
    View layout_img3;
    @BindView(R.id.tv_img1)
    ImageView tv_img1;
    @BindView(R.id.tv_img2)
    ImageView tv_img2;
    @BindView(R.id.tv_img3)
    ImageView tv_img3;
    @BindView(R.id.tv_type)
    TextView tv_type;
    @BindView(R.id.et_content)
    EditText et_content;
    private List<String> imgList;
    private List<ImageItem> images;
    private ImagePicker imagePicker;
    private final int MAX_LENGTH = 3;
    private List<TypeModel> typeList;
    private List<String> typeNames;
    private TypeModel typeModel;
    private String endpoint = BuildConfig.endpoint;
    private String accessKeyId = BuildConfig.accessKeyId;
    private String accessKeySecret = BuildConfig.accessKeySecret;
    private String securityToken = BuildConfig.securityToken;

    private String stsServer = "http://test.efuny.net/sts/sts.php";
    private String editBucketName = "efun-oss";
    private OssService ossService;
    private int num = 0;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar)
                .statusBarDarkFont(true, 0.2f).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        imgList = new ArrayList<>();
        images = new ArrayList<>();
        typeList = new ArrayList<>();
        typeNames = new ArrayList<>();
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        int fullWidth = wm.getDefaultDisplay().getWidth() - Kits.Dimens.dpToPxInt(context, 30) - Kits.Dimens.dpToPxInt(context, 14);
        LinearLayout.LayoutParams linLayoutParams1 = (LinearLayout.LayoutParams) layout_img1.getLayoutParams();
        linLayoutParams1.width = fullWidth / 3;
        linLayoutParams1.height = fullWidth / 3;
        LinearLayout.LayoutParams linLayoutParams2 = (LinearLayout.LayoutParams) layout_img2.getLayoutParams();
        linLayoutParams2.width = fullWidth / 3;
        linLayoutParams2.height = fullWidth / 3;
        LinearLayout.LayoutParams linLayoutParams3 = (LinearLayout.LayoutParams) layout_img3.getLayoutParams();
        linLayoutParams3.width = fullWidth / 3;
        linLayoutParams3.height = fullWidth / 3;
        LinearLayout.LayoutParams linLayoutParams4 = (LinearLayout.LayoutParams) layout_add.getLayoutParams();
        linLayoutParams4.width = fullWidth / 3;
        linLayoutParams4.height = fullWidth / 3;

        updateImageView();
        imagePicker = ImagePicker.getInstance();
        imagePicker.setImageLoader(new PicassoImageLoader());
        getP().getFeedbackType();

        //OSS 初始化
        ossService = initOSS();
        ossService.setBucketName(editBucketName);
    }

    private OssService initOSS() {
//        OSSCredentialProvider credentialProvider = new OSSStsTokenCredentialProvider(accessKeyId, accessKeySecret, securityToken);
        OSSCredentialProvider credentialProvider = new OSSAuthCredentialsProvider(stsServer);
        ClientConfiguration conf = new ClientConfiguration();
        conf.setConnectionTimeout(15 * 1000); // 连接超时，默认15秒
        conf.setSocketTimeout(15 * 1000); // socket超时，默认15秒
        conf.setMaxConcurrentRequest(5); // 最大并发请求书，默认5个
        conf.setMaxErrorRetry(2); // 失败后最大重试次数，默认2次
        conf.setHttpDnsEnable(true);
        OSS oss = new OSSClient(getApplicationContext(), endpoint, credentialProvider, conf);
        return new OssService(oss, editBucketName);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_feedback;
    }

    @Override
    public FeedbackPresent newP() {
        return new FeedbackPresent();
    }

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(FeedbackActivity.class)
                .launch();
    }

    @OnClick(R.id.layout_choice_type)
    void selectType() {
        /*new MaterialDialog.Builder(this)
                .title(R.string.choice_type)
                .items(typeNames)
                .itemsCallback(new MaterialDialog.ListCallback() {
                    @Override
                    public void onSelection(MaterialDialog dialog, View view, int which, CharSequence text) {
                        tv_type.setText(text);
                        typeModel = typeList.get(which);
                    }
                })
                .show();
*/
        final ArrayAdapter<String> arrayAdapter
                = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1);
        arrayAdapter.addAll(typeNames);
        ListView listView = new ListView(this);
        listView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        float scale = getResources().getDisplayMetrics().density;
        int dpAsPixels = (int) (8 * scale + 0.5f);
        listView.setPadding(0, dpAsPixels, 0, dpAsPixels);
        listView.setDividerHeight(0);
        listView.setAdapter(arrayAdapter);
        final MaterialDialog alert = new MaterialDialog(this)
                .setTitle(R.string.choice_type)
                .setCanceledOnTouchOutside(true)
                .setContentView(listView);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                tv_type.setText(typeNames.get(i));
                typeModel = typeList.get(i);
                alert.dismiss();
            }
        });
        alert.show();
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    @OnClick(R.id.layout_add)
    void addImage() {
        imagePicker.setSelectLimit(MAX_LENGTH - images.size());    //选中数量限制
        Intent intent = new Intent(this, ImageGridActivity.class);
        startActivityForResult(intent, Keys.IMAGE_PICKER);
    }

    @OnClick(R.id.layout_delete1)
    void deleteImage1() {
        if (!Kits.Empty.check(images) && images.size() >= 1) {
            images.remove(0);
        }
        updateImageView();
    }

    @OnClick(R.id.layout_delete2)
    void deleteImage2() {
        if (!Kits.Empty.check(images) && images.size() >= 2) {
            images.remove(1);
        }
        updateImageView();
    }

    @OnClick(R.id.layout_delete3)
    void deleteImage3() {
        if (!Kits.Empty.check(images) && images.size() >= 3) {
            images.remove(2);
        }
        updateImageView();
    }

    private void updateImageView() {
        if (Kits.Empty.check(images)) {
            images.clear();
            layout_img1.setVisibility(View.GONE);
            layout_img2.setVisibility(View.GONE);
            layout_img3.setVisibility(View.GONE);
            layout_add.setVisibility(View.VISIBLE);
        } else {
            switch (images.size()) {
                case 1:
                    layout_img1.setVisibility(View.VISIBLE);
                    layout_img2.setVisibility(View.GONE);
                    layout_img3.setVisibility(View.GONE);
                    layout_add.setVisibility(View.VISIBLE);
                    ILFactory.getLoader().loadFile(tv_img1, new File(images.get(0).path), null);
                    break;
                case 2:
                    layout_img1.setVisibility(View.VISIBLE);
                    layout_img2.setVisibility(View.VISIBLE);
                    layout_img3.setVisibility(View.GONE);
                    layout_add.setVisibility(View.VISIBLE);
                    ILFactory.getLoader().loadFile(tv_img1, new File(images.get(0).path), null);
                    ILFactory.getLoader().loadFile(tv_img2, new File(images.get(1).path), null);
                    break;
                case 3:
                default:
                    layout_img1.setVisibility(View.VISIBLE);
                    layout_img2.setVisibility(View.VISIBLE);
                    layout_img3.setVisibility(View.VISIBLE);
                    layout_add.setVisibility(View.GONE);
                    ILFactory.getLoader().loadFile(tv_img1, new File(images.get(0).path), null);
                    ILFactory.getLoader().loadFile(tv_img2, new File(images.get(1).path), null);
                    ILFactory.getLoader().loadFile(tv_img3, new File(images.get(2).path), null);
                    break;
            }
        }
    }

    @OnClick(R.id.layout_submit)
    void submit() {
        if (typeModel == null) {
            toast(R.string.please_choice_type);
            return;
        }
        if (TextUtils.isEmpty(et_content.getEditableText().toString().trim())) {
            toast(R.string.please_input_content);
            return;
        }
        final FeedbackParam feedbackParam = new FeedbackParam();
        feedbackParam.setUserId(AppContext.getAccount().getUserId());
        feedbackParam.setContent(et_content.getEditableText().toString().trim());
        feedbackParam.setTypeId(typeModel.getTypeId());
        if (!Kits.Empty.check(images)) {
            num = 0;
            showProgress(false);
            ossService.asyncPutImage(images, new OssService.UploadListener() {
                @Override
                public void uploadSuccess(String imageUrl) {
                    num++;
                    imgList.add(imageUrl);
                    if (num == images.size()) {
                        feedbackParam.setImages(imgList);
                        getP().submitFeedback(feedbackParam);
                    }
                }

                @Override
                public void uploadFailed() {
                    num++;
                }
            });
        } else {
            showProgress(false);
            getP().submitFeedback(feedbackParam);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == ImagePicker.RESULT_CODE_ITEMS) {
            if (data != null && requestCode == Keys.IMAGE_PICKER) {
                images.addAll((ArrayList<ImageItem>) data.getSerializableExtra(ImagePicker.EXTRA_RESULT_ITEMS));
                updateImageView();
            } else {
                Toast.makeText(this, "没有数据", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void showData(BaseModel<FeedbackTypeModel> result) {
        typeList.clear();
        typeNames.clear();
        typeList = result.getData().getTypeList();
        for (int i = 0; i < typeList.size(); i++) {
            typeNames.add(typeList.get(i).getTypeName());
        }
    }

    public void feedbackResult(BaseModel result) {
        if (result.getResult().equals("1")) {
            toast(R.string.feedback_success);
            finish();
        } else {
            toast(result.getMsg());
        }
    }
}
