package cn.legendream.wawa.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.AppBarLayout;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alipay.sdk.app.PayTask;
import com.tencent.mm.opensdk.modelpay.PayReq;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;

import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.BuildConfig;
import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.event.BusProvider;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.alipay.PayResult;
import cn.legendream.wawa.event.AddressEvent;
import cn.legendream.wawa.event.PayEvent;
import cn.legendream.wawa.kit.AES128;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.Account;
import cn.legendream.wawa.model.AddressModel;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.GetExchangeOrderModel;
import cn.legendream.wawa.model.GetExchangeOrderParam;
import cn.legendream.wawa.model.GetExpressPriceOrderParam;
import cn.legendream.wawa.model.MallExchangeModel;
import cn.legendream.wawa.model.MallInfoModel;
import cn.legendream.wawa.model.MallInfoParam;
import cn.legendream.wawa.model.PayCreateOrderModel;
import cn.legendream.wawa.model.PayCreateOrderParam;
import cn.legendream.wawa.model.UserAddressInfoModel;
import cn.legendream.wawa.model.UserGoodParam;
import cn.legendream.wawa.model.WxPayOrderModel;
import cn.legendream.wawa.model.WxPayOrderParam;
import cn.legendream.wawa.present.GoodDetailPresent;
import cn.legendream.wawa.view.PayDialog;
import io.reactivex.functions.Consumer;
import me.drakeet.materialdialog.MaterialDialog;

/**
 * 实物详情
 *
 * @version V1.0 <>
 * @FileName: GoodDetailActivity
 * @author: Samson.Sun
 * @date: 2018-7-13 23:53
 * @email: s_xin@neusoft.com
 */
public class GoodDetailActivity extends XActivity<GoodDetailPresent> {
    @BindView(R.id.app_bar)
    AppBarLayout app_bar;
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.toolbar_title)
    TextView toolbar_title;
    @BindView(R.id.iv_detail_image)
    ImageView iv_detail_image;
    @BindView(R.id.tv_good_score)
    TextView tv_good_score;
    @BindView(R.id.tv_score)
    TextView tv_score;
    @BindView(R.id.tv_good_and)
    TextView tv_good_and;
    @BindView(R.id.tv_good_price)
    TextView tv_good_price;
    @BindView(R.id.tv_good_money)
    TextView tv_good_money;
    @BindView(R.id.tv_good_address)
    TextView tv_good_address;
    @BindView(R.id.tv_good_ems_price)
    TextView tv_good_ems_price;
    @BindView(R.id.tv_detail_name)
    TextView tv_detail_name;
    @BindView(R.id.iv_exchange)
    ImageView iv_exchange;
    @BindView(R.id.wv_web)
    WebView wv_web;
    @BindView(R.id.layout_address)
    View layout_address;
    @BindView(R.id.layout_ems)
    View layout_ems;
    private String goodsId = "";
    private String url = "";
    private String userPoint = "";
    private String expressPrice = "";
    private String price = "";
    private String goodsType = "";
    private String addressId = "";
    private String score = "";
    private UserAddressInfoModel userAddressInfoModel;
    public static final String PARAM_GOODS_ID = "param_goods_id";
    public static final String PARAM_GOODS_NAME = "param_goods_name";
    public static final String PARAM_GOODS_TYPE = "param_goods_type";

    private boolean isNeedCashPay = false;

    private BaseModel<GetExchangeOrderModel> getExchangeOrderModelBaseModel;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar).init();
    }

    public static void launch(Activity activity, String goodsId, String goodsName, String goodsType) {
        Router.newIntent(activity)
                .to(GoodDetailActivity.class)
                .putString(PARAM_GOODS_ID, goodsId)
                .putString(PARAM_GOODS_NAME, goodsName)
                .putString(PARAM_GOODS_TYPE, goodsType)
                .launch();
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_good_detail;
    }

    @Override
    public GoodDetailPresent newP() {
        return new GoodDetailPresent();
    }


    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        setSupportActionBar(toolbar);
        goodsId = getIntent().getStringExtra(PARAM_GOODS_ID);
        String title = getIntent().getStringExtra(PARAM_GOODS_NAME);
        if (!TextUtils.isEmpty(title)) {
            tv_detail_name.setText(title);
        }
        goodsType = getIntent().getStringExtra(PARAM_GOODS_TYPE);
        setGoodType();
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        int fullWidth = wm.getDefaultDisplay().getWidth();
//        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) iv_detail_image.getLayoutParams();
//        layoutParams.width = fullWidth;
//        layoutParams.height = (int) (fullWidth * 0.77);
//        layoutParams.topMargin = mImmersionBar.getBarParams().titleBarPaddingTopHeight;
        MallInfoParam mallInfoParam = new MallInfoParam();
        mallInfoParam.setGoodId(goodsId);
        mallInfoParam.setUserId(AppContext.getAccount().getUserId());
        iv_exchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final MaterialDialog materialDialog = new MaterialDialog(context);
                materialDialog.setTitle(R.string.exchange)
                        .setMessage(Utils.formatStrings(context, R.string.is_exchange, getIntent().getStringExtra(PARAM_GOODS_NAME)))
                        .setCanceledOnTouchOutside(true)
                        .setPositiveButton(R.string.confirm, new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                materialDialog.dismiss();
                                if (goodsType.equals("1") && TextUtils.isEmpty(addressId)) {
                                    toast(R.string.address_not_null);
                                    return;
                                }

                                if (isNeedCashPay) {
                                    GetExchangeOrderParam getExchangeOrderParam = new GetExchangeOrderParam();
                                    getExchangeOrderParam.setAddressId(addressId);
                                    getExchangeOrderParam.setGoodId(goodsId);
                                    getExchangeOrderParam.setUserId(AppContext.getAccount().getUserId());

                                    getP().getExchangeOrder(getExchangeOrderParam);
                                } else {
                                    UserGoodParam userGoodParam = new UserGoodParam();
                                    userGoodParam.setGoodId(goodsId);
                                    userGoodParam.setUserId(AppContext.getAccount().getUserId());
                                    userGoodParam.setAddressId(addressId);

                                    getP().mallExchange(userGoodParam);
                                }

                            }
                        });
                materialDialog.setNegativeButton(R.string.cancel, new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        materialDialog.dismiss();
                    }
                });
                materialDialog.show();
            }
        });
        getP().getMallInfo(mallInfoParam);
        BusProvider.getBus().toFlowable(AddressEvent.class)
                .subscribe(new Consumer<AddressEvent>() {
                    @Override
                    public void accept(AddressEvent addressEvent) throws Exception {
                        AddressModel addressModel = addressEvent.getModel();
                        if (userAddressInfoModel == null) {
                            userAddressInfoModel = new UserAddressInfoModel();
                        }
                        addressId = addressModel.getAddressId();
                        userAddressInfoModel.setAddress(addressModel.getAddress());
                        userAddressInfoModel.setUserAddressId(addressModel.getAddressId());
                        userAddressInfoModel.setUserAddressMobile(addressModel.getMobile());
                        userAddressInfoModel.setUserAddressPerson(addressModel.getPerson());
                        tv_good_address.setText(userAddressInfoModel.getAddress());
                    }
                });

        BusProvider.getBus().toFlowable(PayEvent.class)
                .subscribe(new Consumer<PayEvent>() {
                    @Override
                    public void accept(PayEvent payEvent) throws Exception {
                        toastMessage("支付成功", "");
                        Account account = AppContext.getAccount();
                        account.setUserPoint(score);
                        SharedPref.getInstance(context).put(Keys.ACCOUNT, account);
                        AppContext.setAccount(account);
                        ExchangeActivity.launch(context);
                        finish();
                    }
                });
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    @SuppressLint("JavascriptInterface")
    private void initWeb() {
        WebSettings webSettings = wv_web.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDefaultTextEncodingName("UTF-8");
        webSettings.setUseWideViewPort(true);// 放大缩小
        webSettings.setSupportZoom(true);
        webSettings.setLoadWithOverviewMode(true);
//        webSettings.setBuiltInZoomControls(true);
        wv_web.addJavascriptInterface(this, "nativeMethod");
        wv_web.setWebChromeClient(new MyWebChromeClient());
        wv_web.setWebViewClient(new WebViewClient());
        if (url != null && url.contains("http")) {
            url = AES128.decode2(url);
            url = url.replace("\"", "");
            wv_web.loadUrl(url);
        }
    }

    class MyWebChromeClient extends WebChromeClient {

        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
        }

        @Override
        public boolean onJsAlert(WebView view, String url, String message,
                                 JsResult result) {
            result.confirm();
            return true;
        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
            try {
                if (newProgress == 100) {
                    hideProgress();
                } else {
                    showProgress();
                }
            } catch (WindowManager.BadTokenException e) {

            }
        }
    }

    private void setData(MallInfoModel mallInfoModel) {
        userAddressInfoModel = mallInfoModel.getUserAddressInfo();
        ILFactory.getLoader().loadNet(iv_detail_image, mallInfoModel.getGoodImageUrl(), null);
        tv_detail_name.setText(mallInfoModel.getGoodName());
        if (TextUtils.isEmpty(mallInfoModel.getIntegral())) {
            tv_good_score.setVisibility(View.GONE);
            tv_score.setVisibility(View.GONE);
        } else {
            int score = Integer.parseInt(mallInfoModel.getIntegral());
            if (score > 0) {
                tv_good_score.setVisibility(View.VISIBLE);
                tv_score.setVisibility(View.VISIBLE);
                tv_good_score.setText(mallInfoModel.getIntegral());
            } else {
                tv_good_score.setVisibility(View.GONE);
                tv_score.setVisibility(View.GONE);
            }
        }
        if (TextUtils.isEmpty(mallInfoModel.getPrice())) {
            tv_good_and.setVisibility(View.GONE);
            tv_good_price.setVisibility(View.GONE);
            tv_good_money.setVisibility(View.GONE);
        } else {
            double price = Double.parseDouble(mallInfoModel.getPrice());
            if (price > 0) {
                tv_good_and.setVisibility(View.VISIBLE);
                tv_good_price.setVisibility(View.VISIBLE);
                tv_good_money.setVisibility(View.VISIBLE);
                tv_good_price.setText(mallInfoModel.getPrice());
            } else {
                tv_good_and.setVisibility(View.GONE);
                tv_good_price.setVisibility(View.GONE);
                tv_good_money.setVisibility(View.GONE);
            }
        }
        if (goodsType.equals("1")) {
            addressId = userAddressInfoModel.getUserAddressId();
            tv_good_address.setText(userAddressInfoModel.getAddress());
            tv_good_ems_price.setText(mallInfoModel.getExpressPriceText());
        }
        userPoint = mallInfoModel.getUserPoint();
        expressPrice = mallInfoModel.getExpressPrice();
        price = mallInfoModel.getPrice();
        Account account = AppContext.getAccount();
        account.setUserPoint(userPoint);
        SharedPref.getInstance(context).put(Keys.ACCOUNT, account);
        AppContext.setAccount(account);
        if (Integer.parseInt(userPoint) < Integer.parseInt(mallInfoModel.getIntegral())) {
            iv_exchange.setImageResource(R.drawable.btn_exchange_disable);
            iv_exchange.setEnabled(false);
        }
    }

    public void showData(BaseModel<MallInfoModel> result) {
        url = result.getData().getGoodDetail();
        goodsType = result.getData().getGoodType();

        if (Double.parseDouble(result.getData().getPrice()) > 0) {
            isNeedCashPay = true;
        } else {
            isNeedCashPay = false;
        }

        setData(result.getData());
        setGoodType();
        initWeb();
    }


    public void exchangeResult(BaseModel<MallExchangeModel> result) {
        if (result.getData() == null) {
            toast(getString(R.string.exchange_failed));
            return;
        }
        double price = 0;
        String orderId = "";
        if (!TextUtils.isEmpty(result.getData().getPrice())) {
            price = Double.parseDouble(result.getData().getPrice());
        }
        if (!TextUtils.isEmpty(result.getData().getUserPoint())) {
            score = result.getData().getUserPoint();
        }
        if (!TextUtils.isEmpty(result.getData().getOrderNumber())) {
            orderId = result.getData().getOrderNumber();
        }
        if (price == 0) {
            toast(getString(R.string.exchange_success));
            Account account = AppContext.getAccount();
            account.setUserPoint(score);
            SharedPref.getInstance(context).put(Keys.ACCOUNT, account);
            AppContext.setAccount(account);
            ExchangeActivity.launch(context);
            finish();
        } else {
            final String finalOrderId = orderId;
            final PayDialog signDialog = new PayDialog
                    .Builder(context)
                    .setMessage(score, price)
                    .setOnAlipayPayClickListener(new PayDialog.OnAlipayPayClickListener() {
                        @Override
                        public void onAlipayPay(DialogInterface dialog, String score, double money) {
                            createOrder(true, finalOrderId);
                        }
                    })
                    .setOnWechatPayClickListener(new PayDialog.OnWechatPayClickListener() {
                        @Override
                        public void onWechatPay(DialogInterface dialog, String score, double money) {
                            createOrder(false, finalOrderId);
                        }
                    })
                    .create();
            signDialog.show();
        }
    }

    public void setGoodType() {
        if (goodsType.equals("2")) {
            layout_address.setVisibility(View.GONE);
            layout_ems.setVisibility(View.GONE);
        } else if (goodsType.equals("1")) {
            layout_address.setVisibility(View.VISIBLE);
            layout_ems.setVisibility(View.VISIBLE);
        } else {
            layout_address.setVisibility(View.GONE);
            layout_ems.setVisibility(View.GONE);
        }
    }

    @OnClick(R.id.tv_good_address)
    void choiceAddress() {
        AddressActivity.launch(context);
    }

    @OnClick(R.id.tv_item_right)
    void choiceAddressRight() {
        AddressActivity.launch(context);
    }

    private void createOrder(boolean isAli, String orderId) {
        if (isAli) {
            PayCreateOrderParam payCreateOrderParam = new PayCreateOrderParam();
            payCreateOrderParam.setOrderNumber(orderId);
            payCreateOrderParam.setDeviceInfo("Android APPV2");
            getP().aliPayCreateOrder(payCreateOrderParam);
        } else {
            WxPayOrderParam wxPayOrderParam = new WxPayOrderParam();
            wxPayOrderParam.setOrderNumber(orderId);
            wxPayOrderParam.setDeviceInfo("Android APPV2");
            getP().wxPayCreateOrder(wxPayOrderParam);
        }
    }

    public void alipayOrder(BaseModel<PayCreateOrderModel> result) {
        alipay(result.getData().getStr());
    }

    public void wechatOrder(BaseModel<WxPayOrderModel> result) {
        payWechat(result.getData());
    }

    private void alipay(final String orderInfo) {
        Runnable payRunnable = new Runnable() {

            @Override
            public void run() {
                PayTask alipay = new PayTask(context);
                Map<String, String> result = alipay.payV2(orderInfo, true);

                Message msg = new Message();
                msg.obj = result;
                mHandler.sendMessage(msg);
            }
        };

        Thread payThread = new Thread(payRunnable);
        payThread.start();
    }

    private void payWechat(final WxPayOrderModel wxPayOrderModel) {
        final IWXAPI api = WXAPIFactory.createWXAPI(this, BuildConfig.wechatKey);
        try {
            PayReq req = new PayReq();
            req.appId = BuildConfig.wechatKey;
            req.partnerId = wxPayOrderModel.getPartnerid();
            req.prepayId = wxPayOrderModel.getPrepayid();
            req.nonceStr = wxPayOrderModel.getNoncestr();
            req.timeStamp = wxPayOrderModel.getTimestamp();
            req.packageValue = wxPayOrderModel.getPackageValue();
            req.sign = wxPayOrderModel.getSign();
            req.extData = "app data";
            // 在支付之前，如果应用没有注册到微信，应该先调用IWXMsg.registerApp将应用注册到微信
            api.sendReq(req);
        } catch (Exception e) {
        }
    }

    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {
        @SuppressWarnings("unused")
        public void handleMessage(Message msg) {
            @SuppressWarnings("unchecked")
            PayResult payResult = new PayResult((Map<String, String>) msg.obj);
            /**
             对于支付结果，请商户依赖服务端的异步通知结果。同步通知结果，仅作为支付结束的通知。
             */
            String resultInfo = payResult.getResult();// 同步返回需要验证的信息
            String resultStatus = payResult.getResultStatus();
            // 判断resultStatus 为9000则代表支付成功
            if (TextUtils.equals(resultStatus, "9000")) {
                // 该笔订单是否真实支付成功，需要依赖服务端的异步通知。
                BusProvider.getBus().post(new PayEvent());
            } else {
                // 该笔订单真实的支付结果，需要依赖服务端的异步通知。
                Toast.makeText(context, "支付失败", Toast.LENGTH_SHORT).show();
            }
        }
    };

    public void getExchangeOrderResult(BaseModel<GetExchangeOrderModel> getExchangeOrderModelBaseModel) {

        score = getExchangeOrderModelBaseModel.getData().getUserPoint();

        ExchangeDialog exchangeDialog = new ExchangeDialog(this, this, getExchangeOrderModelBaseModel.getData().getOrderNumber());
        exchangeDialog.show();

    }

    public void createAliOrder(String orderNo) {

        GetExpressPriceOrderParam param = new GetExpressPriceOrderParam();
        param.setUserId(AppContext.getAccount().getUserId());
        param.setOrderNo(orderNo);

        getP().getExchangeAliPayCreateOrder(param);

    }

    public void createWechatOrder(String orderNo) {

        GetExpressPriceOrderParam param = new GetExpressPriceOrderParam();
        param.setUserId(AppContext.getAccount().getUserId());
        param.setOrderNo(orderNo);

        getP().getExchangeWxPayCreateOrder(param);
    }


}
