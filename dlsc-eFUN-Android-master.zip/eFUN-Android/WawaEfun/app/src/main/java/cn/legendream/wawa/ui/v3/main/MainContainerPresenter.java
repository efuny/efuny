package cn.legendream.wawa.ui.v3.main;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.PushTokenParam;
import cn.legendream.wawa.model.SignParam;
import cn.legendream.wawa.model.SignScoreModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.model.UserSignModel;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import io.reactivex.functions.Consumer;

/**
 * Created by zhaoyuefeng on 2019/4/24.
 * Description 
 */
public class MainContainerPresenter extends XPresent<MainContainerActivity> {


    public void userSignView(SignParam signParam) {
        Api.getSimpleService().userSignView(NetUtil.createRequestBody(signParam))
                .compose(XApi.<BaseModel<UserSignModel>>getApiTransformer())
                .compose(XApi.<BaseModel<UserSignModel>>getScheduler())
                .compose(getV().<BaseModel<UserSignModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress(false);
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<UserSignModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<UserSignModel> resultModel) {
                        getV().hideProgress();
                        getV().showSignDialog(resultModel.getData());
                    }
                });
    }

    public void userSignIn(UserParam userParam) {
        Api.getSimpleService().userSignIn(NetUtil.createRequestBody(userParam))
                .compose(XApi.<BaseModel<SignScoreModel>>getApiTransformer())
                .compose(XApi.<BaseModel<SignScoreModel>>getScheduler())
                .compose(getV().<BaseModel<SignScoreModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress(false);
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<SignScoreModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<SignScoreModel> resultModel) {
                        getV().hideProgress();
                        getV().signSuccess(resultModel.getData().getScore(), resultModel.getData().getGameMoney());
                    }
                });
    }

    public void setUserPushToken(PushTokenParam pushTokenParam) {
        Api.getSimpleService().setUserPushToken(NetUtil.createRequestBody(pushTokenParam))
                .compose(XApi.<BaseModel>getApiTransformer())
                .compose(XApi.<BaseModel>getScheduler())
                .compose(getV().<BaseModel>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel resultModel) {
                        getV().hideProgress();
                    }
                });
    }


}
