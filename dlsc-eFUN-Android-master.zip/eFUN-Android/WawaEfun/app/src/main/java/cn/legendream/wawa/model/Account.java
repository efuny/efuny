package cn.legendream.wawa.model;

import java.io.Serializable;

/**
 * @version V1.0 <>
 * @FileName: Account
 * @author: Samson.Sun
 * @date: 2017-12-6 11:06
 * @email: s_xin@neusoft.com
 */
public class Account implements Serializable {
    public Account() {
    }

    private String nickName;
    private String headUrl;
    private String gameMoney;
    private String userId;
    private String userPoint;

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getHeadUrl() {
        return headUrl;
    }

    public void setHeadUrl(String headUrl) {
        this.headUrl = headUrl;
    }

    public String getGameMoney() {
        return gameMoney;
    }

    public void setGameMoney(String gameMoney) {
        this.gameMoney = gameMoney;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserPoint() {
        return userPoint;
    }

    public void setUserPoint(String userPoint) {
        this.userPoint = userPoint;
    }
}
