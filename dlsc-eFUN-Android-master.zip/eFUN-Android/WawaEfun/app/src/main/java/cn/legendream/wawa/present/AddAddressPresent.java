package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import java.util.List;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.AddAddressParam;
import cn.legendream.wawa.model.AddressModel;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.AddAddressActivity;
import cn.legendream.wawa.ui.MineActivity;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: AddAddressPresent
 * @author: Samson.Sun
 * @date: 2017-12-8 20:30
 * @email: s_xin@neusoft.com
 */
public class AddAddressPresent extends XPresent<AddAddressActivity> {
    public void userEstablishAddress(AddAddressParam addAddressParam) {
        Api.getSimpleService().userEstablishAddress(NetUtil.createRequestBody(addAddressParam))
                .compose(XApi.<BaseModel>getApiTransformer())
                .compose(XApi.<BaseModel>getScheduler())
                .compose(getV().<BaseModel>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel result) {
                        getV().showData(result);
                    }
                });
    }
}
