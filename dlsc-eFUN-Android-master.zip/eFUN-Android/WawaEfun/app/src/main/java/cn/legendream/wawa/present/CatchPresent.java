package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import java.util.List;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.CatchMemberModel;
import cn.legendream.wawa.model.MachineInfoModel;
import cn.legendream.wawa.model.MachineInfoParam;
import cn.legendream.wawa.model.OrderExchangeInfoModel;
import cn.legendream.wawa.model.RecordModel;
import cn.legendream.wawa.model.RecordParam;
import cn.legendream.wawa.model.UserOrderModel;
import cn.legendream.wawa.model.UserOrderParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.RecordActivity;
import cn.legendream.wawa.ui.fragment.BaseCatchFragment;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: CatchPresent
 * @author: Samson.Sun
 * @date: 2017-12-16 20:56
 * @email: s_xin@neusoft.com
 */
public class CatchPresent extends XPresent<BaseCatchFragment> {
    public void userGrabRecordList(final boolean isRefresh, RecordParam recordParam) {
        Api.getSimpleService().userGrabRecordList(NetUtil.createRequestBody(recordParam))
                .compose(XApi.<BaseModel<RecordModel>>getApiTransformer())
                .compose(XApi.<BaseModel<RecordModel>>getScheduler())
                .compose(getV().<BaseModel<RecordModel>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<RecordModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<RecordModel> machineResult) {
                        getV().showData(isRefresh, machineResult);
                    }
                });
    }

    public void userOrderChangeScore(UserOrderParam userOrderParam) {
        Api.getSimpleService().userOrderChangeScore(NetUtil.createRequestBody(userOrderParam))
                .compose(XApi.<BaseModel<UserOrderModel>>getApiTransformer())
                .compose(XApi.<BaseModel<UserOrderModel>>getScheduler())
                .compose(getV().<BaseModel<UserOrderModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<UserOrderModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<UserOrderModel> result) {
                        getV().hideProgress();
                        getV().exchangeResult(result);
                    }
                });
    }

    public void orderExchangeInfo(final UserOrderParam userOrderParam) {
        Api.getSimpleService().orderExchangeInfo(NetUtil.createRequestBody(userOrderParam))
                .compose(XApi.<BaseModel<OrderExchangeInfoModel>>getApiTransformer())
                .compose(XApi.<BaseModel<OrderExchangeInfoModel>>getScheduler())
                .compose(getV().<BaseModel<OrderExchangeInfoModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<OrderExchangeInfoModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<OrderExchangeInfoModel> result) {
                        getV().hideProgress();
                        getV().exchangeInfo(result, userOrderParam.getOrderId());
                    }
                });
    }

    public void userOrderChangeGameIntegral(final UserOrderParam userOrderParam) {
        Api.getSimpleService().userOrderChangeGameIntegral(NetUtil.createRequestBody(userOrderParam))
                .compose(XApi.<BaseModel<UserOrderModel>>getApiTransformer())
                .compose(XApi.<BaseModel<UserOrderModel>>getScheduler())
                .compose(getV().<BaseModel<UserOrderModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<UserOrderModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<UserOrderModel> result) {
                        getV().hideProgress();
                        getV().exchangeScoreResult(result);
                    }
                });
    }
}
