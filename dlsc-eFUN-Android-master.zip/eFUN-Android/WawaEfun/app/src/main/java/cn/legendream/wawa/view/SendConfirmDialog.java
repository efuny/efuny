package cn.legendream.wawa.view;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;

/**
 * @version V1.0 <>
 * @FileName: ScoreChoiceDialog
 * @author: Samson.Sun
 * @date: 2018-6-7 22:42
 * @email: s_xin@neusoft.com
 */
public class SendConfirmDialog extends Dialog {
    public SendConfirmDialog(@NonNull Context context) {
        super(context);
    }

    public SendConfirmDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    public static class Builder {
        private Context context;
        private String expressPrice;
        private OnConfirmClickListener onConfirmClickListener;

        public Builder(Context context) {
            this.context = context;
        }

        public Builder setExpressPrice(String expressPrice) {
            this.expressPrice = expressPrice;
            return this;
        }

        public Builder setOnSubmitClickListener(OnConfirmClickListener onConfirmClickListener) {
            this.onConfirmClickListener = onConfirmClickListener;
            return this;
        }

        public SendConfirmDialog create() {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final SendConfirmDialog dialog = new SendConfirmDialog(context, R.style.Dialog);
            View layout = inflater.inflate(R.layout.dialog_send_confirm, null);

            TextView contentTv = layout.findViewById(R.id.content_tv);
            contentTv.setText("本次发货需支付" + expressPrice + "元邮费，\n请确认收货地址正确。");

            Button negativeButton = layout.findViewById(R.id.negativeButton);
            negativeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onConfirmClickListener.onClick(dialog);
                }
            });
            dialog.setContentView(layout);
            return dialog;
        }
    }

    public interface OnConfirmClickListener {

        void onClick(DialogInterface dialog);

    }
}