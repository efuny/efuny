package cn.legendream.wawa.net;

import cn.droidlover.xdroidmvp.net.XApi;

/**
 * @version V1.0 <>
 * @FileName: Api
 * @author: Samson.Sun
 * @date: 2017-12-5 21:22
 * @email: s_xin@neusoft.com
 */
public class Api {

    public static final String API_BASE_URL = "http://test.efuny.net/index.php/api/";
    //    public static final String BASE_PATH = "EFunIndex/";
    public static final String BASE_PATH = "EFunIndexV3/";
    public static final String BASE_SCORE_PATH = "DuiBaApi/";
    public static final String DUI_BA_PATH = "http://test.efuny.net/";
    public static final String ED_PATH = "http://test.efuny.net/agreement/ed";
    public static final String BASE_URL = API_BASE_URL + BASE_PATH;

    private static SimpleService simpleService;
    private static LoginService loginService;
    private static ControlService controlService;
    private static ScoreService scoreService;

    public static SimpleService getSimpleService() {
        if (simpleService == null) {
            synchronized (Api.class) {
                if (simpleService == null) {
                    simpleService = XApi.getInstance().getRetrofit(BASE_URL, true).create(SimpleService.class);
                }
            }
        }
        return simpleService;
    }

    public static LoginService getLoginService() {
        if (loginService == null) {
            synchronized (Api.class) {
                if (loginService == null) {
                    loginService = XApi.getInstance().getRetrofit(BASE_URL, true).create(LoginService.class);
                }
            }
        }
        return loginService;
    }

    public static ControlService getControlService() {
        if (controlService == null) {
            synchronized (Api.class) {
                if (controlService == null) {
                    controlService = XApi.getInstance().getRetrofit(BASE_URL, true).create(ControlService.class);
                }
            }
        }
        return controlService;
    }

    public static ScoreService getScoreService() {
        if (scoreService == null) {
            synchronized (Api.class) {
                if (scoreService == null) {
                    scoreService = XApi.getInstance().getRetrofit(API_BASE_URL + BASE_SCORE_PATH, true).create(ScoreService.class);
                }
            }
        }
        return scoreService;
    }
}
