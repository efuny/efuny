package cn.legendream.wawa.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.router.Router;
import cn.droidlover.xdroidmvp.view.refreshlayout.SmartRefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.MaterialHeader;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.RefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.enumvo.SpinnerStyle;
import cn.droidlover.xdroidmvp.view.refreshlayout.footer.BallPulseFooter;
import cn.droidlover.xdroidmvp.view.refreshlayout.listener.OnRefreshLoadmoreListener;
import cn.droidlover.xrecyclerview.RecyclerItemCallback;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.adapter.ConsumptionAdapter;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.ConsumptionModel;
import cn.legendream.wawa.model.ConsumptionParam;
import cn.legendream.wawa.present.ConsumptionPresent;

import static android.support.v7.widget.DividerItemDecoration.VERTICAL;

/**
 * 消费记录
 *
 * @version V1.0 <>
 * @FileName: ConsumptionActivity
 * @author: Samson.Sun
 * @date: 2018-3-28 11:12
 * @email: s_xin@neusoft.com
 */
public class ConsumptionActivity extends XActivity<ConsumptionPresent> {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.rv_list)
    XRecyclerView rv_list;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    private ConsumptionAdapter mAdapter;
    private List<ConsumptionModel> ConsumptionModelList;
    private int page = 1;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar)
                .statusBarDarkFont(true, 0.2f).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        initAdapter();
        //设置 Header 为 Material风格
        refreshLayout.setRefreshHeader(new MaterialHeader(context).setShowBezierWave(false));
        //设置 Footer 为 球脉冲
        refreshLayout.setRefreshFooter(new BallPulseFooter(context).setSpinnerStyle(SpinnerStyle.Scale));
        refreshLayout.autoRefresh();
        //第一次进入触发自动刷新，演示效果
        final ConsumptionParam consumptionParam = new ConsumptionParam();
        consumptionParam.setUserId(AppContext.getAccount().getUserId());
        consumptionParam.setPage(page + "");
        getP().getUserConsumptionList(true, consumptionParam);
        refreshLayout.setOnRefreshLoadmoreListener(new OnRefreshLoadmoreListener() {
            @Override
            public void onLoadmore(RefreshLayout refreshlayout) {
                page++;
                consumptionParam.setPage(page + "");
                getP().getUserConsumptionList(false, consumptionParam);
            }

            @Override
            public void onRefresh(RefreshLayout refreshlayout) {
                page = 1;
                consumptionParam.setPage(page + "");
                getP().getUserConsumptionList(true, consumptionParam);
            }
        });
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_consumption;
    }

    @OnClick(R.id.layout_recharge)
    void recharge() {
        if (!Utils.isFastClick()) {
            RechargeActivity.launch(context);
        }
    }

    @Override
    public ConsumptionPresent newP() {
        return new ConsumptionPresent();
    }


    private void initAdapter() {
        ConsumptionModelList = new ArrayList<>();
        mAdapter = new ConsumptionAdapter(context);
        mAdapter.setRecItemClick(new RecyclerItemCallback<ConsumptionModel, ConsumptionAdapter.ViewHolder>() {
            @Override
            public void onItemClick(int position, ConsumptionModel model, int tag, ConsumptionAdapter.ViewHolder holder) {
                super.onItemClick(position, model, tag, holder);
            }
        });
        rv_list.setItemAnimator(new DefaultItemAnimator());
        rv_list.setLayoutManager(new LinearLayoutManager(context));
        rv_list.addItemDecoration(new DividerItemDecoration(context, VERTICAL));
        rv_list.setAdapter(mAdapter);
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(ConsumptionActivity.class)
                .launch();
    }

    public void showError(NetError error) {
        super.showError(error);
        refreshLayout.finishRefresh();
        refreshLayout.finishLoadmore();
    }

    public void showData(boolean isRefresh, BaseModel<List<ConsumptionModel>> result) {
        if (isRefresh) {
            refreshLayout.finishRefresh();
            refreshLayout.resetNoMoreData();
        } else {
            refreshLayout.finishLoadmore();
        }
        if (page > 1) {
            mAdapter.addData(result.getData());
        } else {
            mAdapter.setData(result.getData());
        }
    }
}
