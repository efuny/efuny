package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: UserOrderModel
 * @author: Samson.Sun
 * @date: 2018-1-19 16:07
 * @email: s_xin@neusoft.com
 */
public class UserOrderModel {
    public UserOrderModel() {
    }
    private String point;

    public String getPoint() {
        return point;
    }

    public void setPoint(String point) {
        this.point = point;
    }
}
