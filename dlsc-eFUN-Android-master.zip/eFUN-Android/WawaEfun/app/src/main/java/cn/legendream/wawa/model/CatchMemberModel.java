package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: CatchMemberModel
 * @author: Samson.Sun
 * @date: 2017-12-16 20:12
 * @email: s_xin@neusoft.com
 */
public class CatchMemberModel {
    public CatchMemberModel() {
    }

    private String userName;
    private String headUrl;
    private String createTime;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getHeadUrl() {
        return headUrl;
    }

    public void setHeadUrl(String headUrl) {
        this.headUrl = headUrl;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }
}
