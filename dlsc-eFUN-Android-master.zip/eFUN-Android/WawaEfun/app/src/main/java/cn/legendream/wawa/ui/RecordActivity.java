package cn.legendream.wawa.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.present.RecordPresent;
import cn.legendream.wawa.ui.fragment.BaseCatchFragment;
import cn.legendream.wawa.ui.fragment.CatchFailedFragment;
import cn.legendream.wawa.ui.fragment.CatchSuccessFragment;

/**
 * 抓取记录
 *
 * @version V1.0 <>
 * @FileName: RecordActivity
 * @author: Samson.Sun
 * @date: 2017-12-8 20:23
 * @email: s_xin@neusoft.com
 */
public class RecordActivity extends XActivity<RecordPresent> implements AppBarLayout.OnOffsetChangedListener, BaseCatchFragment.CatchListener {
    @BindView(R.id.app_bar)
    AppBarLayout app_bar;
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.toolbar_layout)
    CollapsingToolbarLayout toolbar_layout;
    @BindView(R.id.refreshLayout)
    View refreshLayout;
    @BindView(R.id.toolbar_title)
    TextView toolbar_title;
    @BindView(R.id.tv_num)
    TextView tv_num;
    @BindView(R.id.tab_success_ll)
    LinearLayout tabSuccessLl;
    @BindView(R.id.tab_fail_ll)
    LinearLayout tabFailLl;
    @BindView(R.id.tab_success_tv)
    TextView tabSuccessTv;
    @BindView(R.id.tab_success_line)
    View tabSuccessLine;
    @BindView(R.id.tab_fail_tv)
    TextView tabFailTv;
    @BindView(R.id.tab_fail_line)
    View tabFailLine;
    private int maxMarginTop = 0;
    private int maxMarginLeft = 0;
    private int maxMarginRight = 0;
    private int EXPEND_MARGIN_TOP = 0;//展开后margin

    List<Fragment> fragmentList = new ArrayList<>();


    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);

        tabSuccessTv.setTypeface(Utils.getCondensedBold(context));
        tabFailTv.setTypeface(Utils.getCondensedBold(context));

        fragmentList.clear();

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();

        CatchSuccessFragment catchSuccessFragment = CatchSuccessFragment.newInstance(this);
        transaction.add(R.id.container_fl, catchSuccessFragment);
        fragmentList.add(catchSuccessFragment);

        CatchFailedFragment catchFailedFragment = CatchFailedFragment.newInstance(this);
        transaction.add(R.id.container_fl, catchFailedFragment);
        fragmentList.add(catchFailedFragment);

        transaction.commit();

        setTab(0);

        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(false);
        }
        EXPEND_MARGIN_TOP = Kits.Dimens.dpToPxInt(context, 10);
        ViewGroup.MarginLayoutParams marginParams = getMarginLayoutParams(refreshLayout);
        maxMarginTop = marginParams.topMargin;
        maxMarginLeft = marginParams.leftMargin;
        maxMarginRight = marginParams.rightMargin;
        app_bar.addOnOffsetChangedListener(this);

    }

    private void setTab(int index) {

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();

        switch (index) {

            case 0: {

                transaction.show(fragmentList.get(0));
                transaction.hide(fragmentList.get(1));

                tabSuccessLine.setSelected(true);
                tabSuccessTv.setSelected(true);

                tabFailLine.setSelected(false);
                tabFailTv.setSelected(false);


                break;
            }

            case 1: {

                transaction.hide(fragmentList.get(0));
                transaction.show(fragmentList.get(1));

                tabSuccessLine.setSelected(false);
                tabSuccessTv.setSelected(false);

                tabFailLine.setSelected(true);
                tabFailTv.setSelected(true);

                break;
            }

        }

        transaction.commit();

    }

    public View getTabText(int position, String[] titles) {
        View v = LayoutInflater.from(this).inflate(R.layout.tab_item, null);
        TextView tv = v.findViewById(R.id.tv_tab_name);
        tv.setText(titles[position]);
        tv.setTypeface(Utils.getGoTrialFont(context));
        return v;
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_record;
    }

    @Override
    public RecordPresent newP() {
        return new RecordPresent();
    }

    @Override
    public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
        int maxHeight = toolbar.getHeight() - app_bar.getHeight();
        if (verticalOffset == 0) {
            setMargin(maxMarginTop);
            toolbar_title.setAlpha(0);
        } else if (verticalOffset == maxHeight) {
            setMargin(EXPEND_MARGIN_TOP);
            toolbar_title.setAlpha(1);
        } else {
            setMargin(maxMarginTop * (maxHeight - verticalOffset) / maxHeight + EXPEND_MARGIN_TOP * verticalOffset / maxHeight);
            toolbar_title.setAlpha(0);
        }
    }

    private void setMargin(int px) {
        ViewGroup.MarginLayoutParams marginParams = getMarginLayoutParams(refreshLayout);
        marginParams.setMargins(maxMarginLeft, px, maxMarginRight, 0);
        refreshLayout.setLayoutParams(marginParams);
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(RecordActivity.class)
                .launch();
    }

    @Override
    public void catchInfoChanged(String username, String headUrl, String dollCount) {
        tv_num.setText(Utils.formatStrings(context, R.string.catch_num, dollCount));
    }

    @OnClick({R.id.tab_success_ll, R.id.tab_fail_ll})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tab_success_ll: {
                setTab(0);
                break;
            }
            case R.id.tab_fail_ll: {
                setTab(1);
                break;
            }
        }
    }
}
