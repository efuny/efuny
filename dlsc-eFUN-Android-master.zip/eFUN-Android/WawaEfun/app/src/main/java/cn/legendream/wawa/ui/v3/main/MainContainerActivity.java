package cn.legendream.wawa.ui.v3.main;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.tencent.android.tpush.XGIOperateCallback;
import com.tencent.android.tpush.XGPushConfig;
import com.tencent.android.tpush.XGPushManager;
import com.tencent.android.tpush.common.Constants;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.event.BusProvider;
import cn.droidlover.xdroidmvp.log.XLog;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.event.LogoutEvent;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.PushTokenParam;
import cn.legendream.wawa.model.SignParam;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.model.UserSignModel;
import cn.legendream.wawa.receiver.NetWorkStateChangeReceiver;
import cn.legendream.wawa.ui.v3.main.charge.ChargeFragment;
import cn.legendream.wawa.ui.v3.main.main.MainFragment;
import cn.legendream.wawa.ui.v3.main.mine.MineFragment;
import cn.legendream.wawa.ui.v3.main.shop.ShopFragment;
import cn.legendream.wawa.view.SignDialog;
import io.reactivex.functions.Consumer;

public class MainContainerActivity extends XActivity<MainContainerPresenter> {

    @BindView(R.id.container_fl)
    FrameLayout containerFl;
    @BindView(R.id.game_tab_ll)
    LinearLayout gameTabLl;
    @BindView(R.id.shop_tab_ll)
    LinearLayout shopTabLl;
    @BindView(R.id.charge_tab_ll)
    LinearLayout chargeTabLl;
    @BindView(R.id.mine_tab_ll)
    LinearLayout mineTabLl;

    private List<Fragment> fragmentList = new ArrayList<>();
    private List<View> tabList = new ArrayList<>();

    private static NetWorkStateChangeReceiver netWorkStateChangeReceiver;

    static {

        netWorkStateChangeReceiver = new NetWorkStateChangeReceiver();

    }

    public static void launch(Activity activity) {
        Router.newIntent(activity)
                .to(MainContainerActivity.class)
                .launch();
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_main_container;
    }

    @Override
    public MainContainerPresenter newP() {
        return new MainContainerPresenter();
    }

    @Override
    public void initData(Bundle savedInstanceState) {

        initFragment();

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");

        registerReceiver(netWorkStateChangeReceiver, intentFilter);

        Utils.awakeApp(context);

        registerPush();

        getP().userSignView(new SignParam(AppContext.getAccount().getUserId(), "0"));
        BusProvider.getBus().toFlowable(LogoutEvent.class)
                .subscribe(new Consumer<LogoutEvent>() {
                    @Override
                    public void accept(LogoutEvent logoutEvent) throws Exception {
                        finish();
                    }
                });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(netWorkStateChangeReceiver);
    }

    private void initFragment() {

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();

        MainFragment mainFragment = new MainFragment();
        fragmentList.add(mainFragment);
        transaction.add(R.id.container_fl, mainFragment);
        tabList.add(gameTabLl);

        ShopFragment shopFragment = new ShopFragment();
        fragmentList.add(shopFragment);
        transaction.add(R.id.container_fl, shopFragment);
        tabList.add(shopTabLl);

        ChargeFragment chargeFragment = new ChargeFragment();
        fragmentList.add(chargeFragment);
        transaction.add(R.id.container_fl, chargeFragment);
        tabList.add(chargeTabLl);

        MineFragment mineFragment = new MineFragment();
        fragmentList.add(mineFragment);
        transaction.add(R.id.container_fl, mineFragment);
        tabList.add(mineTabLl);

        transaction.commit();

        setTab(0);

    }

    private void setTab(int index) {

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();

        for (int i = 0; i < fragmentList.size(); i++) {

            if (index == i) {
                transaction.show(fragmentList.get(i));
                tabList.get(i).setSelected(true);
            } else {
                transaction.hide(fragmentList.get(i));
                tabList.get(i).setSelected(false);
            }

        }

        transaction.commit();

    }

    private void registerPush() {
        //TODO 打包关掉
        XGPushConfig.enableDebug(this, false);
        XGPushManager.registerPush(getApplicationContext(),
                new XGIOperateCallback() {
                    @Override
                    public void onSuccess(Object data, int flag) {
                        XLog.d(Constants.LogTag,
                                "+++ register push sucess. token:" + data);
                        PushTokenParam pushTokenParam = new PushTokenParam();
                        pushTokenParam.setPushToken(data.toString());
                        pushTokenParam.setUserId(AppContext.getAccount().getUserId());
                        getP().setUserPushToken(pushTokenParam);
                    }

                    @Override
                    public void onFail(Object data, int errCode, String msg) {
                        XLog.d(Constants.LogTag,
                                "+++ register push fail. token:" + data
                                        + ", errCode:" + errCode + ",msg:"
                                        + msg);
                    }
                });
    }

    public void showSignDialog(UserSignModel userSignModel) {
        if (userSignModel.getSignList().size() != 7 || userSignModel.getDaySignStauts().equals("1")) {
            return;
        }
        final SignDialog signDialog = new SignDialog
                .Builder(context)
                .setUserSign(userSignModel)
                .setOnSubmitClickListener(new SignDialog.OnSubmitClickListener() {
                    @Override
                    public void onOnSubmit(DialogInterface dialog, String money) {
                        getP().userSignIn(new UserParam(AppContext.getAccount().getUserId()));
                    }
                }).create();
        signDialog.show();
    }

    public void signSuccess(String score, String money) {
//        final MaterialDialog materialDialog = new MaterialDialog(context);
//        materialDialog.setTitle(R.string.tips)
//                .setMessage(Utils.formatStrings(context, R.string.sign_success, money, score))
//                .setCanceledOnTouchOutside(true)
//                .setPositiveButton(R.string.confirm, new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        materialDialog.dismiss();
//                    }
//                });
//        materialDialog.show();
        toastMessage(getString(R.string.sign_success), Utils.formatStrings(context, R.string.sign_gain_score, money, score));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }

    @OnClick({R.id.game_tab_ll, R.id.shop_tab_ll, R.id.charge_tab_ll, R.id.mine_tab_ll})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.game_tab_ll: {
                setTab(0);
                break;
            }
            case R.id.shop_tab_ll: {
                setTab(1);
                break;
            }
            case R.id.charge_tab_ll: {
                setTab(2);
                break;
            }
            case R.id.mine_tab_ll: {
                setTab(3);
                break;
            }
        }
    }
}
