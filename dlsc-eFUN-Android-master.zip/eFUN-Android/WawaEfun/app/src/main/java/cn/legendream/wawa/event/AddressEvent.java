package cn.legendream.wawa.event;

import cn.droidlover.xdroidmvp.event.IBus;
import cn.legendream.wawa.model.AddressModel;

/**
 * @version V1.0 <>
 * @FileName: AddressEvent
 * @author: Samson.Sun
 * @date: 2018-7-23 0:56
 * @email: s_xin@neusoft.com
 */
public class AddressEvent implements IBus.IEvent {
    private AddressModel model;
    public AddressEvent(AddressModel model) {
        this.model = model;
    }

    @Override
    public int getTag() {
        return 0;
    }

    public AddressModel getModel() {
        return model;
    }

    public void setModel(AddressModel model) {
        this.model = model;
    }
}
