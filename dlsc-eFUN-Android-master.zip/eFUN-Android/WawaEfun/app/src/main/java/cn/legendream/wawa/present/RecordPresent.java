package cn.legendream.wawa.present;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.legendream.wawa.ui.RecordActivity;

/**
 *
 * @version V1.0 <>
 * @FileName: RecordPresent
 * @author: Samson.Sun
 * @date: 2017-12-8 20:23
 * @email: s_xin@neusoft.com
 */
public class RecordPresent extends XPresent<RecordActivity> {
}
