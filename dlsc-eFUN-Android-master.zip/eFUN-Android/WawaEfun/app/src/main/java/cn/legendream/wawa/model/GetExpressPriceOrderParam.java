package cn.legendream.wawa.model;

/**
 * Created by zhaoyuefeng on 2018/9/26.
 * Description
 */

public class GetExpressPriceOrderParam {

    private String userId;
    private String orderNo;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
}
