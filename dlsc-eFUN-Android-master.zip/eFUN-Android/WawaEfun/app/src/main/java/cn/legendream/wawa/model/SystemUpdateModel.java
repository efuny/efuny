package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: SystemUpdateModel
 * @author: Samson.Sun
 * @date: 2018-4-3 10:45
 * @email: s_xin@neusoft.com
 */
public class SystemUpdateModel {
    public SystemUpdateModel() {
    }

    private String version;
    private String versionCode;
    private String isForce;
    private String content;
    private String downloadUrl;

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(String versionCode) {
        this.versionCode = versionCode;
    }

    public String getIsForce() {
        return isForce;
    }

    public void setIsForce(String isForce) {
        this.isForce = isForce;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }
}
