package cn.legendream.wawa.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Service;
import android.media.AudioManager;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.AES128;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.Account;
import cn.legendream.wawa.ui.v3.main.MainContainerActivity;

/**
 * @version V1.0 <>
 * @FileName: AdWebActivity
 * @author: Samson.Sun
 * @date: 2018-5-21 11:22
 * @email: s_xin@neusoft.com
 */
public class AdWebActivity extends XActivity {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.wv_web)
    WebView wv_web;
    @BindView(R.id.toolbar_title)
    TextView toolbar_title;

    public static final String PARAM_URL = "param_url";
    public static final String PARAM_TITLE = "param_title";
    private String url;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar)
                .statusBarDarkFont(true, 0.2f).init();
    }

    public static void launch(Activity activity, String url) {
        Router.newIntent(activity)
                .to(AdWebActivity.class)
                .putString(PARAM_URL, url)
                .launch();
    }

    public static void launch(Activity activity, String url, String title) {
        Router.newIntent(activity)
                .to(AdWebActivity.class)
                .putString(PARAM_URL, url)
                .putString(PARAM_TITLE, title)
                .launch();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        url = getIntent().getStringExtra(PARAM_URL);
        if (!TextUtils.isEmpty(getIntent().getStringExtra(PARAM_TITLE))) {
            toolbar_title.setText(getIntent().getStringExtra(PARAM_TITLE));
        }
        initWeb();
    }

    @SuppressLint("JavascriptInterface")
    private void initWeb() {
        WebSettings webSettings = wv_web.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDefaultTextEncodingName("UTF-8");
        webSettings.setUseWideViewPort(true);// 放大缩小
        webSettings.setSupportZoom(true);
        webSettings.setLoadWithOverviewMode(true);
//        webSettings.setBuiltInZoomControls(true);
        wv_web.addJavascriptInterface(this, "nativeMethod");
        wv_web.setWebChromeClient(new MyWebChromeClient());
        wv_web.setWebViewClient(new WebViewClient());
        if (url != null && url.contains("http")) {
            url = AES128.decode2(url);
            url = url.replace("\"", "");
            wv_web.loadUrl(url);
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_ad;
    }

    @Override
    public Object newP() {
        return null;
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        toActivity();
    }

    private void toActivity() {
        boolean isLogin = SharedPref.getInstance(context).getBoolean(Keys.IS_LOGIN, false);
        if (isLogin) {
            Account account = SharedPref.getInstance(context).get(Keys.ACCOUNT, Account.class);
            if (account == null || TextUtils.isEmpty(account.getUserId())) {
                LoginActivity.launch(context);
            }
            AppContext.setAccount(account);
            MainContainerActivity.launch(context);
        } else {
            LoginActivity.launch(context);
        }
        finish();
    }

    class MyWebChromeClient extends WebChromeClient {

        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
        }

        @Override
        public boolean onJsAlert(WebView view, String url, String message,
                                 JsResult result) {
            result.confirm();
            return true;
        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
            try {
                if (newProgress == 100) {
                    hideProgress();
                } else {
                    showProgress();
                }
            } catch (WindowManager.BadTokenException e) {

            }
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                toActivity();
                return true;
            default:
                break;
        }
        return super.onKeyDown(keyCode, event);
    }

}
