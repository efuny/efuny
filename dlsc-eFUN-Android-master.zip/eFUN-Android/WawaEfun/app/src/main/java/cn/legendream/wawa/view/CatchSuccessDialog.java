package cn.legendream.wawa.view;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import cn.legendream.wawa.R;

/**
 * @version V1.0 <>
 * @FileName: ScoreChoiceDialog
 * @author: Samson.Sun
 * @date: 2018-6-7 22:42
 * @email: s_xin@neusoft.com
 */
public class CatchSuccessDialog extends Dialog {
    public CatchSuccessDialog(@NonNull Context context) {
        super(context);
    }

    public CatchSuccessDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    public static class Builder {
        private Context context;

        public Builder(Context context) {
            this.context = context;
        }

        public CatchSuccessDialog create() {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final CatchSuccessDialog dialog = new CatchSuccessDialog(context, R.style.Dialog);
            View layout = inflater.inflate(R.layout.dialog_catch_success, null);

            Button negativeButton = layout.findViewById(R.id.negativeButton);
            negativeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dialog.dismiss();
                }
            });
            dialog.setContentView(layout);
            return dialog;
        }
    }

}