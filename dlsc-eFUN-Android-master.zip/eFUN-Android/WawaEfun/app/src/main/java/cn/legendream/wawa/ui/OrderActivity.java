package cn.legendream.wawa.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.joooonho.SelectableRoundedImageView;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.ExchangeGoodInfoModel;
import cn.legendream.wawa.model.ExpressInfoModel;
import cn.legendream.wawa.model.GoodInfoModel;
import cn.legendream.wawa.model.OrderInfoChildModel;
import cn.legendream.wawa.model.OrderInfoModel;
import cn.legendream.wawa.model.OrderInfoParam;
import cn.legendream.wawa.present.OrderPresent;

/**
 * @version V1.0 <>
 * @FileName: OrderActivity
 * @author: Samson.Sun
 * @date: 2018-7-19 23:45
 * @email: s_xin@neusoft.com
 */
public class OrderActivity extends XActivity<OrderPresent> {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.toolbar_title)
    TextView toolbar_title;
    @BindView(R.id.iv_state)
    ImageView iv_state;
    @BindView(R.id.tv_state)
    TextView tv_state;
    @BindView(R.id.tv_state_value)
    TextView tv_state_value;
    @BindView(R.id.tv_deliver_no)
    TextView tv_deliver_no;
    @BindView(R.id.iv_deliver)
    ImageView iv_deliver;
    @BindView(R.id.tv_deliver_info)
    TextView tv_deliver_info;
    @BindView(R.id.tv_name)
    TextView tv_name;
    @BindView(R.id.tv_mobile)
    TextView tv_mobile;
    @BindView(R.id.tv_address)
    TextView tv_address;
    @BindView(R.id.iv_shop_image)
    SelectableRoundedImageView iv_shop_image;
    @BindView(R.id.tv_order_name)
    TextView tv_order_name;
    @BindView(R.id.tv_good_score)
    TextView tv_good_score;
    @BindView(R.id.tv_score)
    TextView tv_score;
    @BindView(R.id.tv_good_and)
    TextView tv_good_and;
    @BindView(R.id.tv_good_price)
    TextView tv_good_price;
    @BindView(R.id.tv_good_money)
    TextView tv_good_money;
    @BindView(R.id.tv_good_score1)
    TextView tv_good_score1;
    @BindView(R.id.tv_score1)
    TextView tv_score1;
    @BindView(R.id.tv_good_and1)
    TextView tv_good_and1;
    @BindView(R.id.tv_good_price1)
    TextView tv_good_price1;
    @BindView(R.id.tv_good_money1)
    TextView tv_good_money1;
    @BindView(R.id.tv_order_no_value)
    TextView tv_order_no_value;
    @BindView(R.id.tv_order_time_value)
    TextView tv_order_time_value;
    public static final String PARAM_ID = "param_id";
    private String orderId = "";
    private String expressUrl = "";

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar).init();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        orderId = getIntent().getStringExtra(PARAM_ID);
        if (TextUtils.isEmpty(orderId)) {
            toast(R.string.order_null);
            return;
        }
        OrderInfoParam orderInfoParam = new OrderInfoParam();
        orderInfoParam.setUserId(AppContext.getAccount().getUserId());
        orderInfoParam.setOrderId(orderId);
        getP().orderInfo(orderInfoParam);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_order;
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    @Override
    public OrderPresent newP() {
        return new OrderPresent();
    }

    public void showData(BaseModel<OrderInfoModel> result) {
        ExpressInfoModel expressInfo = result.getData().getExpressInfo();
        OrderInfoChildModel orderInfo = result.getData().getOrderInfo();
        GoodInfoModel goodInfo = result.getData().getGoodInfo();
        ExchangeGoodInfoModel exchangeGoodInfo = result.getData().getExchangeGoodInfo();
        setExpressInfo(expressInfo);
        setOrderInfo(orderInfo);
        setGoodInfo(goodInfo);
        setExchangeGoodInfo(exchangeGoodInfo);
    }

    private void setExpressInfo(ExpressInfoModel expressInfo) {
        tv_state.setText(expressInfo.getExpressStatusText());
        tv_state_value.setText(expressInfo.getPayStatusText());
        tv_deliver_info.setText(expressInfo.getExpressName());
        tv_deliver_no.setText(expressInfo.getExpressNumber());
        tv_name.setText(expressInfo.getContacts());
        tv_mobile.setText(expressInfo.getPhoneNumber());
        tv_address.setText(expressInfo.getAddress());
        expressUrl = expressInfo.getExpressUrl();
        //2待发货 3已发货 4已收货 5完成
        if (!TextUtils.isEmpty(expressInfo.getExpressStatus())) {
            if (expressInfo.getExpressStatus().equals("2")) {
                iv_state.setImageResource(R.drawable.ic_wait_send);
            } else if (expressInfo.getExpressStatus().equals("3")) {
                iv_state.setImageResource(R.drawable.ic_already_send);
            } else if (expressInfo.getExpressStatus().equals("4")) {
                iv_state.setImageResource(R.drawable.ic_already_send);
            } else if (expressInfo.getExpressStatus().equals("5")) {
                iv_state.setImageResource(R.drawable.ic_has_finish);
            }
        }
    }

    private void setOrderInfo(OrderInfoChildModel orderInfo) {
        tv_order_no_value.setText(orderInfo.getOrderNumber());
        tv_order_time_value.setText(orderInfo.getCreateTime());
        if (TextUtils.isEmpty(orderInfo.getPrice())) {
            tv_good_and1.setVisibility(View.GONE);
            tv_good_price1.setVisibility(View.GONE);
            tv_good_money1.setVisibility(View.GONE);
        } else {
            double price = Double.parseDouble(orderInfo.getPrice());
            if (price > 0) {
                tv_good_and1.setVisibility(View.VISIBLE);
                tv_good_price1.setVisibility(View.VISIBLE);
                tv_good_money1.setVisibility(View.VISIBLE);
                tv_good_price1.setText(orderInfo.getPrice());
            } else {
                tv_good_and1.setVisibility(View.GONE);
                tv_good_price1.setVisibility(View.GONE);
                tv_good_money1.setVisibility(View.GONE);
            }
        }
        if (TextUtils.isEmpty(orderInfo.getIntegral())) {
            tv_good_score1.setVisibility(View.GONE);
            tv_score1.setVisibility(View.GONE);
        } else {
            int score = Integer.parseInt(orderInfo.getIntegral());
            if (score > 0) {
                tv_good_score1.setVisibility(View.VISIBLE);
                tv_score1.setVisibility(View.VISIBLE);
                tv_good_score1.setText(orderInfo.getIntegral());
            } else {
                tv_good_score1.setVisibility(View.GONE);
                tv_score1.setVisibility(View.GONE);
            }
        }
    }

    private void setGoodInfo(GoodInfoModel goodInfo) {
        ILFactory.getLoader().loadNet(iv_shop_image, goodInfo.getGoodImageUrl(), null);
        tv_order_name.setText(goodInfo.getGoodName());
        if (TextUtils.isEmpty(goodInfo.getPrice())) {
            tv_good_and.setVisibility(View.GONE);
            tv_good_price.setVisibility(View.GONE);
            tv_good_money.setVisibility(View.GONE);
        } else {
            double price = Double.parseDouble(goodInfo.getPrice());
            if (price > 0) {
                tv_good_and.setVisibility(View.VISIBLE);
                tv_good_price.setVisibility(View.VISIBLE);
                tv_good_money.setVisibility(View.VISIBLE);
                tv_good_price.setText(goodInfo.getPrice());
            } else {
                tv_good_and.setVisibility(View.GONE);
                tv_good_price.setVisibility(View.GONE);
                tv_good_money.setVisibility(View.GONE);
            }
        }
        if (TextUtils.isEmpty(goodInfo.getIntegral())) {
            tv_good_score.setVisibility(View.GONE);
            tv_score.setVisibility(View.GONE);
        } else {
            int score = Integer.parseInt(goodInfo.getIntegral());
            if (score > 0) {
                tv_good_score.setVisibility(View.VISIBLE);
                tv_score.setVisibility(View.VISIBLE);
                tv_good_score.setText(goodInfo.getIntegral());
            } else {
                tv_good_score.setVisibility(View.GONE);
                tv_score.setVisibility(View.GONE);
            }
        }
    }

    private void setExchangeGoodInfo(ExchangeGoodInfoModel exchangeGoodInfo) {

    }

    public static void launch(Activity activity, String orderId) {
        Router.newIntent(activity)
                .to(OrderActivity.class)
                .putString(PARAM_ID, orderId)
                .launch();
    }

    @OnClick(R.id.tv_select)
    void select() {
        WebActivity.launch(context, expressUrl, getString(R.string.ems_detail));
    }
}
