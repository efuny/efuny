package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: SubmitCodeParam
 * @author: Samson.Sun
 * @date: 2017-12-21 10:35
 * @email: s_xin@neusoft.com
 */
public class SubmitCodeParam {
    public SubmitCodeParam() {
    }
    private String userId;
    private String code;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
