package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: AboutModel
 * @author: Samson.Sun
 * @date: 2017-12-21 11:25
 * @email: s_xin@neusoft.com
 */
public class AboutModel {
    public AboutModel() {
    }

    private String shareUrl;
    private String agreementUrl;
    private String problemUrl;

    public String getShareUrl() {
        return shareUrl;
    }

    public void setShareUrl(String shareUrl) {
        this.shareUrl = shareUrl;
    }

    public String getAgreementUrl() {
        return agreementUrl;
    }

    public void setAgreementUrl(String agreementUrl) {
        this.agreementUrl = agreementUrl;
    }

    public String getProblemUrl() {
        return problemUrl;
    }

    public void setProblemUrl(String problemUrl) {
        this.problemUrl = problemUrl;
    }
}
