package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: GameControlModel
 * @author: Samson.Sun
 * @date: 2018-1-15 21:42
 * @email: s_xin@neusoft.com
 */
public class GameControlModel {
    public GameControlModel() {
    }

    private String up;
    private String down;
    private String left;
    private String right;
    private String stop;
    private String grab;

    public String getUp() {
        return up;
    }

    public void setUp(String up) {
        this.up = up;
    }

    public String getDown() {
        return down;
    }

    public void setDown(String down) {
        this.down = down;
    }

    public String getLeft() {
        return left;
    }

    public void setLeft(String left) {
        this.left = left;
    }

    public String getRight() {
        return right;
    }

    public void setRight(String right) {
        this.right = right;
    }

    public String getStop() {
        return stop;
    }

    public void setStop(String stop) {
        this.stop = stop;
    }

    public String getGrab() {
        return grab;
    }

    public void setGrab(String grab) {
        this.grab = grab;
    }
}
