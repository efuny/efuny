package cn.legendream.wawa.ui.v3.mine.share;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.InvitationCodeModel;
import cn.legendream.wawa.model.InviteParam;
import cn.legendream.wawa.model.ShareInfoModel;
import cn.legendream.wawa.model.ShareInfoParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import io.reactivex.functions.Consumer;

/**
 * Created by zhaoyuefeng on 2019/5/1.
 * Description 
 */
public class SharePresenter extends XPresent<ShareActivity> {

    public void getUserInvitationCode(InviteParam inviteParam) {
        Api.getSimpleService().getUserInvitationCode(NetUtil.createRequestBody(inviteParam))
                .compose(XApi.<BaseModel<InvitationCodeModel>>getApiTransformer())
                .compose(XApi.<BaseModel<InvitationCodeModel>>getScheduler())
                .compose(getV().<BaseModel<InvitationCodeModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<InvitationCodeModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<InvitationCodeModel> result) {
                        getV().hideProgress();
                        getV().showCode(result);
                    }
                });
    }

    public void getShareInfo(ShareInfoParam shareInfoParam) {
        Api.getSimpleService().getShareInfo(NetUtil.createRequestBody(shareInfoParam))
                .compose(XApi.<BaseModel<ShareInfoModel>>getApiTransformer())
                .compose(XApi.<BaseModel<ShareInfoModel>>getScheduler())
                .compose(getV().<BaseModel<ShareInfoModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<ShareInfoModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<ShareInfoModel> result) {
                        getV().showShareInfo(result);
                    }
                });
    }

}
