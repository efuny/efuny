package cn.legendream.wawa.present;

import java.util.List;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.CategoryModel;
import cn.legendream.wawa.model.SystemStartPageInfoModel;
import cn.legendream.wawa.model.SystemUpdateModel;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.ui.SplashActivity;

/**
 * @version V1.0 <>
 * @FileName: SplashPresent
 * @author: Samson.Sun
 * @date: 2017-12-17 17:51
 * @email: s_xin@neusoft.com
 */
public class SplashPresent extends XPresent<SplashActivity> {
    public void systemStartPageInfo() {
        Api.getSimpleService().systemStartPageInfo()
                .compose(XApi.<BaseModel<SystemStartPageInfoModel>>getApiTransformer())
                .compose(XApi.<BaseModel<SystemStartPageInfoModel>>getScheduler())
                .compose(getV().<BaseModel<SystemStartPageInfoModel>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<SystemStartPageInfoModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<SystemStartPageInfoModel> machineResult) {
                        getV().showUrl(machineResult);
                    }
                });
    }
    public void getMachineCategoryList() {
        Api.getSimpleService().getMachineCategoryList()
                .compose(XApi.<BaseModel<List<CategoryModel>>>getApiTransformer())
                .compose(XApi.<BaseModel<List<CategoryModel>>>getScheduler())
                .compose(getV().<BaseModel<List<CategoryModel>>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<List<CategoryModel>>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<List<CategoryModel>> machineResult) {
                        getV().showCategory(machineResult.getData());
                    }
                });
    }

    public void getSystemUpdate() {
        Api.getSimpleService().getSystemUpdate()
                .compose(XApi.<BaseModel<SystemUpdateModel>>getApiTransformer())
                .compose(XApi.<BaseModel<SystemUpdateModel>>getScheduler())
                .compose(getV().<BaseModel<SystemUpdateModel>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<SystemUpdateModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<SystemUpdateModel> machineResult) {
                        getV().showSystemUpdate(machineResult.getData());
                    }
                });
    }
}
