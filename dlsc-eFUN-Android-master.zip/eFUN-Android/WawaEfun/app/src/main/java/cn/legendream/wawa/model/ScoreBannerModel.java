package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: ScoreBannerModel
 * @author: Samson.Sun
 * @date: 2018-7-17 23:22
 * @email: s_xin@neusoft.com
 */
public class ScoreBannerModel {
    public ScoreBannerModel() {
    }

    private String goodId;
    private String imageUrl;
    private String goodType;

    public String getGoodId() {
        return goodId;
    }

    public void setGoodId(String goodId) {
        this.goodId = goodId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getGoodType() {
        return goodType;
    }

    public void setGoodType(String goodType) {
        this.goodType = goodType;
    }
}
