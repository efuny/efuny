package cn.legendream.wawa.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.kit.KnifeKit;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.model.AddressModel;
import cn.legendream.wawa.model.CatchMemberModel;
import de.hdodenhof.circleimageview.CircleImageView;

/**
 * @version V1.0 <>
 * @FileName: GameCatchAdapter
 * @author: Samson.Sun
 * @date: 2017-12-24 0:53
 * @email: s_xin@neusoft.com
 */
public class GameCatchAdapter extends SimpleRecAdapter<CatchMemberModel, GameCatchAdapter.ViewHolder> {
    public GameCatchAdapter(Context context) {
        super(context);
    }

    @Override
    public ViewHolder newViewHolder(View itemView) {
        return new ViewHolder(itemView);
    }

    @Override
    public int getLayoutId() {
        return R.layout.item_game_catch;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        CatchMemberModel catchMemberModel = data.get(position);
        ILFactory.getLoader().loadNet(holder.profile_image, catchMemberModel.getHeadUrl(), null);
        holder.tv_name.setText(catchMemberModel.getUserName());
        holder.tv_time.setText(catchMemberModel.getCreateTime());
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.profile_image)
        CircleImageView profile_image;
        @BindView(R.id.tv_name)
        TextView tv_name;
        @BindView(R.id.tv_time)
        TextView tv_time;

        public ViewHolder(View itemView) {
            super(itemView);
            KnifeKit.bind(this, itemView);
        }
    }
}
