package cn.legendream.wawa.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.WindowManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;

/**
 * @version V1.0 <>
 * @FileName: WebActivity
 * @author: Samson.Sun
 * @date: 2017-12-21 11:30
 * @email: s_xin@neusoft.com
 */
public class WebActivity extends XActivity {
    @BindView(R.id.detail_toolbar)
    Toolbar toolbar;
    @BindView(R.id.wv_web)
    WebView wv_web;
    @BindView(R.id.toolbar_title)
    TextView toolbar_title;

    public static final String PARAM_URL = "param_url";
    public static final String PARAM_TITLE = "param_title";
    private String url;

    @Override
    protected void initImmersionBar() {
        super.initImmersionBar();
        mImmersionBar.titleBar(toolbar)
                .statusBarDarkFont(true, 0.2f).init();
    }

    public static void launch(Activity activity, String url, String title) {
        Router.newIntent(activity)
                .to(WebActivity.class)
                .putString(PARAM_URL, url)
                .putString(PARAM_TITLE, title)
                .launch();
    }

    @Override
    public void initData(Bundle savedInstanceState) {
        url = getIntent().getStringExtra(PARAM_URL);
        toolbar_title.setText(getIntent().getStringExtra(PARAM_TITLE));
        initWeb();
    }

    @SuppressLint("JavascriptInterface")
    private void initWeb() {
        WebSettings webSettings = wv_web.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDefaultTextEncodingName("UTF-8");
        webSettings.setUseWideViewPort(true);// 放大缩小
        webSettings.setSupportZoom(true);
        webSettings.setLoadWithOverviewMode(true);
//        webSettings.setBuiltInZoomControls(true);
        wv_web.addJavascriptInterface(this, "nativeMethod");
        wv_web.setWebChromeClient(new MyWebChromeClient());
        wv_web.setWebViewClient(new WebViewClient());
        if (url != null && url.contains("http")) {
            wv_web.loadUrl(url);
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_webview;
    }

    @Override
    public Object newP() {
        return null;
    }

    @OnClick(R.id.iv_back)
    void finishActivity() {
        finish();
    }

    class MyWebChromeClient extends WebChromeClient {

        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
        }

        @Override
        public boolean onJsAlert(WebView view, String url, String message,
                                 JsResult result) {
            result.confirm();
            return true;
        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
            try {
                if (newProgress == 100) {
                    hideProgress();
                } else {
                    showProgress();
                }
            } catch (WindowManager.BadTokenException e) {

            }
        }
    }
}
