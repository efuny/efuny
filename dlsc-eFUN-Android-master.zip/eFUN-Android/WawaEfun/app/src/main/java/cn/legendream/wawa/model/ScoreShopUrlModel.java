package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: ScoreShopUrlModel
 * @author: Samson.Sun
 * @date: 2018-5-21 15:17
 * @email: s_xin@neusoft.com
 */
public class ScoreShopUrlModel {
    public ScoreShopUrlModel() {
    }

    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
