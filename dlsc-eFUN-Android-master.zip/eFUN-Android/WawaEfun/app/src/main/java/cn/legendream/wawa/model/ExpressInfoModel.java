package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: ExpressInfoModel
 * @author: Samson.Sun
 * @date: 2018-7-20 1:10
 * @email: s_xin@neusoft.com
 */
public class ExpressInfoModel {
    public ExpressInfoModel() {
    }

    private String expressStatusText;
    private String payStatusText;
    private String expressNumber;
    private String expressName;
    private String address;
    private String phoneNumber;
    private String contacts;
    private String expressUrl;
    /**
     * 2待发货 3已发货 4已收货 5完成
     */
    private String expressStatus;

    public String getExpressStatusText() {
        return expressStatusText;
    }

    public void setExpressStatusText(String expressStatusText) {
        this.expressStatusText = expressStatusText;
    }

    public String getPayStatusText() {
        return payStatusText;
    }

    public void setPayStatusText(String payStatusText) {
        this.payStatusText = payStatusText;
    }

    public String getExpressNumber() {
        return expressNumber;
    }

    public void setExpressNumber(String expressNumber) {
        this.expressNumber = expressNumber;
    }

    public String getExpressName() {
        return expressName;
    }

    public void setExpressName(String expressName) {
        this.expressName = expressName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getContacts() {
        return contacts;
    }

    public void setContacts(String contacts) {
        this.contacts = contacts;
    }

    public String getExpressUrl() {
        return expressUrl;
    }

    public void setExpressUrl(String expressUrl) {
        this.expressUrl = expressUrl;
    }

    /**
     * 2待发货 3已发货 4已收货 5完成
     *
     * @return
     */
    public String getExpressStatus() {
        return expressStatus;
    }

    public void setExpressStatus(String expressStatus) {
        this.expressStatus = expressStatus;
    }
}
