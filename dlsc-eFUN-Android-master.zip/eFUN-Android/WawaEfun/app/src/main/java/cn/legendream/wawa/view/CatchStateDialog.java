package cn.legendream.wawa.view;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import cn.legendream.wawa.R;

/**
 * @version V1.0 <>
 * @FileName: CatchStateDialog
 * @author: Samson.Sun
 * @date: 2017-12-28 21:13
 * @email: s_xin@neusoft.com
 */
public class CatchStateDialog extends Dialog {
    public CatchStateDialog(@NonNull Context context) {
        super(context);
    }

    public CatchStateDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    public static class Builder {
        private Context context;
        private int titleImage = 0;
        private String textView1;
        private String textView2;
        private String btn_text1;
        private String btn_text2;
        private int colorRes;
        private boolean isSuccess;
        private DialogInterface.OnClickListener negativeButtonClickListener;

        public Builder(Context context) {
            this.context = context;
        }

        public Builder setTitleImage(int titleImage) {
            this.titleImage = titleImage;
            return this;
        }

        public Builder setTextView1(String textView1) {
            this.textView1 = textView1;
            return this;
        }

        public Builder setTextView2(String textView2) {
            this.textView2 = textView2;
            return this;
        }

        public Builder setBtn_text1(String btn_text1) {
            this.btn_text1 = btn_text1;
            return this;
        }

        public Builder setBtn_text2(String btn_text2) {
            this.btn_text2 = btn_text2;
            return this;
        }

        public Builder setColorRes(int colorRes) {
            this.colorRes = colorRes;
            return this;
        }

        public Builder setSuccess(boolean success) {
            isSuccess = success;
            return this;
        }

        public Builder setNegativeButtonClickListener(OnClickListener negativeButtonClickListener) {
            this.negativeButtonClickListener = negativeButtonClickListener;
            return this;
        }

        public CatchStateDialog create() {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final CatchStateDialog dialog = new CatchStateDialog(context, R.style.Dialog);
            View layout = inflater.inflate(R.layout.dialog_catch_state, null);
            View layout_bg = layout.findViewById(R.id.layout_bg);
            ImageView iv_image = layout.findViewById(R.id.iv_image);
            TextView tv_txt1 = layout.findViewById(R.id.tv_txt1);
            TextView tv_txt2 = layout.findViewById(R.id.tv_txt2);
            TextView tv_confirm = layout.findViewById(R.id.tv_confirm);
            tv_confirm.requestFocus();
            if (colorRes != 0) {
                layout_bg.setBackgroundColor(colorRes);
            }
            if (isSuccess){
                layout_bg.setBackgroundResource(R.drawable.bg_result_success);
                iv_image.setImageResource(R.drawable.ic_result_success);
            }else{
                layout_bg.setBackgroundResource(R.drawable.bg_result_failed);
                iv_image.setImageResource(R.drawable.ic_result_failed);
            }
            if (titleImage == 0) {
                iv_image.setVisibility(View.GONE);
            } else {
                iv_image.setVisibility(View.VISIBLE);
                iv_image.setImageResource(titleImage);
            }
            if (TextUtils.isEmpty(textView1)) {
                tv_txt1.setVisibility(View.GONE);
            } else {
                tv_txt1.setVisibility(View.VISIBLE);
                tv_txt1.setText(textView1);

            }
            if (TextUtils.isEmpty(textView2)) {
                tv_txt2.setVisibility(View.GONE);
            } else {
                tv_txt2.setVisibility(View.VISIBLE);
                tv_txt2.setText(textView2);

            }
            if (TextUtils.isEmpty(btn_text1)) {
                tv_confirm.setVisibility(View.GONE);
            } else {
                tv_confirm.setVisibility(View.VISIBLE);
                tv_confirm.setText(btn_text1);

            }
            tv_confirm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    negativeButtonClickListener.onClick(dialog,
                            DialogInterface.BUTTON_NEGATIVE);
                }
            });
            dialog.setContentView(layout);
            return dialog;
        }
    }
}
