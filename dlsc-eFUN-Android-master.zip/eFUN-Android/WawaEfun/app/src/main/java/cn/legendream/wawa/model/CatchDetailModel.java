package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: CatchDetailModel
 * @author: Samson.Sun
 * @date: 2018-5-21 16:24
 * @email: s_xin@neusoft.com
 */
public class CatchDetailModel {
    public CatchDetailModel() {
    }

    public String dollName;
    public String dollNumber;
    public String dollImage;
    public String gameIntegral;
    public String dollStatusText;
    public String gameNumber;
    public String contentText;
    public String status;//3：抓中 4：已发货 5：已完成 6：已兑换
    public String statusText;
    public String userPoint;

    public String getDollName() {
        return dollName;
    }

    public void setDollName(String dollName) {
        this.dollName = dollName;
    }

    public String getDollNumber() {
        return dollNumber;
    }

    public void setDollNumber(String dollNumber) {
        this.dollNumber = dollNumber;
    }

    public String getDollImage() {
        return dollImage;
    }

    public void setDollImage(String dollImage) {
        this.dollImage = dollImage;
    }

    public String getGameIntegral() {
        return gameIntegral;
    }

    public void setGameIntegral(String gameIntegral) {
        this.gameIntegral = gameIntegral;
    }

    public String getDollStatusText() {
        return dollStatusText;
    }

    public void setDollStatusText(String dollStatusText) {
        this.dollStatusText = dollStatusText;
    }

    public String getGameNumber() {
        return gameNumber;
    }

    public void setGameNumber(String gameNumber) {
        this.gameNumber = gameNumber;
    }

    public String getContentText() {
        return contentText;
    }

    public void setContentText(String contentText) {
        this.contentText = contentText;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatusText() {
        return statusText;
    }

    public void setStatusText(String statusText) {
        this.statusText = statusText;
    }

    public String getUserPoint() {
        return userPoint;
    }

    public void setUserPoint(String userPoint) {
        this.userPoint = userPoint;
    }
}
