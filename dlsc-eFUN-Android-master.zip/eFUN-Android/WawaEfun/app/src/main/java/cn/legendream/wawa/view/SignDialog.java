package cn.legendream.wawa.view;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Point;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

import cn.droidlover.xdroidmvp.kit.Kits;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.SignModel;
import cn.legendream.wawa.model.UserSignModel;

/**
 * @version V1.0 <>
 * @FileName: SignDialog
 * @author: Samson.Sun
 * @date: 2018-5-22 15:38
 * @email: s_xin@neusoft.com
 */
public class SignDialog extends Dialog {
    public SignDialog(@NonNull Context context) {
        super(context);
    }

    public SignDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    public interface OnSubmitClickListener {
        void onOnSubmit(DialogInterface dialog, String money);
    }

    public static class Builder {
        private Context context;
        private OnSubmitClickListener onSubmitClickListener;
        private UserSignModel userSignModel;
        private View layout_bg, layout_sign, layout_sign_1, layout_sign_2, layout_sign_3, layout_sign_4, layout_sign_5, layout_sign_6, layout_sign_7;
        private ImageView iv_day_state_1, iv_day_state_2, iv_day_state_3, iv_day_state_4, iv_day_state_5, iv_day_state_6, iv_day_state_7;
        private ImageView iv_day_hand_1, iv_day_hand_2, iv_day_hand_3, iv_day_hand_4, iv_day_hand_5, iv_day_hand_6, iv_day_hand_7;
        private ImageView tv_day_score_1, tv_day_score_2, tv_day_score_3, tv_day_score_4, tv_day_score_5, tv_day_score_6, tv_day_score_7;
        private TextView tv_title, tv_day_x_1, tv_day_x_2, tv_day_x_3, tv_day_x_4, tv_day_x_5, tv_day_x_6, tv_day_x_7;
        private ImageView iv_close, iv_get_reward;

        public Builder(Context context) {
            this.context = context;
        }

        public Builder setUserSign(UserSignModel userSignModel) {
            this.userSignModel = userSignModel;
            return this;
        }

        public Builder setOnSubmitClickListener(OnSubmitClickListener onSubmitClickListener) {
            this.onSubmitClickListener = onSubmitClickListener;
            return this;
        }

        public SignDialog create() {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final SignDialog dialog = new SignDialog(context, R.style.Dialog);
            View layout = inflater.inflate(R.layout.dialog_sign, null);
            layout_bg = layout.findViewById(R.id.layout_bg);
            layout_sign = layout.findViewById(R.id.layout_sign);
            layout_sign_1 = layout.findViewById(R.id.layout_sign_1);
            layout_sign_2 = layout.findViewById(R.id.layout_sign_2);
            layout_sign_3 = layout.findViewById(R.id.layout_sign_3);
            layout_sign_4 = layout.findViewById(R.id.layout_sign_4);
            layout_sign_5 = layout.findViewById(R.id.layout_sign_5);
            layout_sign_6 = layout.findViewById(R.id.layout_sign_6);
            layout_sign_7 = layout.findViewById(R.id.layout_sign_7);
            iv_day_state_1 = layout.findViewById(R.id.iv_day_state_1);
            iv_day_state_2 = layout.findViewById(R.id.iv_day_state_2);
            iv_day_state_3 = layout.findViewById(R.id.iv_day_state_3);
            iv_day_state_4 = layout.findViewById(R.id.iv_day_state_4);
            iv_day_state_5 = layout.findViewById(R.id.iv_day_state_5);
            iv_day_state_6 = layout.findViewById(R.id.iv_day_state_6);
            iv_day_state_7 = layout.findViewById(R.id.iv_day_state_7);
            iv_day_hand_1 = layout.findViewById(R.id.iv_day_hand_1);
            iv_day_hand_2 = layout.findViewById(R.id.iv_day_hand_2);
            iv_day_hand_3 = layout.findViewById(R.id.iv_day_hand_3);
            iv_day_hand_4 = layout.findViewById(R.id.iv_day_hand_4);
            iv_day_hand_5 = layout.findViewById(R.id.iv_day_hand_5);
            iv_day_hand_6 = layout.findViewById(R.id.iv_day_hand_6);
            iv_day_hand_7 = layout.findViewById(R.id.iv_day_hand_7);
            tv_day_score_1 = layout.findViewById(R.id.tv_day_score_1);
            tv_day_score_2 = layout.findViewById(R.id.tv_day_score_2);
            tv_day_score_3 = layout.findViewById(R.id.tv_day_score_3);
            tv_day_score_4 = layout.findViewById(R.id.tv_day_score_4);
            tv_day_score_5 = layout.findViewById(R.id.tv_day_score_5);
            tv_day_score_6 = layout.findViewById(R.id.tv_day_score_6);
            tv_day_score_7 = layout.findViewById(R.id.tv_day_score_7);
            tv_day_x_1 = layout.findViewById(R.id.tv_day_x_1);
            tv_day_x_2 = layout.findViewById(R.id.tv_day_x_2);
            tv_day_x_3 = layout.findViewById(R.id.tv_day_x_3);
            tv_day_x_4 = layout.findViewById(R.id.tv_day_x_4);
            tv_day_x_5 = layout.findViewById(R.id.tv_day_x_5);
            tv_day_x_6 = layout.findViewById(R.id.tv_day_x_6);
            tv_day_x_7 = layout.findViewById(R.id.tv_day_x_7);
            tv_title = layout.findViewById(R.id.tv_title);
            iv_close = layout.findViewById(R.id.iv_close);
            iv_get_reward = layout.findViewById(R.id.iv_get_reward);
            TextView[] tv_day_xs = {tv_day_x_1, tv_day_x_2, tv_day_x_3, tv_day_x_4, tv_day_x_5, tv_day_x_6, tv_day_x_7};
            final ImageView[] iv_day_hands = {iv_day_hand_1, iv_day_hand_2, iv_day_hand_3, iv_day_hand_4, iv_day_hand_5, iv_day_hand_6, iv_day_hand_7};
            final ImageView[] iv_day_states = {iv_day_state_1, iv_day_state_2, iv_day_state_3, iv_day_state_4, iv_day_state_5, iv_day_state_6, iv_day_state_7};
            ImageView[] tv_day_scores = {tv_day_score_1, tv_day_score_2, tv_day_score_3, tv_day_score_4, tv_day_score_5, tv_day_score_6, tv_day_score_7};
            View[] layout_signs = {layout_sign_1, layout_sign_2, layout_sign_3, layout_sign_4, layout_sign_5, layout_sign_6, layout_sign_7};
            final int[] signDrawables = {R.drawable.ic_already_sign, R.drawable.ic_already_sign_7};
            final int[] noSignDrawables = {R.drawable.ic_no_sign, R.drawable.ic_no_sign_7};
            int[] dayScoreDrawables = {R.drawable.ic_score_5, R.drawable.ic_score_10, R.drawable.ic_score_15, R.drawable.ic_score_20, R.drawable.ic_score_25, R.drawable.ic_score_30, R.drawable.ic_score_40, R.drawable.ic_score_50};
            String[] scores = {"5", "10", "15", "20", "25", "30", "40", "50"};
            final List<SignModel> signList = userSignModel.getSignList();
            final int signDays = Integer.parseInt(userSignModel.getSignNumber());
            WindowManager wm = (WindowManager) context
                    .getSystemService(Context.WINDOW_SERVICE);
            Point point = new Point();
            wm.getDefaultDisplay().getSize(point);
            int fullWidth = point.x;
            int width = fullWidth - Kits.Dimens.dpToPxInt(context, 170);
            for (int i = 0; i < layout_signs.length; i++) {
                RelativeLayout.LayoutParams signLayoutParams = (RelativeLayout.LayoutParams) layout_signs[i].getLayoutParams();
                if (i == 6) {
                    signLayoutParams.width = width;
                } else {
                    signLayoutParams.height = width / 3;
                    signLayoutParams.width = width / 3;
                }
            }
            RelativeLayout.LayoutParams relayoutLP = (RelativeLayout.LayoutParams) layout_sign.getLayoutParams();
            relayoutLP.width = width + Kits.Dimens.dpToPxInt(context, 30);
            relayoutLP.leftMargin = Kits.Dimens.dpToPxInt(context, 15);
            relayoutLP.rightMargin = Kits.Dimens.dpToPxInt(context, 15);
            relayoutLP.topMargin = Kits.Dimens.dpToPxInt(context, -20);
            layout_sign.setPadding(Kits.Dimens.dpToPxInt(context, 15), Kits.Dimens.dpToPxInt(context, 20), Kits.Dimens.dpToPxInt(context, 15), Kits.Dimens.dpToPxInt(context, 30));
            RelativeLayout.LayoutParams bgLayoutParams = (RelativeLayout.LayoutParams) layout_bg.getLayoutParams();
            bgLayoutParams.width = fullWidth - Kits.Dimens.dpToPxInt(context, 110);
            layout_bg.setPadding(0, 0, 0, Kits.Dimens.dpToPxInt(context, 15));
            tv_title.setText(Utils.formatStrings(context, R.string.sign_x_day, userSignModel.getSignNumber()));
            for (int i = 0; i < 7; i++) {
                tv_day_xs[i].setText(Utils.formatStrings(context, R.string.day_x, signList.get(i).getDay()));
                if (i < signDays) {
                    iv_day_states[i].setVisibility(View.VISIBLE);
                    iv_day_states[i].setImageResource(signList.get(i).getIsSignIn().equals("1") ?
                            (i == 6 ? signDrawables[1] : signDrawables[0]) :
                            (i == 6 ? noSignDrawables[1] : noSignDrawables[0]));
                } else {
                    iv_day_states[i].setVisibility(View.GONE);
                }
                if (i == signDays) {
                    iv_day_hands[i].setVisibility(View.VISIBLE);
                } else {
                    iv_day_hands[i].setVisibility(View.GONE);
                }
                for (int j = 0; j < scores.length; j++) {
                    if (scores[j].equals(signList.get(i).getScore())) {
                        tv_day_scores[i].setImageResource(dayScoreDrawables[j]);
                    }
                }
            }
            iv_get_reward.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    iv_day_hands[signDays].setVisibility(View.GONE);
                    AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
//                    ScaleAnimation scaleAnimation = new ScaleAnimation(2,1,2,1,Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                    alphaAnimation.setDuration(1000);
                    alphaAnimation.setFillAfter(true);
                    iv_day_states[signDays].startAnimation(alphaAnimation);
                    alphaAnimation.setAnimationListener(new Animation.AnimationListener() {
                        @Override
                        public void onAnimationStart(Animation animation) {
                            iv_day_states[signDays].setImageResource(signDays == 6 ? signDrawables[1] : signDrawables[0]);
                            iv_day_states[signDays].setVisibility(View.VISIBLE);
                        }

                        @Override
                        public void onAnimationEnd(Animation animation) {
                            dialog.dismiss();
                            onSubmitClickListener.onOnSubmit(dialog, signList.get(signDays).getScore());
                        }

                        @Override
                        public void onAnimationRepeat(Animation animation) {

                        }
                    });
                }
            });
            iv_close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dialog.dismiss();
                }
            });
            dialog.setContentView(layout);
            return dialog;
        }
    }
}
