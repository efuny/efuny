package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.PayCreateOrderModel;
import cn.legendream.wawa.model.PayCreateOrderParam;
import cn.legendream.wawa.model.PayModel;
import cn.legendream.wawa.model.PayParam;
import cn.legendream.wawa.model.RechargeModel;
import cn.legendream.wawa.model.SubmitCodeParam;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.model.WxPayOrderModel;
import cn.legendream.wawa.model.WxPayOrderParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.MyAccountActivity;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: MyAccountPresent
 * @author: Samson.Sun
 * @date: 2017-12-14 17:10
 * @email: s_xin@neusoft.com
 */
public class MyAccountPresent extends XPresent<MyAccountActivity> {
    public void getRechargeList(UserParam userParam) {
        Api.getSimpleService().getRechargeList(NetUtil.createRequestBody(userParam))
                .compose(XApi.<BaseModel<RechargeModel>>getApiTransformer())
                .compose(XApi.<BaseModel<RechargeModel>>getScheduler())
                .compose(getV().<BaseModel<RechargeModel>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<RechargeModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<RechargeModel> result) {
                        getV().rechargeList(result);
                    }
                });
    }

    public void userCreateRechargeOrder(PayParam payParam, final boolean isAli) {
        Api.getSimpleService().userCreateRechargeOrder(NetUtil.createRequestBody(payParam))
                .compose(XApi.<BaseModel<PayModel>>getApiTransformer())
                .compose(XApi.<BaseModel<PayModel>>getScheduler())
                .compose(getV().<BaseModel<PayModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<PayModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<PayModel> result) {
                        getV().hideProgress();
                        getV().createOrder(result, isAli);
                    }
                });
    }

    public void aliPayCreateOrder(PayCreateOrderParam payCreateOrderParam) {
        Api.getSimpleService().aliPayCreateOrder(NetUtil.createRequestBody(payCreateOrderParam))
                .compose(XApi.<BaseModel<PayCreateOrderModel>>getApiTransformer())
                .compose(XApi.<BaseModel<PayCreateOrderModel>>getScheduler())
                .compose(getV().<BaseModel<PayCreateOrderModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<PayCreateOrderModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<PayCreateOrderModel> result) {
                        getV().hideProgress();
                        getV().alipayOrder(result);
                    }
                });
    }

    public void wxPayCreateOrder(WxPayOrderParam wxPayOrderParam) {
        Api.getSimpleService().wxPayCreateOrder(NetUtil.createRequestBody(wxPayOrderParam))
                .compose(XApi.<BaseModel<WxPayOrderModel>>getApiTransformer())
                .compose(XApi.<BaseModel<WxPayOrderModel>>getScheduler())
                .compose(getV().<BaseModel<WxPayOrderModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<WxPayOrderModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<WxPayOrderModel> result) {
                        getV().hideProgress();
                        getV().wechatOrder(result);
                    }
                });
    }
}
