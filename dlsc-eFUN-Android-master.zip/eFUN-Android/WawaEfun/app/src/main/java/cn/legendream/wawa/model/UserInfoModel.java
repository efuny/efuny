package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: UserInfoModel
 * @author: Samson.Sun
 * @date: 2017-12-26 23:07
 * @email: s_xin@neusoft.com
 */
public class UserInfoModel {
    public UserInfoModel() {
    }

    private String username;
    private String id;
    private String gameMoney;
    private String userPoint;
    private String headUrl;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGameMoney() {
        return gameMoney;
    }

    public void setGameMoney(String gameMoney) {
        this.gameMoney = gameMoney;
    }

    public String getUserPoint() {
        return userPoint;
    }

    public void setUserPoint(String userPoint) {
        this.userPoint = userPoint;
    }

    public String getHeadUrl() {
        return headUrl;
    }

    public void setHeadUrl(String headUrl) {
        this.headUrl = headUrl;
    }
}
