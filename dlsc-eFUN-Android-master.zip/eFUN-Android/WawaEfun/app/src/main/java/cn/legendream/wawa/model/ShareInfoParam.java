package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: ShareInfoParam
 * @author: Samson.Sun
 * @date: 2018-3-28 10:55
 * @email: s_xin@neusoft.com
 */
public class ShareInfoParam {
    public ShareInfoParam(String userId) {
        this.userId = userId;
    }

    private String userId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
