package cn.legendream.wawa;

import android.app.ActivityManager;
import android.app.Application;
import android.app.Notification;
import android.content.Context;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.tencent.android.tpush.XGNotifaction;
import com.tencent.android.tpush.XGPushManager;
import com.tencent.android.tpush.XGPushNotifactionCallback;
import com.tencent.bugly.crashreport.CrashReport;
import com.umeng.socialize.Config;
import com.umeng.socialize.PlatformConfig;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.common.QueuedWork;

import java.io.IOException;
import java.util.List;

import cn.droidlover.xdroidmvp.BuildConfig;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.NetProvider;
import cn.droidlover.xdroidmvp.net.RequestHandler;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.droidlover.xdroidmvp.view.citypicker.style.citypickerview.CityPickerView;
import cn.legendream.wawa.kit.badger.BadgeUtil;
import okhttp3.CookieJar;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * @version V1.0 <>
 * @FileName: App
 * @author: Samson.Sun
 * @date: 2017-12-5 0:41
 * @email: s_xin@neusoft.com
 */
public class App extends Application {
    private static Context context;

    @Override
    public void onCreate() {
        super.onCreate();
        context = this;
        XApi.registerProvider(new NetProvider() {

            @Override
            public Interceptor[] configInterceptors() {
                Interceptor interceptor = new Interceptor() {
                    @Override
                    public Response intercept(Chain chain) throws IOException {
                        Request request = chain.request()
                                .newBuilder()
                                .addHeader("Content-Type", "application/json")
                                .addHeader("Accept", "application/json;charset=UTF-8")
                                .build();
                        /*RequestBody requestBody = request.body();
                        Buffer buffer = new Buffer();
                        if (requestBody != null) {
                            MediaType mediaType = requestBody.contentType();
                            if (mediaType != null) {
                                if (isText(mediaType)) {
                                    final Request copy = request.newBuilder().build();
                                    copy.body().writeTo(buffer);
                                    requestBody.writeTo(buffer);
                                }
                            }
                        }
                        request.newBuilder()
                                .post(requestBody)
                                .build();*/
                        return chain.proceed(request);
                    }
                };
                Interceptor[] interceptors = new Interceptor[]{interceptor};
                return interceptors;
            }

            @Override
            public void configHttps(OkHttpClient.Builder builder) {

            }

            @Override
            public CookieJar configCookie() {
                return null;
            }

            @Override
            public RequestHandler configHandler() {
                return null;
            }

            @Override
            public long configConnectTimeoutMills() {
                return 30000;
            }

            @Override
            public long configReadTimeoutMills() {
                return 30000;
            }

            @Override
            public boolean configLogEnable() {
                return true;
            }

            @Override
            public boolean handleError(NetError error) {
                return false;
            }

            @Override
            public boolean dispatchProgressEnable() {
                return false;
            }
        });
        //bugly注册
        CrashReport.initCrashReport(getApplicationContext(), BuildConfig.buglyId, false);
        // 在主进程设置信鸽相关的内容
        if (isMainProcess()) {
            // 为保证弹出通知前一定调用本方法，需要在application的onCreate注册
            // 收到通知时，会调用本回调函数。
            // 相当于这个回调会拦截在信鸽的弹出通知之前被截取
            // 一般上针对需要获取通知内容、标题，设置通知点击的跳转逻辑等等
            XGPushManager
                    .setNotifactionCallback(new XGPushNotifactionCallback() {

                        @Override
                        public void handleNotify(XGNotifaction xGNotifaction) {
                            Log.i("test", "处理信鸽通知：" + xGNotifaction);
                            // 获取标签、内容、自定义内容
                            String title = xGNotifaction.getTitle();
                            String content = xGNotifaction.getContent();
                            String customContent = xGNotifaction
                                    .getCustomContent();
                            // 其它的处理
                            showBadger();
                            // 如果还要弹出通知，可直接调用以下代码或自己创建Notifaction，否则，本通知将不会弹出在通知栏中。
                            xGNotifaction.doNotify();
                        }
                    });
        }

        //开启debug模式，方便定位错误，具体错误检查方式可以查看http://dev.umeng.com/social/android/quick-integration的报错必看，正式发布，请关闭该模式
        //TODO 测试模式
        Config.DEBUG = false;
        QueuedWork.isUseThreadPool = false;
        UMShareAPI.get(this);
        //城市选择初始化
        CityPickerView.getInstance().init(this);
    }

    private boolean isText(MediaType mediaType) {
        if (mediaType == null) return false;

        return ("text".equals(mediaType.subtype())
                || "json".equals(mediaType.subtype())
                || "xml".equals(mediaType.subtype())
                || "html".equals(mediaType.subtype())
                || "webviewhtml".equals(mediaType.subtype())
                || "x-www-form-urlencoded".equals(mediaType.subtype()));
    }

    public static Context getContext() {
        return context;
    }

    public boolean isMainProcess() {
        ActivityManager am = ((ActivityManager) getSystemService(Context.ACTIVITY_SERVICE));
        List<ActivityManager.RunningAppProcessInfo> processInfos = am.getRunningAppProcesses();
        String mainProcessName = getPackageName();
        int myPid = android.os.Process.myPid();
        for (ActivityManager.RunningAppProcessInfo info : processInfos) {
            if (info.pid == myPid && mainProcessName.equals(info.processName)) {
                return true;
            }
        }
        return false;
    }

    //各个平台的配置，建议放在全局Application或者程序入口
    {
//        PlatformConfig.setWeixin("wx9a7d6224ec489554", "e21d4131ac06a0aaef008f261825b06b");
//        PlatformConfig.setWeixin("wx6a80112f66ba9cd9", "219e4ed5e15d20daa96ad3028117d61e");
        PlatformConfig.setWeixin(BuildConfig.wechatKey, BuildConfig.wechatSecret);
        //tauth.AuthActivity
        PlatformConfig.setSinaWeibo("3384385692", "b96a65c8aeef688b4ca2291f8d61b213", "https://api.weibo.com/oauth2/default.html");
        PlatformConfig.setQQZone("1106550992", "tgnIJrvUW76dnKGl");
        PlatformConfig.setAlipay(BuildConfig.aliAppId);
    }

    private void showBadger(){
        NotificationCompat.Builder mBuilder = new NotificationCompat
                .Builder(getApplicationContext(), context.getResources().getString(R.string.app_name))
                .setSmallIcon(getApplicationInfo().icon)
                .setWhen(System.currentTimeMillis())
                .setAutoCancel(true);

        mBuilder.setContentTitle(context.getResources().getString(R.string.app_name));
        mBuilder.setTicker(context.getResources().getString(R.string.app_name));
        mBuilder.setContentText(context.getResources().getString(R.string.efun_message));

        //点击set 后，app退到桌面等待3s看效果（有的launcher当app在前台设置未读数量无效）
        final Notification notification = mBuilder.build();
        BadgeUtil.sendBadgeNotification(notification, 100, getApplicationContext(), 1, 1);
    }
}
