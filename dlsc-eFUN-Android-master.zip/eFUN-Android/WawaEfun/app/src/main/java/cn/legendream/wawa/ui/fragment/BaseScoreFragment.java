package cn.legendream.wawa.ui.fragment;

import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.mvp.XLazyFragment;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.view.refreshlayout.SmartRefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.MaterialHeader;
import cn.droidlover.xdroidmvp.view.refreshlayout.api.RefreshLayout;
import cn.droidlover.xdroidmvp.view.refreshlayout.enumvo.SpinnerStyle;
import cn.droidlover.xdroidmvp.view.refreshlayout.footer.BallPulseFooter;
import cn.droidlover.xdroidmvp.view.refreshlayout.listener.OnRefreshLoadmoreListener;
import cn.droidlover.xrecyclerview.XRecyclerView;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.Account;
import cn.legendream.wawa.model.ScoreModel;
import cn.legendream.wawa.model.ScoreParam;
import cn.legendream.wawa.present.ScorePresent;

import static android.support.v7.widget.DividerItemDecoration.VERTICAL;

/**
 * @version V1.0 <>
 * @FileName: BaseScoreFragment
 * @author: Samson.Sun
 * @date: 2017-12-20 15:55
 * @email: s_xin@neusoft.com
 */
public abstract class BaseScoreFragment extends XLazyFragment<ScorePresent> {
    @BindView(R.id.contentLayout)
    XRecyclerView contentLayout;
    @BindView(R.id.refreshLayout)
    SmartRefreshLayout refreshLayout;
    private int page = 1;
    public static ScoreChanged scoreChangeListener;

    @Override
    public void initData(Bundle savedInstanceState) {
        Utils.awakeApp(context);
        initAdapter();
        //设置 Header 为 Material风格
        refreshLayout.setRefreshHeader(new MaterialHeader(context).setShowBezierWave(false));
        //设置 Footer 为 球脉冲
        refreshLayout.setRefreshFooter(new BallPulseFooter(context).setSpinnerStyle(SpinnerStyle.Scale));
        refreshLayout.autoRefresh();//第一次进入触发自动刷新，演示效果
        final ScoreParam scoreParam = new ScoreParam();
        scoreParam.setUserId(AppContext.getAccount().getUserId());
        scoreParam.setPointType(getType());
        scoreParam.setPage(page + "");
        getP().getUserPointRecord(true, scoreParam);
        refreshLayout.setOnRefreshLoadmoreListener(new OnRefreshLoadmoreListener() {
            @Override
            public void onLoadmore(RefreshLayout refreshlayout) {
                page++;
                scoreParam.setPage(page + "");
                getP().getUserPointRecord(false, scoreParam);
            }

            @Override
            public void onRefresh(RefreshLayout refreshlayout) {
                page = 1;
                scoreParam.setPage(page + "");
                getP().getUserPointRecord(true, scoreParam);
            }
        });
    }

    private void initAdapter() {
        setLayoutManager(contentLayout);
        contentLayout.setItemAnimator(new DefaultItemAnimator());
        contentLayout.setLayoutManager(new LinearLayoutManager(context));
        contentLayout.addItemDecoration(new DividerItemDecoration(context, VERTICAL));
        contentLayout.setAdapter(getAdapter());
    }

    public interface ScoreChanged {
        void scoreChange(String score, String helpUrl);
    }

    public abstract SimpleRecAdapter getAdapter();

    public abstract void setLayoutManager(XRecyclerView recyclerView);

    public abstract String getType();

    @Override
    public int getLayoutId() {
        return R.layout.fragment_base_catch;
    }

    @Override
    public ScorePresent newP() {
        return new ScorePresent();
    }

    public void showError(NetError error) {
        super.showError(error);
        refreshLayout.finishRefresh();
        refreshLayout.finishLoadmore();
    }

    public void showData(boolean isRefresh, ScoreModel model) {
        if (isRefresh) {
            refreshLayout.finishRefresh();
            refreshLayout.resetNoMoreData();
        } else {
            refreshLayout.finishLoadmore();
        }
        if (scoreChangeListener != null) {
            scoreChangeListener.scoreChange(model.getUserPoint(), model.getHelpUrl());
        }
        Account account = AppContext.getAccount();
        account.setUserPoint(model.getUserPoint());
        SharedPref.getInstance(context).put(Keys.ACCOUNT, account);
        AppContext.setAccount(account);
        if (page > 1) {
            getAdapter().addData(model.getPointRecordList());
        } else {
            getAdapter().setData(model.getPointRecordList());
        }
    }
}
