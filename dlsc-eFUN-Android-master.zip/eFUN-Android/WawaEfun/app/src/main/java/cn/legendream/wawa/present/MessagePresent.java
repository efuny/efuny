package cn.legendream.wawa.present;

import java.util.List;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.MessageModel;
import cn.legendream.wawa.model.MessageParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.MessageActivity;

/**
 * @version V1.0 <>
 * @FileName: MessagePresent
 * @author: Samson.Sun
 * @date: 2017-12-8 20:32
 * @email: s_xin@neusoft.com
 */
public class MessagePresent extends XPresent<MessageActivity> {
    public void getUserMessageList(final boolean isRefresh, MessageParam messageParam) {
        Api.getSimpleService().getUserMessageList(NetUtil.createRequestBody(messageParam))
                .compose(XApi.<BaseModel<List<MessageModel>>>getApiTransformer())
                .compose(XApi.<BaseModel<List<MessageModel>>>getScheduler())
                .compose(getV().<BaseModel<List<MessageModel>>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<List<MessageModel>>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<List<MessageModel>> result) {
                        getV().showData(isRefresh, result);
                    }
                });
    }
}
