package cn.legendream.wawa.ui;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.android.tpush.XGIOperateCallback;
import com.tencent.android.tpush.XGPushConfig;
import com.tencent.android.tpush.XGPushManager;
import com.tencent.android.tpush.common.Constants;

import butterknife.BindView;
import butterknife.OnClick;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.imageloader.ILoader;
import cn.droidlover.xdroidmvp.router.Router;
import cn.legendream.wawa.AppContext;
import cn.legendream.wawa.R;
import cn.legendream.wawa.UpdateService;
import cn.legendream.wawa.kit.Keys;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.kit.badger.BadgeUtil;
import cn.legendream.wawa.model.Account;

import java.util.List;
import java.util.concurrent.TimeUnit;

import cn.droidlover.xdroidmvp.cache.SharedPref;
import cn.droidlover.xdroidmvp.log.XLog;
import cn.droidlover.xdroidmvp.mvp.XActivity;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.CategoryData;
import cn.legendream.wawa.model.CategoryModel;
import cn.legendream.wawa.model.SystemStartPageInfoModel;
import cn.legendream.wawa.model.SystemUpdateModel;
import cn.legendream.wawa.present.SplashPresent;
import cn.legendream.wawa.ui.v3.main.MainContainerActivity;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import okhttp3.internal.Util;

/**
 * @version V1.0 <>
 * @FileName: SplashActivity
 * @author: Samson.Sun
 * @date: 2017-12-6 11:01
 * @email: s_xin@neusoft.com
 */
public class SplashActivity extends XActivity<SplashPresent> {
    @BindView(R.id.iv_splash)
    ImageView iv_splash;
    @BindView(R.id.tv_jump)
    TextView tv_jump;
    private boolean isThrough = false;
    private boolean isCategory = false;
    private boolean isPermission = false;
    private boolean isSystemUpdate = false;
    private boolean isAdShow = false;
    private boolean isClickJump = false;
    private String openUrl = "";

    @Override
    public void initData(Bundle savedInstanceState) {
        getP().getMachineCategoryList();
//        getP().getSystemUpdate();
//        isSystemUpdate = true;
        getP().systemStartPageInfo();
        doStart();
        doGetPermission();
        BadgeUtil.resetBadgeCount(getApplicationContext());
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_splash;
    }

    @Override
    public SplashPresent newP() {
        return new SplashPresent();
    }

    @OnClick(R.id.tv_jump)
    void jump() {
        isClickJump = true;
        toActivity();
    }

    @OnClick(R.id.iv_splash)
    void jumpAd() {
        if (isAdShow) {
            isClickJump = true;
            AdWebActivity.launch(context, openUrl);
            finish();
        }
    }

    private void doGetPermission() {
        getRxPermissions()
                .request(Manifest.permission.READ_EXTERNAL_STORAGE
                        , Manifest.permission.WRITE_EXTERNAL_STORAGE
                        , Manifest.permission.RECORD_AUDIO
                        , Manifest.permission.CAMERA
                        , Manifest.permission.WRITE_SETTINGS)
                .subscribe(new Consumer<Boolean>() {
                    @Override
                    public void accept(Boolean granted) throws Exception {
                        if (isAdShow) {
                            isPermission = true;
                            if (isCategory && isSystemUpdate) {
                                tv_jump.setVisibility(View.VISIBLE);
                            }
                            return;
                        }
                        if (isThrough && isCategory && isSystemUpdate) {
                            toActivity();
                        } else {
                            isPermission = true;
                        }
                    }
                });
    }

    private void doStart() {
        Observable
                .timer(2, TimeUnit.SECONDS)
                .subscribe(new Observer<Long>() {

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onComplete() {

                        getP().getSystemUpdate();

                        if (isAdShow) {
                            isThrough = true;
                            if (isCategory && isSystemUpdate) {
                                tv_jump.setVisibility(View.VISIBLE);
                            }
                            return;
                        }
                        if (isPermission && isCategory && isSystemUpdate) {
                            toActivity();
                        } else {
                            isThrough = true;
                        }
                    }

                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(Long value) {

                    }
                });
    }

    public void showSystemUpdate(final SystemUpdateModel result) {
//        if (isThrough && isPermission && isCategory) {
        try {
            if (Utils.getAppVersionCode(context) < Integer.parseInt(result.getVersionCode())) {
                if (result.getIsForce().equals("0")) {
                    //可忽略
//                        String versionIgnore = SharedPref.getInstance(context).getString(Keys.VERSION_CODE, "-1");
//                        if (versionIgnore.equals(result.getVersionCode())) {
//                            if (isAdShow) {
//                                isSystemUpdate = true;
//                                if (isCategory && isSystemUpdate) {
//                                    tv_jump.setVisibility(View.VISIBLE);
//                                }
//                                return;
//                            }
//                            toActivity();
//                        } else {
//                            //弹下载页面
//                        }

                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setCancelable(false);
                    builder.setTitle("检查到版本更新");
                    builder.setMessage(result.getContent());
                    builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            toActivity();
                        }
                    });
                    builder.setPositiveButton("更新", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent();
                            intent.putExtra("url", result.getDownloadUrl());
                            intent.setClass(SplashActivity.this, UpdateService.class);
                            startService(intent);

                            toActivity();

                        }
                    });
                    builder.show();

                } else {
                    //不可忽略 弹下载页面

                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setCancelable(false);
                    builder.setTitle("检查到版本更新");
                    builder.setMessage(result.getContent());
                    builder.setPositiveButton("更新", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent();
                            intent.putExtra("url", result.getDownloadUrl());
                            intent.setClass(SplashActivity.this, UpdateService.class);
                            startService(intent);

                            toActivity();

                        }
                    });
                    builder.show();

                }
            } else {
                if (isAdShow) {
                    isSystemUpdate = true;
                    if (isCategory && isSystemUpdate) {
                        tv_jump.setVisibility(View.VISIBLE);
                    }
                    return;
                }
                toActivity();
            }
        } catch (Exception e) {
//                if (isAdShow) {
//                    isSystemUpdate = true;
//                    if (isCategory && isSystemUpdate) {
//                        tv_jump.setVisibility(View.VISIBLE);
//                    }
//                    return;
//                }
//                toActivity();
        }
//        } else {
////            isSystemUpdate = true;
//        }
    }

    private void toActivity() {
        boolean isLogin = SharedPref.getInstance(context).getBoolean(Keys.IS_LOGIN, false);
        if (isLogin) {
            Account account = SharedPref.getInstance(context).get(Keys.ACCOUNT, Account.class);
            if (account == null || TextUtils.isEmpty(account.getUserId()) || TextUtils.isEmpty(account.getNickName()) || TextUtils.isEmpty(account.getHeadUrl())) {
                LoginActivity.launch(context);
                return;
            }
            AppContext.setAccount(account);
            MainContainerActivity.launch(context);
        } else {
            LoginActivity.launch(context);
        }
        finish();
    }

    public void showCategory(List<CategoryModel> machineResult) {
        CategoryData categoryData = new CategoryData(machineResult);
        SharedPref.getInstance(context).put(Keys.CATEGORY, categoryData);
        if (isAdShow) {
            isCategory = true;
            if (isSystemUpdate) {
                tv_jump.setVisibility(View.VISIBLE);
            }
            return;
        }
        if (isPermission && isThrough) {
            toActivity();
        } else {
            isCategory = true;
        }
    }

    public void showUrl(BaseModel<SystemStartPageInfoModel> machineResult) {
        if (machineResult.getData() != null && !TextUtils.isEmpty(machineResult.getData().getUrl())) {
            isAdShow = true;
            openUrl = machineResult.getData().getOpenUrl();
            ILoader.Options options = new ILoader.Options(R.drawable.ic_splash, R.drawable.ic_splash);
            ILFactory.getLoader().loadNet(iv_splash, machineResult.getData().getUrl(), options);
            doShowAd();
            if (isCategory && isSystemUpdate) {
                tv_jump.setVisibility(View.VISIBLE);
            }
        }
    }

    private void doShowAd() {
        Observable
                .timer(3, TimeUnit.SECONDS)
                .subscribe(new Observer<Long>() {

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onComplete() {
                        isAdShow = false;
                        if (isPermission && isCategory && isSystemUpdate && !isClickJump) {
                            toActivity();
                        }
                    }

                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(Long value) {

                    }
                });
    }

}
