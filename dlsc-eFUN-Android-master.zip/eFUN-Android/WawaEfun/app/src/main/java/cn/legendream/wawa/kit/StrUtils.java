package cn.legendream.wawa.kit;

/**
 * @version V1.0 <>
 * @FileName: StrUtils
 * @author: Samson.Sun
 * @date: 2017-12-23 18:19
 * @email: s_xin@neusoft.com
 */
public class StrUtils {
    public static boolean notBlank(String str) {
        return str != null && !"".equals(str.trim());
    }
}
