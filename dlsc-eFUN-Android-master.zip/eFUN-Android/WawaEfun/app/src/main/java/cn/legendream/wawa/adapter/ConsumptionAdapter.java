package cn.legendream.wawa.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xdroidmvp.kit.KnifeKit;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.BillModel;
import cn.legendream.wawa.model.ConsumptionModel;
import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.internal.Util;

/**
 * @version V1.0 <>
 * @FileName: ConsumptionAdapter
 * @author: Samson.Sun
 * @date: 2017-12-14 10:49
 * @email: s_xin@neusoft.com
 */
public class ConsumptionAdapter extends SimpleRecAdapter<ConsumptionModel, ConsumptionAdapter.ViewHolder> {
    public ConsumptionAdapter(Context context) {
        super(context);
    }

    @Override
    public ViewHolder newViewHolder(View itemView) {
        return new ViewHolder(itemView);
    }

    @Override
    public int getLayoutId() {
        return R.layout.item_consumption;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ConsumptionModel consumptionModel = data.get(position);
        if (consumptionModel.getType().equals("1") || consumptionModel.getType().equals("3")) {
            holder.tv_money.setText(Utils.formatStrings(context, R.string.income_money, consumptionModel.getGameMoney()));
            holder.tv_money.setTextColor(getColor(R.color.blue_f4));
        } else if (consumptionModel.getType().equals("2")) {
            holder.tv_money.setText(Utils.formatStrings(context, R.string.expense_money, consumptionModel.getGameMoney()));
            holder.tv_money.setTextColor(getColor(R.color.pink_5b));
        } else {
            holder.tv_money.setText(consumptionModel.getGameMoney());
            holder.tv_money.setTextColor(getColor(R.color.blue_f4));
        }
        holder.tv_baby_money.setText(consumptionModel.getContent());
        holder.tv_time.setText(consumptionModel.getDateTime());

    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.tv_money)
        TextView tv_money;
        @BindView(R.id.tv_baby_money)
        TextView tv_baby_money;
        @BindView(R.id.tv_time)
        TextView tv_time;

        public ViewHolder(View itemView) {
            super(itemView);
            KnifeKit.bind(this, itemView);
        }
    }
}
