package cn.legendream.wawa.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;

/**
 * Created by zhaoyuefeng on 2018/9/3.
 * Description
 */

public class NetWorkStateChangeReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        boolean isAvaliable = false;

        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connectivityManager == null) {
            isAvaliable = false;
        } else {

            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isAvailable()) {

//                switch (networkInfo.getType()) {
//
//                    case ConnectivityManager.TYPE_MOBILE: {
//                        Utils.showToast(context, R.string.network_mobile);
//                        break;
//                    }
//
//                    case ConnectivityManager.TYPE_WIFI: {
//
//                        break;
//                    }
//
//                }

                isAvaliable = true;

            } else {
                isAvaliable = false;
            }
        }

        if (!isAvaliable) {
            Toast.makeText(context, "当前网络环境差，建议更换4G或wifi", Toast.LENGTH_SHORT).show();
        }

    }
}
