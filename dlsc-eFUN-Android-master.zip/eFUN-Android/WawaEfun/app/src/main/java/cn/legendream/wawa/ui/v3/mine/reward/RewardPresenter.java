package cn.legendream.wawa.ui.v3.mine.reward;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.RewardModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import io.reactivex.functions.Consumer;

/**
 * Created by zhaoyuefeng on 2019/5/2.
 * Description 
 */
public class RewardPresenter extends XPresent<RewardActivity> {


    public void getRewardList(UserParam userParam) {

        Api.getSimpleService().rewardListInfo(NetUtil.createRequestBody(userParam))
                .compose(XApi.<BaseModel<RewardModel>>getApiTransformer())
                .compose(XApi.<BaseModel<RewardModel>>getScheduler())
                .compose(getV().<BaseModel<RewardModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<RewardModel>>() {
                    @Override
                    public void onNext(BaseModel<RewardModel> result) {
                        getV().hideProgress();
                        getV().showResult(result);
                    }

                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }
                });
    }


}
