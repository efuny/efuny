package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: TestLoginResult
 * @author: Samson.Sun
 * @date: 2018-1-23 9:22
 * @email: s_xin@neusoft.com
 */
public class TestLoginResult {
    public TestLoginResult() {
    }

    private String wx;
    private String testLogin;
    private String agreementUrl;

    public String getWx() {
        return wx;
    }

    public void setWx(String wx) {
        this.wx = wx;
    }

    public String getTestLogin() {
        return testLogin;
    }

    public void setTestLogin(String testLogin) {
        this.testLogin = testLogin;
    }

    public String getAgreementUrl() {
        return agreementUrl;
    }

    public void setAgreementUrl(String agreementUrl) {
        this.agreementUrl = agreementUrl;
    }
}
