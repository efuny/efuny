package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.MallHomeModel;
import cn.legendream.wawa.model.UserParam;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.ShopActivity;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: ScoreShopPresent
 * @author: Samson.Sun
 * @date: 2018-7-8 20:27
 * @email: s_xin@neusoft.com
 */
public class ScoreShopPresent extends XPresent<ShopActivity> {

    public void getMallHome(UserParam userParam) {
        Api.getSimpleService().getMallHome(NetUtil.createRequestBody(userParam))
                .compose(XApi.<BaseModel<MallHomeModel>>getApiTransformer())
                .compose(XApi.<BaseModel<MallHomeModel>>getScheduler())
                .compose(getV().<BaseModel<MallHomeModel>>bindToLifecycle())
                .doOnSubscribe(new Consumer<Subscription>() {
                    @Override
                    public void accept(Subscription subscription) throws Exception {
                        getV().showProgress();
                    }
                })
                .subscribe(new ApiSubscriber<BaseModel<MallHomeModel>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<MallHomeModel> result) {
                        getV().hideProgress();
                        getV().showData(result);
                    }
                });
    }
}
