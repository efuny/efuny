package cn.legendream.wawa.model;

import java.util.List;

/**
 * Created by zhaoyuefeng on 2019/5/17.
 * Description 
 */
public class RewardModel {


    /**
     * invitation_count : 14
     * recharge_count : 12
     * recharge_money : 320
     * recharge_integral : 88
     * list : [{"nick_name":"昵称1","date_time":"2019-05-01","money":"￥67"},{"nick_name":"昵称2","date_time":"2019-05-01","money":"￥58"},{"nick_name":"昵称3","date_time":"2019-05-01","money":"￥11"},{"nick_name":"昵称4","date_time":"2019-05-01","money":"￥15"},{"nick_name":"昵称5","date_time":"2019-05-01","money":"￥71"},{"nick_name":"昵称6","date_time":"2019-05-01","money":"￥75"},{"nick_name":"昵称7","date_time":"2019-05-01","money":"￥39"},{"nick_name":"昵称8","date_time":"2019-05-01","money":"￥83"},{"nick_name":"昵称9","date_time":"2019-05-01","money":"￥74"},{"nick_name":"昵称10","date_time":"2019-05-01","money":"￥99"},{"nick_name":"昵称11","date_time":"2019-05-01","money":"￥68"},{"nick_name":"昵称12","date_time":"2019-05-01","money":"￥86"},{"nick_name":"昵称13","date_time":"2019-05-01","money":"￥71"},{"nick_name":"昵称14","date_time":"2019-05-01","money":"￥32"},{"nick_name":"昵称15","date_time":"2019-05-01","money":"￥17"},{"nick_name":"昵称16","date_time":"2019-05-01","money":"￥26"},{"nick_name":"昵称17","date_time":"2019-05-01","money":"￥60"},{"nick_name":"昵称18","date_time":"2019-05-01","money":"￥70"},{"nick_name":"昵称19","date_time":"2019-05-01","money":"￥33"},{"nick_name":"昵称20","date_time":"2019-05-01","money":"￥45"}]
     */

    private String invitation_count;
    private String recharge_count;
    private String recharge_money;
    private String recharge_integral;
    private List<ListBean> list;

    public String getInvitation_count() {
        return invitation_count;
    }

    public void setInvitation_count(String invitation_count) {
        this.invitation_count = invitation_count;
    }

    public String getRecharge_count() {
        return recharge_count;
    }

    public void setRecharge_count(String recharge_count) {
        this.recharge_count = recharge_count;
    }

    public String getRecharge_money() {
        return recharge_money;
    }

    public void setRecharge_money(String recharge_money) {
        this.recharge_money = recharge_money;
    }

    public String getRecharge_integral() {
        return recharge_integral;
    }

    public void setRecharge_integral(String recharge_integral) {
        this.recharge_integral = recharge_integral;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean {
        /**
         * nick_name : 昵称1
         * date_time : 2019-05-01
         * money : ￥67
         */

        private String nick_name;
        private String date_time;
        private String money;

        public String getNick_name() {
            return nick_name;
        }

        public void setNick_name(String nick_name) {
            this.nick_name = nick_name;
        }

        public String getDate_time() {
            return date_time;
        }

        public void setDate_time(String date_time) {
            this.date_time = date_time;
        }

        public String getMoney() {
            return money;
        }

        public void setMoney(String money) {
            this.money = money;
        }
    }
}
