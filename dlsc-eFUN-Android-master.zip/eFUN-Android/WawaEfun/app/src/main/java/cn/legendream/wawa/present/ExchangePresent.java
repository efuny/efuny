package cn.legendream.wawa.present;

import org.reactivestreams.Subscription;

import java.util.List;

import cn.droidlover.xdroidmvp.mvp.XPresent;
import cn.droidlover.xdroidmvp.net.ApiSubscriber;
import cn.droidlover.xdroidmvp.net.NetError;
import cn.droidlover.xdroidmvp.net.XApi;
import cn.legendream.wawa.model.BaseModel;
import cn.legendream.wawa.model.ExchangeLogModel;
import cn.legendream.wawa.net.Api;
import cn.legendream.wawa.net.NetUtil;
import cn.legendream.wawa.ui.ExchangeActivity;
import io.reactivex.functions.Consumer;

/**
 * @version V1.0 <>
 * @FileName: ExchangePresent
 * @author: Samson.Sun
 * @date: 2018-7-18 23:27
 * @email: s_xin@neusoft.com
 */
public class ExchangePresent extends XPresent<ExchangeActivity> {
    public void exchangeLog(final boolean isRefresh, PageParam pageParam) {
        Api.getSimpleService().exchangeLog(NetUtil.createRequestBody(pageParam))
                .compose(XApi.<BaseModel<List<ExchangeLogModel>>>getApiTransformer())
                .compose(XApi.<BaseModel<List<ExchangeLogModel>>>getScheduler())
                .compose(getV().<BaseModel<List<ExchangeLogModel>>>bindToLifecycle())
                .subscribe(new ApiSubscriber<BaseModel<List<ExchangeLogModel>>>() {
                    @Override
                    protected void onFail(NetError error) {
                        getV().showError(error);
                    }

                    @Override
                    public void onNext(BaseModel<List<ExchangeLogModel>> result) {
                        getV().hideProgress();
                        getV().showData(isRefresh, result);
                    }
                });
    }
}
