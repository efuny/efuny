package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: AddAddressParam
 * @author: Samson.Sun
 * @date: 2017-12-22 11:46
 * @email: s_xin@neusoft.com
 */
public class AddAddressParam {
    public AddAddressParam() {
    }

    private String userId;
    private String province;
    private String city;
    private String area;
    private String mobile;
    private String person;
    private String isDefault;
    private String address;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
