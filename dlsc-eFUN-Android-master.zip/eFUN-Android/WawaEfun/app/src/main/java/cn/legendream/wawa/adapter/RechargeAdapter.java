package cn.legendream.wawa.adapter;

import android.content.Context;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import butterknife.BindView;
import cn.droidlover.xdroidmvp.base.SimpleRecAdapter;
import cn.droidlover.xdroidmvp.imageloader.ILFactory;
import cn.droidlover.xdroidmvp.kit.Kits;
import cn.droidlover.xdroidmvp.kit.KnifeKit;
import cn.legendream.wawa.R;
import cn.legendream.wawa.kit.Utils;
import cn.legendream.wawa.model.RechargeListModel;
import cn.legendream.wawa.model.SendBabyModel;
import okhttp3.internal.Util;

/**
 * @version V1.0 <>
 * @FileName: RechargeAdapter
 * @author: Samson.Sun
 * @date: 2017-12-21 23:45
 * @email: s_xin@neusoft.com
 */
public class RechargeAdapter extends SimpleRecAdapter<RechargeListModel, RechargeAdapter.ViewHolder> {

    public RechargeAdapter(Context context) {
        super(context);
    }

    @Override
    public ViewHolder newViewHolder(View itemView) {
        return new ViewHolder(itemView);
    }

    @Override
    public int getLayoutId() {
        return R.layout.item_recharge;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final RechargeListModel rechargeListModel = data.get(position);
        holder.tv_efun_money1.setTypeface(Utils.getCondensedBold(context));
        holder.tv_efun_money2.setTypeface(Utils.getCondensedBold(context));
        holder.tv_money.setTypeface(Utils.getCondensedBold(context));
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        int fullWidth = wm.getDefaultDisplay().getWidth();
        int width = fullWidth / 2 - Kits.Dimens.dpToPxInt(context, 20) - Kits.Dimens.dpToPxInt(context, 7);
        int height = (int) (width / 1.51);
        GridLayoutManager.LayoutParams layoutParams = (GridLayoutManager.LayoutParams) holder.layout_item.getLayoutParams();
        layoutParams.height = height;
        layoutParams.width = width;
        holder.layout_item.setLayoutParams(layoutParams);
        RelativeLayout.LayoutParams linLayoutParam = (RelativeLayout.LayoutParams) holder.layout_top.getLayoutParams();
        linLayoutParam.width = width - Kits.Dimens.dpToPxInt(context, 15);
        linLayoutParam.height = (int) ((height - Kits.Dimens.dpToPxInt(context, 15)) / 1.52);
        holder.layout_top.setLayoutParams(linLayoutParam);
        RelativeLayout.LayoutParams bottomLayoutParam = (RelativeLayout.LayoutParams) holder.layout_bottom.getLayoutParams();
        bottomLayoutParam.width = linLayoutParam.width;
        bottomLayoutParam.height = height - linLayoutParam.height - Kits.Dimens.dpToPxInt(context, 1) - Kits.Dimens.dpToPxInt(context, 15);
        holder.layout_bottom.setLayoutParams(bottomLayoutParam);
        holder.tv_money.setText(Utils.formatStrings(context, R.string.efun_money, rechargeListModel.getPackagePrice()));
        holder.tv_efun_money1.setText(rechargeListModel.getPackageName());
        holder.tv_efun_money2.setText(rechargeListModel.getPackageTitle());
        if (TextUtils.isEmpty(rechargeListModel.getPackageImageUrl())) {
            ILFactory.getLoader().loadResource(holder.iv_image, R.drawable.ic_money, null);
        } else {
            ILFactory.getLoader().loadNet(holder.iv_image, rechargeListModel.getPackageImageUrl(), null);
        }
        holder.layout_bg.setBackgroundResource(rechargeListModel.isSelect() ? R.drawable.item_account_checked : R.drawable.item_account_normal);
        holder.layout_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getRecItemClick() != null) {
                    getRecItemClick().onItemClick(position, rechargeListModel, 0, holder);
                }
            }
        });
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.layout_item)
        View layout_item;
        @BindView(R.id.layout_bg)
        View layout_bg;
        @BindView(R.id.layout_top)
        View layout_top;
        @BindView(R.id.layout_bottom)
        View layout_bottom;
        @BindView(R.id.tv_money)
        TextView tv_money;
        @BindView(R.id.tv_efun_money1)
        TextView tv_efun_money1;
        @BindView(R.id.tv_efun_money2)
        TextView tv_efun_money2;
        @BindView(R.id.iv_image)
        ImageView iv_image;

        public ViewHolder(View itemView) {
            super(itemView);
            KnifeKit.bind(this, itemView);
        }
    }
}
