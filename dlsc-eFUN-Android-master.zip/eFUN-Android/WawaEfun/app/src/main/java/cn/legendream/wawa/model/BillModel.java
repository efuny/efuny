package cn.legendream.wawa.model;

/**
 * @version V1.0 <>
 * @FileName: BillModel
 * @author: Samson.Sun
 * @date: 2017-12-14 10:50
 * @email: s_xin@neusoft.com
 */
public class BillModel {
    public BillModel() {
    }
    private String payType;
    private String gameMoney;
    private String dateTime;
    private String orderStatus;
    private String price;
    private String statusText;

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getGameMoney() {
        return gameMoney;
    }

    public void setGameMoney(String gameMoney) {
        this.gameMoney = gameMoney;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getStatusText() {
        return statusText;
    }

    public void setStatusText(String statusText) {
        this.statusText = statusText;
    }
}

